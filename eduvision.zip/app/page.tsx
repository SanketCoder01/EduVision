"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Image from "next/image"
import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { School, User } from "lucide-react"

export default function WelcomePage() {
  const router = useRouter()
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Simulate loading time
    const timer = setTimeout(() => {
      setLoading(false)
    }, 3000)

    return () => clearTimeout(timer)
  }, [])

  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-50 to-white flex flex-col items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.5 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5 }}
        className="text-center"
      >
        <div className="relative w-32 h-32 mx-auto mb-6">
          <Image
            src="./images/logo.png"
            alt="EduVision Logo"
            width={128}
            height={128}
            className="rounded-full border-4 border-purple-600 shadow-lg"
            priority
          />
          {loading && (
            <motion.div
              className="absolute inset-0 flex items-center justify-center"
              animate={{ rotate: 360 }}
              transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY, ease: "linear" }}
            >
              <div className="w-full h-full rounded-full border-t-4 border-purple-600 opacity-75"></div>
            </motion.div>
          )}
        </div>
        <motion.h1
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="text-3xl md:text-4xl font-bold text-purple-900 mb-2"
        >
          Welcome to EduVision
        </motion.h1>
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="text-gray-600 mb-8 max-w-md mx-auto"
        >
          Empowering education through innovative technology solutions
        </motion.p>
      </motion.div>

      <motion.div
        initial={{ y: 50, opacity: 0 }}
        animate={{ y: 0, opacity: loading ? 0 : 1 }}
        transition={{ delay: 0.8, type: "spring", stiffness: 100 }}
        className="w-full max-w-md space-y-4"
      >
        <Button
          onClick={() => router.push("/login?type=faculty")}
          className="w-full py-6 bg-purple-700 hover:bg-purple-800 text-white flex items-center justify-center gap-2 text-lg"
        >
          <User className="h-5 w-5" />
          Faculty Login
        </Button>
        <Button
          onClick={() => router.push("/login?type=student")}
          className="w-full py-6 bg-green-600 hover:bg-green-700 text-white flex items-center justify-center gap-2 text-lg"
        >
          <School className="h-5 w-5" />
          Student Login
        </Button>
      </motion.div>
    </div>
  )
}
