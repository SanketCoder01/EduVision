"use server"

import { createServerSupabaseClient } from "@/lib/supabase"
import { revalidatePath } from "next/cache"

// Create a new assignment
export async function createAssignment(formData: {
  title: string
  description: string
  facultyId: string
  classId: string
  assignmentType: string
  allowedFileTypes: string[]
  wordLimit?: number
  startDate: string
  dueDate: string
  visibility: boolean
  allowLateSubmission: boolean
  allowResubmission: boolean
  enablePlagiarismCheck: boolean
  allowGroupSubmission: boolean
}) {
  const supabase = createServerSupabaseClient()

  try {
    const { data, error } = await supabase
      .from("assignments")
      .insert({
        title: formData.title,
        description: formData.description,
        faculty_id: formData.facultyId,
        class_id: formData.classId,
        assignment_type: formData.assignmentType,
        allowed_file_types: formData.allowedFileTypes,
        word_limit: formData.wordLimit,
        start_date: formData.startDate,
        due_date: formData.dueDate,
        visibility: formData.visibility,
        allow_late_submission: formData.allowLateSubmission,
        allow_resubmission: formData.allowResubmission,
        enable_plagiarism_check: formData.enablePlagiarismCheck,
        allow_group_submission: formData.allowGroupSubmission,
      })
      .select()
      .single()

    if (error) throw error

    revalidatePath("/dashboard/assignments")
    return { success: true, data }
  } catch (error) {
    console.error("Error creating assignment:", error)
    return { success: false, error }
  }
}

// Add resources to an assignment
export async function addAssignmentResources(
  resources: {
    assignmentId: string
    name: string
    fileType: string
    fileUrl: string
  }[],
) {
  const supabase = createServerSupabaseClient()

  try {
    const { data, error } = await supabase.from("assignment_resources").insert(
      resources.map((resource) => ({
        assignment_id: resource.assignmentId,
        name: resource.name,
        file_type: resource.fileType,
        file_url: resource.fileUrl,
      })),
    )

    if (error) throw error

    return { success: true, data }
  } catch (error) {
    console.error("Error adding assignment resources:", error)
    return { success: false, error }
  }
}

// Get all assignments
export async function getAssignments(facultyId?: string, classId?: string) {
  const supabase = createServerSupabaseClient()

  try {
    let query = supabase.from("assignments").select("*")

    if (facultyId) {
      query = query.eq("faculty_id", facultyId)
    }

    if (classId) {
      query = query.eq("class_id", classId)
    }

    const { data, error } = await query.order("created_at", { ascending: false })

    if (error) throw error

    return { success: true, data }
  } catch (error) {
    console.error("Error fetching assignments:", error)
    return { success: false, error }
  }
}

// Get assignment by ID
export async function getAssignmentById(id: string) {
  const supabase = createServerSupabaseClient()

  try {
    const { data: assignment, error: assignmentError } = await supabase
      .from("assignments")
      .select("*")
      .eq("id", id)
      .single()

    if (assignmentError) throw assignmentError

    const { data: resources, error: resourcesError } = await supabase
      .from("assignment_resources")
      .select("*")
      .eq("assignment_id", id)

    if (resourcesError) throw resourcesError

    return {
      success: true,
      data: {
        assignment,
        resources: resources || [],
      },
    }
  } catch (error) {
    console.error("Error fetching assignment:", error)
    return { success: false, error }
  }
}

// Update assignment
export async function updateAssignment(
  id: string,
  formData: {
    title: string
    description: string
    classId: string
    assignmentType: string
    allowedFileTypes: string[]
    wordLimit?: number
    startDate: string
    dueDate: string
    visibility: boolean
    allowLateSubmission: boolean
    allowResubmission: boolean
    enablePlagiarismCheck: boolean
    allowGroupSubmission: boolean
  },
) {
  const supabase = createServerSupabaseClient()

  try {
    const { data, error } = await supabase
      .from("assignments")
      .update({
        title: formData.title,
        description: formData.description,
        class_id: formData.classId,
        assignment_type: formData.assignmentType,
        allowed_file_types: formData.allowedFileTypes,
        word_limit: formData.wordLimit,
        start_date: formData.startDate,
        due_date: formData.dueDate,
        visibility: formData.visibility,
        allow_late_submission: formData.allowLateSubmission,
        allow_resubmission: formData.allowResubmission,
        enable_plagiarism_check: formData.enablePlagiarismCheck,
        allow_group_submission: formData.allowGroupSubmission,
        updated_at: new Date().toISOString(),
      })
      .eq("id", id)
      .select()
      .single()

    if (error) throw error

    revalidatePath(`/dashboard/assignments/manage/${id}`)
    revalidatePath("/dashboard/assignments")
    return { success: true, data }
  } catch (error) {
    console.error("Error updating assignment:", error)
    return { success: false, error }
  }
}

// Delete assignment
export async function deleteAssignment(id: string) {
  const supabase = createServerSupabaseClient()

  try {
    const { error } = await supabase.from("assignments").delete().eq("id", id)

    if (error) throw error

    revalidatePath("/dashboard/assignments")
    return { success: true }
  } catch (error) {
    console.error("Error deleting assignment:", error)
    return { success: false, error }
  }
}

// Get submissions for an assignment
export async function getSubmissions(assignmentId: string) {
  const supabase = createServerSupabaseClient()

  try {
    const { data, error } = await supabase
      .from("submissions")
      .select("*")
      .eq("assignment_id", assignmentId)
      .order("submitted_at", { ascending: false })

    if (error) throw error

    // Get submission files
    const submissionIds = data.map((submission) => submission.id)

    if (submissionIds.length > 0) {
      const { data: files, error: filesError } = await supabase
        .from("submission_files")
        .select("*")
        .in("submission_id", submissionIds)

      if (filesError) throw filesError

      // Add files to submissions
      const submissionsWithFiles = data.map((submission) => {
        const submissionFiles = files.filter((file) => file.submission_id === submission.id)
        return {
          ...submission,
          files: submissionFiles,
        }
      })

      return { success: true, data: submissionsWithFiles }
    }

    return { success: true, data }
  } catch (error) {
    console.error("Error fetching submissions:", error)
    return { success: false, error }
  }
}

// Submit assignment
export async function submitAssignment(formData: {
  assignmentId: string
  studentId: string
  submissionType: string
  content?: string
  files?: {
    name: string
    fileType: string
    fileUrl: string
    fileSize: number
  }[]
}) {
  const supabase = createServerSupabaseClient()

  try {
    // Create submission
    const { data: submission, error: submissionError } = await supabase
      .from("submissions")
      .insert({
        assignment_id: formData.assignmentId,
        student_id: formData.studentId,
        submission_type: formData.submissionType,
        content: formData.content,
        status: "submitted",
        submitted_at: new Date().toISOString(),
      })
      .select()
      .single()

    if (submissionError) throw submissionError

    // Add files if any
    if (formData.files && formData.files.length > 0) {
      const { error: filesError } = await supabase.from("submission_files").insert(
        formData.files.map((file) => ({
          submission_id: submission.id,
          name: file.name,
          file_type: file.fileType,
          file_url: file.fileUrl,
          file_size: file.fileSize,
        })),
      )

      if (filesError) throw filesError
    }

    revalidatePath(`/student-dashboard/assignments`)
    return { success: true, data: submission }
  } catch (error) {
    console.error("Error submitting assignment:", error)
    return { success: false, error }
  }
}

// Save draft
export async function saveDraft(formData: {
  assignmentId: string
  studentId: string
  submissionType: string
  content?: string
  files?: {
    name: string
    fileType: string
    fileUrl: string
    fileSize: number
  }[]
}) {
  const supabase = createServerSupabaseClient()

  try {
    // Create draft
    const { data: draft, error: draftError } = await supabase
      .from("submissions")
      .insert({
        assignment_id: formData.assignmentId,
        student_id: formData.studentId,
        submission_type: formData.submissionType,
        content: formData.content,
        status: "draft",
        submitted_at: null,
      })
      .select()
      .single()

    if (draftError) throw draftError

    // Add files if any
    if (formData.files && formData.files.length > 0) {
      const { error: filesError } = await supabase.from("submission_files").insert(
        formData.files.map((file) => ({
          submission_id: draft.id,
          name: file.name,
          file_type: file.fileType,
          file_url: file.fileUrl,
          file_size: file.fileSize,
        })),
      )

      if (filesError) throw filesError
    }

    return { success: true, data: draft }
  } catch (error) {
    console.error("Error saving draft:", error)
    return { success: false, error }
  }
}

// Grade submission
export async function gradeSubmission(submissionId: string, grade: string, feedback: string) {
  const supabase = createServerSupabaseClient()

  try {
    const { data, error } = await supabase
      .from("submissions")
      .update({
        status: "graded",
        grade,
        feedback,
        graded_at: new Date().toISOString(),
      })
      .eq("id", submissionId)
      .select()
      .single()

    if (error) throw error

    return { success: true, data }
  } catch (error) {
    console.error("Error grading submission:", error)
    return { success: false, error }
  }
}

// Return submission for resubmission
export async function returnForResubmission(submissionId: string, feedback: string) {
  const supabase = createServerSupabaseClient()

  try {
    const { data, error } = await supabase
      .from("submissions")
      .update({
        status: "returned",
        feedback,
        graded_at: null,
        grade: null,
      })
      .eq("id", submissionId)
      .select()
      .single()

    if (error) throw error

    return { success: true, data }
  } catch (error) {
    console.error("Error returning submission:", error)
    return { success: false, error }
  }
}

// Send notification
export async function sendNotification(formData: {
  assignmentId: string
  recipientIds: string[]
  type: string
  content: string
}) {
  const supabase = createServerSupabaseClient()

  try {
    const notifications = formData.recipientIds.map((recipientId) => ({
      assignment_id: formData.assignmentId,
      recipient_id: recipientId,
      type: formData.type,
      content: formData.content,
    }))

    const { data, error } = await supabase.from("assignment_notifications").insert(notifications)

    if (error) throw error

    return { success: true, data }
  } catch (error) {
    console.error("Error sending notifications:", error)
    return { success: false, error }
  }
}

// Add comment
export async function addComment(formData: {
  assignmentId: string
  submissionId?: string
  userId: string
  userType: "faculty" | "student"
  content: string
}) {
  const supabase = createServerSupabaseClient()

  try {
    const { data, error } = await supabase
      .from("assignment_comments")
      .insert({
        assignment_id: formData.assignmentId,
        submission_id: formData.submissionId,
        user_id: formData.userId,
        user_type: formData.userType,
        content: formData.content,
      })
      .select()
      .single()

    if (error) throw error

    return { success: true, data }
  } catch (error) {
    console.error("Error adding comment:", error)
    return { success: false, error }
  }
}

// Get comments for an assignment or submission
export async function getComments(assignmentId: string, submissionId?: string) {
  const supabase = createServerSupabaseClient()

  try {
    let query = supabase
      .from("assignment_comments")
      .select("*")
      .eq("assignment_id", assignmentId)
      .order("created_at", { ascending: true })

    if (submissionId) {
      query = query.eq("submission_id", submissionId)
    }

    const { data, error } = await query

    if (error) throw error

    return { success: true, data }
  } catch (error) {
    console.error("Error fetching comments:", error)
    return { success: false, error }
  }
}

// Get student submissions for an assignment
export async function getStudentSubmissions(studentId: string, assignmentId?: string) {
  const supabase = createServerSupabaseClient()

  try {
    let query = supabase.from("submissions").select("*, assignment:assignments(*)").eq("student_id", studentId)

    if (assignmentId) {
      query = query.eq("assignment_id", assignmentId)
    }

    const { data, error } = await query.order("created_at", { ascending: false })

    if (error) throw error

    // Get submission files
    const submissionIds = data.map((submission) => submission.id)

    if (submissionIds.length > 0) {
      const { data: files, error: filesError } = await supabase
        .from("submission_files")
        .select("*")
        .in("submission_id", submissionIds)

      if (filesError) throw filesError

      // Add files to submissions
      const submissionsWithFiles = data.map((submission) => {
        const submissionFiles = files.filter((file) => file.submission_id === submission.id)
        return {
          ...submission,
          files: submissionFiles,
        }
      })

      return { success: true, data: submissionsWithFiles }
    }

    return { success: true, data }
  } catch (error) {
    console.error("Error fetching student submissions:", error)
    return { success: false, error }
  }
}

// Get assignments for a student
export async function getStudentAssignments(studentId: string, classIds: string[]) {
  const supabase = createServerSupabaseClient()

  try {
    // Get all visible assignments for the student's classes
    const { data: assignments, error: assignmentsError } = await supabase
      .from("assignments")
      .select("*")
      .in("class_id", classIds)
      .eq("visibility", true)
      .order("due_date", { ascending: true })

    if (assignmentsError) throw assignmentsError

    // Get student's submissions
    const { data: submissions, error: submissionsError } = await supabase
      .from("submissions")
      .select("*")
      .eq("student_id", studentId)

    if (submissionsError) throw submissionsError

    // Combine assignments with submission status
    const assignmentsWithStatus = assignments.map((assignment) => {
      const submission = submissions.find((sub) => sub.assignment_id === assignment.id)
      return {
        ...assignment,
        submission: submission || null,
        status: submission ? submission.status : "not_submitted",
      }
    })

    return { success: true, data: assignmentsWithStatus }
  } catch (error) {
    console.error("Error fetching student assignments:", error)
    return { success: false, error }
  }
}
