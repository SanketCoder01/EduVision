"use client"

import { useState, useRef } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Calendar, Clock, MapPin, Upload, X, Check, ChevronRight, ChevronLeft, DollarSign, Users } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { useToast } from "@/components/ui/use-toast"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"

// Mock data for departments
const departments = ["CSE", "IT", "ME", "EE", "CY", "AIML", "AIDS"]

export default function EventsPage() {
  const { toast } = useToast()
  const [activeTab, setActiveTab] = useState("create")
  const [currentStep, setCurrentStep] = useState(1)
  const [eventType, setEventType] = useState("")
  const [selectedDepartments, setSelectedDepartments] = useState([])
  const [enablePayment, setEnablePayment] = useState(false)
  const [showAttendance, setShowAttendance] = useState(false)
  const [showSeatSelection, setShowSeatSelection] = useState(false)
  const [selectedSeats, setSelectedSeats] = useState([])
  const [seatAssignments, setSeatAssignments] = useState({})
  const [currentAssignClass, setCurrentAssignClass] = useState("")
  const [searchQuery, setSearchQuery] = useState("")

  // Form states
  const [title, setTitle] = useState("")
  const [description, setDescription] = useState("")
  const [date, setDate] = useState("")
  const [time, setTime] = useState("")
  const [venue, setVenue] = useState("")
  const [maxParticipants, setMaxParticipants] = useState("")
  const [paymentAmount, setPaymentAmount] = useState("")
  const [poster, setPoster] = useState(null)

  const fileInputRef = useRef(null)

  // Mock events data
  const [events, setEvents] = useState([
    {
      id: 1,
      title: "Annual Tech Symposium",
      description:
        "A day-long symposium featuring workshops, talks, and networking opportunities for tech enthusiasts.",
      date: "2023-05-15",
      time: "10:00",
      venue: "Main Auditorium",
      poster: "/placeholder.svg?height=200&width=400",
      maxParticipants: 100,
      targetAudience: ["CSE", "IT", "AIML"],
      onlinePayment: true,
      paymentAmount: "500",
      registeredStudents: 45,
      paidStudents: 38,
      attendedStudents: 0,
      seatAssignments: {
        "FY-CSE": [1, 2, 3, 4, 5],
        "SY-AIML": [20, 21, 22, 23, 24, 25],
        "TY-IT": [50, 51, 52, 53],
      },
    },
  ])

  // Mock students data for attendance
  const [students, setStudents] = useState([
    { id: 1, name: "Rahul Sharma", prn: "PRN2023001", class: "FY-CSE", present: false, paid: true },
    { id: 2, name: "Priya Patel", prn: "PRN2023002", class: "FY-CSE", present: false, paid: true },
    { id: 3, name: "Amit Kumar", prn: "PRN2023003", class: "SY-CSE", present: false, paid: false },
    { id: 4, name: "Sneha Gupta", prn: "PRN2023004", class: "SY-CSE", present: false, paid: true },
    { id: 5, name: "Vikram Singh", prn: "PRN2023005", class: "TY-CSE", present: false, paid: true },
    { id: 6, name: "Neha Verma", prn: "PRN2023006", class: "FY-IT", present: false, paid: false },
    { id: 7, name: "Raj Malhotra", prn: "PRN2023007", class: "SY-IT", present: false, paid: true },
    { id: 8, name: "Ananya Desai", prn: "PRN2023008", class: "TY-IT", present: false, paid: true },
    { id: 9, name: "Rohan Joshi", prn: "PRN2023009", class: "SY-AIML", present: false, paid: true },
    { id: 10, name: "Kavita Reddy", prn: "PRN2023010", class: "SY-AIML", present: false, paid: true },
  ])

  // Available classes for seat assignment
  const availableClasses = [
    "FY-CSE",
    "SY-CSE",
    "TY-CSE",
    "FY-IT",
    "SY-IT",
    "TY-IT",
    "FY-AIML",
    "SY-AIML",
    "TY-AIML",
    "FY-AIDS",
    "SY-AIDS",
    "TY-AIDS",
  ]

  const toggleDepartment = (dept) => {
    setSelectedDepartments((prev) => (prev.includes(dept) ? prev.filter((d) => d !== dept) : [...prev, dept]))
  }

  const handlePosterUpload = () => {
    // In a real app, this would handle file upload
    setPoster("/placeholder.svg?height=300&width=600")
    toast({
      title: "Poster Uploaded",
      description: "Event poster has been uploaded successfully.",
    })
  }

  const toggleAttendance = (id) => {
    setStudents(students.map((student) => (student.id === id ? { ...student, present: !student.present } : student)))
  }

  const submitAttendance = () => {
    const attendedCount = students.filter((s) => s.present).length

    setEvents(events.map((event) => (event.id === 1 ? { ...event, attendedStudents: attendedCount } : event)))

    setShowAttendance(false)
    toast({
      title: "Attendance Submitted",
      description: `Attendance marked for ${attendedCount} students.`,
    })
  }

  const handleSeatSelection = (seatNumber) => {
    if (selectedSeats.includes(seatNumber)) {
      setSelectedSeats(selectedSeats.filter((seat) => seat !== seatNumber))
    } else {
      setSelectedSeats([...selectedSeats, seatNumber])
    }
  }

  const assignSeatsToClass = () => {
    if (!currentAssignClass || selectedSeats.length === 0) {
      toast({
        title: "Error",
        description: "Please select a class and at least one seat",
        variant: "destructive",
      })
      return
    }

    // Update seat assignments
    setSeatAssignments({
      ...seatAssignments,
      [currentAssignClass]: selectedSeats,
    })

    toast({
      title: "Seats Assigned",
      description: `${selectedSeats.length} seats assigned to ${currentAssignClass}`,
    })

    // Clear selection for next assignment
    setSelectedSeats([])
    setCurrentAssignClass("")
  }

  const isSeatAssigned = (seatNumber) => {
    return Object.values(seatAssignments).some((seats) => seats.includes(seatNumber))
  }

  const getSeatClass = (seatNumber) => {
    for (const [className, seats] of Object.entries(seatAssignments)) {
      if (seats.includes(seatNumber)) {
        return className
      }
    }
    return null
  }

  const getFilteredStudents = () => {
    let filtered = [...students]

    // Filter by search query
    if (searchQuery) {
      const query = searchQuery.toLowerCase()
      filtered = filtered.filter(
        (student) =>
          student.name.toLowerCase().includes(query) ||
          student.prn.toLowerCase().includes(query) ||
          student.class.toLowerCase().includes(query),
      )
    }

    return filtered
  }

  const createEvent = () => {
    if (currentStep < 4) {
      setCurrentStep(currentStep + 1)
      return
    }

    if (!title || !description || !date || !time || !venue || !poster || selectedDepartments.length === 0) {
      toast({
        title: "Error",
        description: "Please fill all required fields",
        variant: "destructive",
      })
      return
    }

    const newEvent = {
      id: events.length + 1,
      title,
      description,
      date,
      time,
      venue,
      poster,
      maxParticipants: maxParticipants ? Number.parseInt(maxParticipants) : undefined,
      targetAudience: selectedDepartments,
      onlinePayment: enablePayment,
      paymentAmount,
      registeredStudents: 0,
      paidStudents: 0,
      attendedStudents: 0,
      seatAssignments: seatAssignments,
    }

    setEvents([...events, newEvent])

    // Reset form
    setTitle("")
    setDescription("")
    setDate("")
    setTime("")
    setVenue("")
    setMaxParticipants("")
    setSelectedDepartments([])
    setEnablePayment(false)
    setPaymentAmount("")
    setPoster(null)
    setCurrentStep(1)
    setEventType("")
    setSeatAssignments({})

    setActiveTab("manage")

    toast({
      title: "Success",
      description: "Event created successfully!",
    })
  }

  const eventTypes = [
    { id: "workshop", title: "Workshop", icon: "Workshop" },
    { id: "sports", title: "Sports Event", icon: "Sports" },
    { id: "cultural", title: "Cultural Event", icon: "Cultural" },
    { id: "training", title: "Training", icon: "Training" },
    { id: "technical", title: "Technical", icon: "Technical" },
    { id: "other", title: "Other", icon: "Other" },
  ]

  const renderCreateTab = () => (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div className="flex space-x-1">
          {[1, 2, 3, 4].map((step) => (
            <div
              key={step}
              className={`w-3 h-3 rounded-full ${currentStep >= step ? "bg-purple-600" : "bg-gray-200"}`}
            />
          ))}
        </div>
        <div className="text-sm text-gray-500">Step {currentStep} of 4</div>
      </div>

      <AnimatePresence mode="wait">
        {currentStep === 1 && (
          <motion.div
            key="step1"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="space-y-4"
          >
            <h3 className="text-lg font-medium">Select Event Type</h3>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              {eventTypes.map((type) => (
                <motion.div key={type.id} whileHover={{ scale: 1.03 }} whileTap={{ scale: 0.98 }}>
                  <Card
                    className={`cursor-pointer hover:shadow-md transition-shadow ${
                      eventType === type.id ? "border-2 border-purple-600" : ""
                    }`}
                    onClick={() => setEventType(type.id)}
                  >
                    <CardContent className="p-4 flex flex-col items-center text-center">
                      <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mb-3">
                        <span className="text-purple-600 font-bold">{type.icon.charAt(0)}</span>
                      </div>
                      <h3 className="font-medium">{type.title}</h3>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>

            <div className="flex justify-end pt-4">
              <Button onClick={() => setCurrentStep(2)} disabled={!eventType}>
                Continue <ChevronRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </motion.div>
        )}

        {currentStep === 2 && (
          <motion.div
            key="step2"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="space-y-4"
          >
            <h3 className="text-lg font-medium">Event Details</h3>
            <Card>
              <CardContent className="p-6 space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="title">Event Title *</Label>
                  <Input
                    id="title"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="Enter event title"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description">Description *</Label>
                  <Textarea
                    id="description"
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="Enter event description"
                    className="min-h-[100px]"
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="date">Date *</Label>
                    <Input id="date" type="date" value={date} onChange={(e) => setDate(e.target.value)} />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="time">Time *</Label>
                    <Input id="time" type="time" value={time} onChange={(e) => setTime(e.target.value)} />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="venue">Venue *</Label>
                  <Input
                    id="venue"
                    value={venue}
                    onChange={(e) => setVenue(e.target.value)}
                    placeholder="Enter event venue"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="maxParticipants">Max Participants</Label>
                  <Input
                    id="maxParticipants"
                    type="number"
                    value={maxParticipants}
                    onChange={(e) => setMaxParticipants(e.target.value)}
                    placeholder="Enter max participants (optional)"
                  />
                </div>
              </CardContent>
            </Card>

            <div className="flex justify-between pt-4">
              <Button variant="outline" onClick={() => setCurrentStep(1)}>
                <ChevronLeft className="mr-2 h-4 w-4" /> Back
              </Button>
              <Button onClick={() => setCurrentStep(3)} disabled={!title || !description || !date || !time || !venue}>
                Continue <ChevronRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </motion.div>
        )}

        {currentStep === 3 && (
          <motion.div
            key="step3"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="space-y-4"
          >
            <h3 className="text-lg font-medium">Target Audience & Poster</h3>
            <Card>
              <CardContent className="p-6 space-y-4">
                <div className="space-y-2">
                  <Label>Target Audience *</Label>
                  <div className="flex flex-wrap gap-2">
                    {departments.map((dept) => (
                      <Button
                        key={dept}
                        variant={selectedDepartments.includes(dept) ? "default" : "outline"}
                        size="sm"
                        onClick={() => toggleDepartment(dept)}
                      >
                        {dept}
                      </Button>
                    ))}
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Event Poster *</Label>
                  <div
                    className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center cursor-pointer hover:bg-gray-50 transition-colors"
                    onClick={() => fileInputRef.current?.click()}
                  >
                    {poster ? (
                      <div className="relative">
                        <img
                          src={poster || "/placeholder.svg"}
                          alt="Event Poster"
                          className="max-h-[300px] mx-auto rounded-md"
                        />
                        <Button
                          variant="outline"
                          size="icon"
                          className="absolute top-2 right-2 bg-white"
                          onClick={(e) => {
                            e.stopPropagation()
                            setPoster(null)
                          }}
                        >
                          <X className="h-4 w-4" />
                        </Button>
                      </div>
                    ) : (
                      <>
                        <Upload className="h-10 w-10 text-gray-400 mx-auto mb-4" />
                        <h4 className="text-lg font-medium text-gray-700 mb-1">Upload Poster</h4>
                        <p className="text-gray-500 text-sm mb-4">PNG, JPG, JPEG</p>
                        <Button variant="outline" size="sm">
                          Browse Files
                        </Button>
                      </>
                    )}
                    <input
                      type="file"
                      ref={fileInputRef}
                      onChange={handlePosterUpload}
                      className="hidden"
                      accept="image/*"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="seatAssignment" className="cursor-pointer">
                      Configure Seat Assignments
                    </Label>
                    <Button variant="outline" size="sm" onClick={() => setShowSeatSelection(true)}>
                      Assign Seats
                    </Button>
                  </div>
                  <p className="text-sm text-gray-500">Assign specific seats to different classes for this event</p>

                  {Object.keys(seatAssignments).length > 0 && (
                    <div className="mt-2 p-3 bg-gray-50 rounded-lg">
                      <h4 className="font-medium mb-2">Current Seat Assignments:</h4>
                      <div className="space-y-1">
                        {Object.entries(seatAssignments).map(([className, seats]) => (
                          <div key={className} className="flex justify-between text-sm">
                            <span className="font-medium">{className}:</span>
                            <span>{seats.length} seats</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            <div className="flex justify-between pt-4">
              <Button variant="outline" onClick={() => setCurrentStep(2)}>
                <ChevronLeft className="mr-2 h-4 w-4" /> Back
              </Button>
              <Button onClick={() => setCurrentStep(4)} disabled={selectedDepartments.length === 0 || !poster}>
                Continue <ChevronRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </motion.div>
        )}

        {currentStep === 4 && (
          <motion.div
            key="step4"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="space-y-4"
          >
            <h3 className="text-lg font-medium">Payment & Review</h3>
            <Card>
              <CardContent className="p-6 space-y-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-1">
                    <Label htmlFor="enablePayment">Enable Online Payment</Label>
                    <p className="text-sm text-gray-500">Allow students to pay online for this event</p>
                  </div>
                  <Switch id="enablePayment" checked={enablePayment} onCheckedChange={setEnablePayment} />
                </div>

                {enablePayment && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: "auto" }}
                    className="space-y-2 pt-2"
                  >
                    <Label htmlFor="paymentAmount">Payment Amount (₹)</Label>
                    <div className="relative">
                      <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-500" />
                      <Input
                        id="paymentAmount"
                        type="number"
                        value={paymentAmount}
                        onChange={(e) => setPaymentAmount(e.target.value)}
                        placeholder="Enter amount"
                        className="pl-10"
                      />
                    </div>
                  </motion.div>
                )}

                <div className="border-t pt-4 mt-4">
                  <h4 className="font-medium mb-4">Event Summary</h4>
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-gray-500">Event Type:</span>
                      <span className="font-medium">
                        {eventTypes.find((t) => t.id === eventType)?.title || eventType}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-500">Title:</span>
                      <span className="font-medium">{title}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-500">Date & Time:</span>
                      <span className="font-medium">
                        {date} at {time}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-500">Venue:</span>
                      <span className="font-medium">{venue}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-500">Target Audience:</span>
                      <span className="font-medium">{selectedDepartments.join(", ")}</span>
                    </div>
                    {enablePayment && (
                      <div className="flex justify-between">
                        <span className="text-gray-500">Payment Amount:</span>
                        <span className="font-medium">₹{paymentAmount}</span>
                      </div>
                    )}
                    <div className="flex justify-between">
                      <span className="text-gray-500">Seat Assignments:</span>
                      <span className="font-medium">
                        {Object.keys(seatAssignments).length > 0
                          ? `${Object.keys(seatAssignments).length} classes configured`
                          : "Not configured"}
                      </span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <div className="flex justify-between pt-4">
              <Button variant="outline" onClick={() => setCurrentStep(3)}>
                <ChevronLeft className="mr-2 h-4 w-4" /> Back
              </Button>
              <Button onClick={createEvent} disabled={enablePayment && !paymentAmount}>
                <Check className="mr-2 h-4 w-4" /> Create Event
              </Button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Seat Selection Dialog */}
      <Dialog open={showSeatSelection} onOpenChange={setShowSeatSelection}>
        <DialogContent className="sm:max-w-[800px] max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Seat Assignment</DialogTitle>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <div className="flex items-center justify-between">
              <div className="text-sm text-gray-500">Select seats and assign them to specific classes</div>

              <div className="flex items-center space-x-2">
                <select
                  className="text-sm border rounded p-1"
                  value={currentAssignClass}
                  onChange={(e) => setCurrentAssignClass(e.target.value)}
                >
                  <option value="">Select Class</option>
                  {availableClasses.map((cls) => (
                    <option key={cls} value={cls}>
                      {cls}
                    </option>
                  ))}
                </select>

                <Button
                  size="sm"
                  onClick={assignSeatsToClass}
                  disabled={!currentAssignClass || selectedSeats.length === 0}
                >
                  Assign {selectedSeats.length} Seats
                </Button>
              </div>
            </div>

            <div className="border-t pt-4">
              <div className="text-center mb-4 p-2 bg-gray-100 rounded">
                <div className="text-lg font-bold">STAGE</div>
              </div>

              <div className="space-y-6">
                {/* First row of seats */}
                <div className="flex justify-center space-x-2">
                  {[...Array(10)].map((_, i) => {
                    const seatNumber = i + 1
                    const isSelected = selectedSeats.includes(seatNumber)
                    const isAssigned = isSeatAssigned(seatNumber)
                    const assignedClass = getSeatClass(seatNumber)

                    return (
                      <div
                        key={seatNumber}
                        className={`w-10 h-10 flex items-center justify-center rounded-md cursor-pointer border ${
                          isSelected
                            ? "bg-purple-600 text-white border-purple-700"
                            : isAssigned
                              ? "bg-gray-800 text-white border-gray-900"
                              : "bg-white border-gray-300 hover:bg-gray-100"
                        }`}
                        onClick={() => !isAssigned && handleSeatSelection(seatNumber)}
                        title={assignedClass ? `Assigned to ${assignedClass}` : ""}
                      >
                        {seatNumber}
                      </div>
                    )
                  })}
                </div>

                {/* Second row of seats */}
                <div className="flex justify-center space-x-2">
                  {[...Array(10)].map((_, i) => {
                    const seatNumber = i + 11
                    const isSelected = selectedSeats.includes(seatNumber)
                    const isAssigned = isSeatAssigned(seatNumber)
                    const assignedClass = getSeatClass(seatNumber)

                    return (
                      <div
                        key={seatNumber}
                        className={`w-10 h-10 flex items-center justify-center rounded-md cursor-pointer border ${
                          isSelected
                            ? "bg-purple-600 text-white border-purple-700"
                            : isAssigned
                              ? "bg-gray-800 text-white border-gray-900"
                              : "bg-white border-gray-300 hover:bg-gray-100"
                        }`}
                        onClick={() => !isAssigned && handleSeatSelection(seatNumber)}
                        title={assignedClass ? `Assigned to ${assignedClass}` : ""}
                      >
                        {seatNumber}
                      </div>
                    )
                  })}
                </div>

                {/* Aisle */}
                <div className="text-center text-sm text-gray-500">AISLE</div>

                {/* Third row of seats */}
                <div className="flex justify-center space-x-2">
                  {[...Array(10)].map((_, i) => {
                    const seatNumber = i + 21
                    const isSelected = selectedSeats.includes(seatNumber)
                    const isAssigned = isSeatAssigned(seatNumber)
                    const assignedClass = getSeatClass(seatNumber)

                    return (
                      <div
                        key={seatNumber}
                        className={`w-10 h-10 flex items-center justify-center rounded-md cursor-pointer border ${
                          isSelected
                            ? "bg-purple-600 text-white border-purple-700"
                            : isAssigned
                              ? "bg-gray-800 text-white border-gray-900"
                              : "bg-white border-gray-300 hover:bg-gray-100"
                        }`}
                        onClick={() => !isAssigned && handleSeatSelection(seatNumber)}
                        title={assignedClass ? `Assigned to ${assignedClass}` : ""}
                      >
                        {seatNumber}
                      </div>
                    )
                  })}
                </div>

                {/* Fourth row of seats */}
                <div className="flex justify-center space-x-2">
                  {[...Array(10)].map((_, i) => {
                    const seatNumber = i + 31
                    const isSelected = selectedSeats.includes(seatNumber)
                    const isAssigned = isSeatAssigned(seatNumber)
                    const assignedClass = getSeatClass(seatNumber)

                    return (
                      <div
                        key={seatNumber}
                        className={`w-10 h-10 flex items-center justify-center rounded-md cursor-pointer border ${
                          isSelected
                            ? "bg-purple-600 text-white border-purple-700"
                            : isAssigned
                              ? "bg-gray-800 text-white border-gray-900"
                              : "bg-white border-gray-300 hover:bg-gray-100"
                        }`}
                        onClick={() => !isAssigned && handleSeatSelection(seatNumber)}
                        title={assignedClass ? `Assigned to ${assignedClass}` : ""}
                      >
                        {seatNumber}
                      </div>
                    )
                  })}
                </div>

                {/* Fifth row of seats */}
                <div className="flex justify-center space-x-2">
                  {[...Array(10)].map((_, i) => {
                    const seatNumber = i + 41
                    const isSelected = selectedSeats.includes(seatNumber)
                    const isAssigned = isSeatAssigned(seatNumber)
                    const assignedClass = getSeatClass(seatNumber)

                    return (
                      <div
                        key={seatNumber}
                        className={`w-10 h-10 flex items-center justify-center rounded-md cursor-pointer border ${
                          isSelected
                            ? "bg-purple-600 text-white border-purple-700"
                            : isAssigned
                              ? "bg-gray-800 text-white border-gray-900"
                              : "bg-white border-gray-300 hover:bg-gray-100"
                        }`}
                        onClick={() => !isAssigned && handleSeatSelection(seatNumber)}
                        title={assignedClass ? `Assigned to ${assignedClass}` : ""}
                      >
                        {seatNumber}
                      </div>
                    )
                  })}
                </div>
              </div>

              <div className="mt-6 border-t pt-4">
                <div className="flex justify-between items-center">
                  <div>
                    <h4 className="font-medium">Seat Assignment Legend</h4>
                    <div className="flex items-center mt-2 space-x-4 text-sm">
                      <div className="flex items-center">
                        <div className="w-4 h-4 bg-white border border-gray-300 mr-1"></div>
                        <span>Available</span>
                      </div>
                      <div className="flex items-center">
                        <div className="w-4 h-4 bg-purple-600 mr-1"></div>
                        <span>Selected</span>
                      </div>
                      <div className="flex items-center">
                        <div className="w-4 h-4 bg-gray-800 mr-1"></div>
                        <span>Assigned</span>
                      </div>
                    </div>
                  </div>

                  <Button onClick={() => setShowSeatSelection(false)} variant="outline">
                    Close
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )

  const renderManageTab = () => (
    <div className="space-y-6">
      {events.length === 0 ? (
        <div className="text-center py-12">
          <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Calendar className="h-8 w-8 text-gray-400" />
          </div>
          <h3 className="text-lg font-medium text-gray-900 mb-2">No Events Yet</h3>
          <p className="text-gray-500 mb-4">Create your first event to get started</p>
          <Button onClick={() => setActiveTab("create")}>Create Event</Button>
        </div>
      ) : (
        <div>
          {events.map((event) => (
            <Card key={event.id} className="mb-6">
              <CardContent className="p-0">
                <div className="md:flex">
                  <div className="md:w-1/3">
                    <img
                      src={event.poster || "/placeholder.svg"}
                      alt={event.title}
                      className="w-full h-48 md:h-full object-cover"
                    />
                  </div>
                  <div className="p-6 md:w-2/3">
                    <div className="flex justify-between items-start mb-4">
                      <div>
                        <h3 className="text-xl font-bold mb-1">{event.title}</h3>
                        <div className="flex flex-wrap gap-2 text-sm text-gray-500">
                          <div className="flex items-center">
                            <Calendar className="h-4 w-4 mr-1" />
                            {event.date}
                          </div>
                          <div className="flex items-center">
                            <Clock className="h-4 w-4 mr-1" />
                            {event.time}
                          </div>
                          <div className="flex items-center">
                            <MapPin className="h-4 w-4 mr-1" />
                            {event.venue}
                          </div>
                        </div>
                      </div>
                      <Button
                        variant={showAttendance ? "outline" : "default"}
                        size="sm"
                        onClick={() => setShowAttendance(!showAttendance)}
                      >
                        {showAttendance ? "Cancel" : "Mark Attendance"}
                      </Button>
                    </div>

                    {!showAttendance ? (
                      <>
                        <p className="text-gray-600 mb-4 line-clamp-2">{event.description}</p>

                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                          <div className="bg-purple-50 p-3 rounded-lg">
                            <div className="text-sm text-gray-500">Registered</div>
                            <div className="text-xl font-bold">{event.registeredStudents}</div>
                          </div>
                          <div className="bg-green-50 p-3 rounded-lg">
                            <div className="text-sm text-gray-500">Payments</div>
                            <div className="text-xl font-bold">{event.paidStudents}</div>
                          </div>
                          <div className="bg-blue-50 p-3 rounded-lg">
                            <div className="text-sm text-gray-500">Attended</div>
                            <div className="text-xl font-bold">{event.attendedStudents}</div>
                          </div>
                          <div className="bg-yellow-50 p-3 rounded-lg">
                            <div className="text-sm text-gray-500">Revenue</div>
                            <div className="text-xl font-bold">₹{event.paidStudents * event.paymentAmount}</div>
                          </div>
                        </div>

                        <div className="flex flex-wrap gap-1">
                          {event.targetAudience.map((dept) => (
                            <span key={dept} className="bg-gray-100 text-gray-800 text-xs px-2 py-1 rounded">
                              {dept}
                            </span>
                          ))}
                        </div>

                        {Object.keys(event.seatAssignments || {}).length > 0 && (
                          <div className="mt-4">
                            <Button variant="outline" size="sm" onClick={() => setShowSeatSelection(true)}>
                              <Users className="h-4 w-4 mr-1" />
                              View Seat Assignments
                            </Button>
                          </div>
                        )}
                      </>
                    ) : (
                      <div className="mt-4">
                        <h4 className="font-medium mb-3">Mark Attendance</h4>
                        <div className="bg-yellow-50 p-3 rounded-lg mb-4 text-sm">
                          Check the box next to each student who attended the event.
                        </div>

                        <div className="mb-4">
                          <Input
                            placeholder="Search students by name, PRN, or class..."
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                            className="mb-2"
                          />
                        </div>

                        <div className="border rounded-lg overflow-hidden mb-4">
                          <div className="grid grid-cols-12 bg-gray-100 p-3 text-sm font-medium">
                            <div className="col-span-1">Present</div>
                            <div className="col-span-5">Name</div>
                            <div className="col-span-3">PRN</div>
                            <div className="col-span-2">Class</div>
                            <div className="col-span-1">Payment</div>
                          </div>

                          {getFilteredStudents().map((student) => (
                            <div
                              key={student.id}
                              className="grid grid-cols-12 p-3 text-sm border-t hover:bg-gray-50 cursor-pointer"
                              onClick={() => toggleAttendance(student.id)}
                            >
                              <div className="col-span-1 flex items-center">
                                <div
                                  className={`w-5 h-5 rounded border flex items-center justify-center ${
                                    student.present ? "bg-purple-600 border-purple-600" : "border-gray-300"
                                  }`}
                                >
                                  {student.present && <Check className="h-3 w-3 text-white" />}
                                </div>
                              </div>
                              <div className="col-span-5">{student.name}</div>
                              <div className="col-span-3">{student.prn}</div>
                              <div className="col-span-2">{student.class}</div>
                              <div className="col-span-1">
                                {student.paid ? (
                                  <Badge className="bg-green-100 text-green-800 text-xs px-2 py-1 rounded">Paid</Badge>
                                ) : (
                                  <Badge className="bg-red-100 text-red-800 text-xs px-2 py-1 rounded">Unpaid</Badge>
                                )}
                              </div>
                            </div>
                          ))}
                        </div>

                        <Button onClick={submitAttendance}>Submit Attendance</Button>
                      </div>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  )

  return (
    <div className="p-6 max-w-6xl mx-auto">
      <h1 className="text-2xl font-bold mb-6">Event Management</h1>

      <Tabs defaultValue="create" value={activeTab} onValueChange={setActiveTab} className="mb-6">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="create">Create Event</TabsTrigger>
          <TabsTrigger value="manage">Manage Events</TabsTrigger>
        </TabsList>
        <TabsContent value="create">{renderCreateTab()}</TabsContent>
        <TabsContent value="manage">{renderManageTab()}</TabsContent>
      </Tabs>
    </div>
  )
}
