"use client"

import { useState, useRef } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { ArrowLeft, Upload, FileText, X, Brain, Check, ChevronLeft, ChevronRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/components/ui/use-toast"

// Mock data for classes
const classes = [
  { id: 1, name: "DSY CSE", assignments: 5 },
  { id: 2, name: "FY CSE", assignments: 3 },
  { id: 3, name: "DSY CY", assignments: 4 },
  { id: 4, name: "TY IT", assignments: 2 },
  { id: 5, name: "FY ME", assignments: 6 },
  { id: 6, name: "DSY EE", assignments: 3 },
]

export default function AssignmentsPage() {
  const { toast } = useToast()
  const [selectedClass, setSelectedClass] = useState(null)
  const [creationMode, setCreationMode] = useState(null)
  const [files, setFiles] = useState([])
  const [assignmentText, setAssignmentText] = useState("")
  const [isProcessing, setIsProcessing] = useState(false)
  const [isSubmitted, setIsSubmitted] = useState(false)
  const [currentStep, setCurrentStep] = useState(1)

  const fileInputRef = useRef(null)

  const handleFileUpload = (e) => {
    const uploadedFiles = Array.from(e.target.files)
    setFiles([...files, ...uploadedFiles])
    toast({
      title: "Files Uploaded",
      description: `${uploadedFiles.length} file(s) uploaded successfully.`,
    })
  }

  const removeFile = (index) => {
    const newFiles = [...files]
    newFiles.splice(index, 1)
    setFiles(newFiles)
  }

  const processWithAI = async () => {
    if (files.length === 0) {
      toast({
        title: "Error",
        description: "Please upload files first",
        variant: "destructive",
      })
      return
    }

    setIsProcessing(true)

    // Simulate AI processing with different responses based on file names
    setTimeout(() => {
      let generatedText = ""

      if (files.some((file) => file.name.toLowerCase().includes("data structure"))) {
        generatedText =
          "# Data Structures Assignment\n\n" +
          "## Part 1: Theoretical Questions\n\n" +
          "1. Explain the difference between an AVL tree and a Red-Black tree. Provide examples of when you would choose one over the other.\n" +
          "2. Analyze the time complexity of insertion, deletion, and search operations in a B-tree. How does the degree of the B-tree affect these operations?\n" +
          "3. Compare and contrast hash tables with binary search trees. Discuss scenarios where each would be the optimal choice.\n\n" +
          "## Part 2: Programming Exercises\n\n" +
          "1. Implement a priority queue using a binary heap. Your implementation should include the following operations:\n" +
          "   - insert(element, priority)\n" +
          "   - extractMax()\n" +
          "   - peek()\n" +
          "   - increaseKey(element, newPriority)\n\n" +
          "2. Implement a graph using an adjacency list and write algorithms for:\n" +
          "   - Depth-First Search (DFS)\n" +
          "   - Breadth-First Search (BFS)\n" +
          "   - Detecting cycles in the graph\n\n" +
          "3. Design and implement an efficient algorithm to find the shortest path between two nodes in a weighted graph."
      } else if (files.some((file) => file.name.toLowerCase().includes("database"))) {
        generatedText =
          "# Database Management Systems Assignment\n\n" +
          "## Part 1: SQL Queries\n\n" +
          "1. Write SQL queries to create the following tables with appropriate constraints:\n" +
          "   - Students (student_id, name, email, date_of_birth, department_id)\n" +
          "   - Departments (department_id, department_name, hod_name)\n" +
          "   - Courses (course_id, course_name, credits, department_id)\n" +
          "   - Enrollments (enrollment_id, student_id, course_id, semester, grade)\n\n" +
          "2. Write SQL queries to perform the following operations:\n" +
          "   - List all students enrolled in a specific course\n" +
          "   - Find the average grade for each course\n" +
          "   - Identify students who have not enrolled in any course\n" +
          "   - List departments along with the number of courses offered\n\n" +
          "## Part 2: Normalization\n\n" +
          "1. Consider the following relation: R(A, B, C, D, E) with functional dependencies:\n" +
          "   - A → B\n" +
          "   - B → C\n" +
          "   - D → E\n" +
          "   - A → D\n\n" +
          "   Decompose this relation into 3NF and BCNF. Show all steps.\n\n" +
          "## Part 3: Transaction Management\n\n" +
          "1. Explain the ACID properties with examples.\n" +
          "2. Describe how two-phase locking ensures serializability."
      } else if (files.some((file) => file.name.toLowerCase().includes("algorithm"))) {
        generatedText =
          "# Algorithms Assignment\n\n" +
          "## Part 1: Algorithm Analysis\n\n" +
          "1. Analyze the time and space complexity of the following algorithms:\n" +
          "   - Merge Sort\n" +
          "   - Quick Sort\n" +
          "   - Dijkstra's Algorithm\n" +
          "   - Bellman-Ford Algorithm\n\n" +
          "2. Prove that the average-case time complexity of Quicksort is O(n log n).\n\n" +
          "## Part 2: Dynamic Programming\n\n" +
          "1. Solve the following problems using dynamic programming:\n" +
          "   - 0/1 Knapsack Problem\n" +
          "   - Longest Common Subsequence\n" +
          "   - Matrix Chain Multiplication\n\n" +
          "2. For each problem, provide:\n" +
          "   - A clear problem statement\n" +
          "   - The recursive relation\n" +
          "   - The base cases\n" +
          "   - The implementation (pseudocode or actual code)\n" +
          "   - Time and space complexity analysis\n\n" +
          "## Part 3: NP-Completeness\n\n" +
          "1. Explain what NP-Complete problems are and why they are significant.\n" +
          "2. Prove that the Traveling Salesman Problem is NP-Complete by reducing from the Hamiltonian Cycle problem."
      } else {
        generatedText =
          "# Programming Assignment\n\n" +
          "## Part 1: Object-Oriented Programming\n\n" +
          "1. Design and implement a class hierarchy for a library management system with the following classes:\n" +
          "   - LibraryItem (abstract class)\n" +
          "   - Book (extends LibraryItem)\n" +
          "   - Magazine (extends LibraryItem)\n" +
          "   - DVD (extends LibraryItem)\n" +
          "   - Library (contains a collection of LibraryItems)\n\n" +
          "2. Implement appropriate methods for:\n" +
          "   - Adding items to the library\n" +
          "   - Removing items from the library\n" +
          "   - Checking out items\n" +
          "   - Returning items\n" +
          "   - Searching for items by title, author, or category\n\n" +
          "## Part 2: Exception Handling\n\n" +
          "1. Implement proper exception handling for your library system, including:\n" +
          "   - Custom exceptions for different error scenarios\n" +
          "   - Try-catch blocks in appropriate places\n" +
          "   - Proper error messages for users\n\n" +
          "## Part 3: File I/O\n\n" +
          "1. Extend your library system to:\n" +
          "   - Save the library data to a file\n" +
          "   - Load the library data from a file\n" +
          "   - Generate reports on library usage"
      }

      setAssignmentText(generatedText)
      setIsProcessing(false)
      toast({
        title: "Success",
        description: "Questions generated successfully!",
      })
    }, 3000)
  }

  const handleSubmit = () => {
    setIsSubmitted(true)
    toast({
      title: "Success",
      description: `Assignment created for ${selectedClass?.name}`,
    })
  }

  const handleBackNavigation = () => {
    if (isSubmitted) {
      setIsSubmitted(false)
      setCreationMode(null)
      return
    }
    if (creationMode) {
      setCreationMode(null)
      return
    }
    if (selectedClass) {
      setSelectedClass(null)
      return
    }
  }

  const renderClassSelection = () => (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="space-y-6">
      <h2 className="text-2xl font-bold">Select Class</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
        {classes.map((cls) => (
          <motion.div key={cls.id} whileHover={{ scale: 1.03 }} whileTap={{ scale: 0.98 }}>
            <Card className="cursor-pointer hover:shadow-md transition-shadow" onClick={() => setSelectedClass(cls)}>
              <CardContent className="p-6 flex flex-col items-center text-center">
                <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mb-4">
                  <span className="text-purple-600 font-bold">{cls.name.split(" ")[0]}</span>
                </div>
                <h3 className="font-medium text-lg mb-1">{cls.name}</h3>
                <p className="text-gray-500 text-sm">{cls.assignments} assignments</p>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>
    </motion.div>
  )

  const renderCreationMode = () => (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="space-y-6">
      <div className="flex items-center mb-6">
        <Button variant="ghost" size="icon" className="mr-2" onClick={() => setSelectedClass(null)}>
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <h2 className="text-2xl font-bold">{selectedClass?.name}</h2>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <motion.div whileHover={{ scale: 1.03 }} whileTap={{ scale: 0.98 }}>
          <Card
            className="cursor-pointer hover:shadow-md transition-shadow h-full"
            onClick={() => setCreationMode("manual")}
          >
            <CardContent className="p-6 flex flex-col items-center text-center h-full justify-center py-12">
              <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mb-4">
                <FileText className="h-8 w-8 text-purple-600" />
              </div>
              <h3 className="font-medium text-xl mb-2">Create Manually</h3>
              <p className="text-gray-500">Write your own assignment instructions</p>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div whileHover={{ scale: 1.03 }} whileTap={{ scale: 0.98 }}>
          <Card
            className="cursor-pointer hover:shadow-md transition-shadow h-full bg-gradient-to-br from-purple-50 to-white"
            onClick={() => setCreationMode("ai")}
          >
            <CardContent className="p-6 flex flex-col items-center text-center h-full justify-center py-12">
              <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mb-4">
                <Brain className="h-8 w-8 text-purple-600" />
              </div>
              <h3 className="font-medium text-xl mb-2">Generate with AI</h3>
              <p className="text-gray-500">Let AI create assignment based on your materials</p>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </motion.div>
  )

  const renderAssignmentForm = () => (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="space-y-6">
      <div className="flex items-center mb-6">
        <Button variant="ghost" size="icon" className="mr-2" onClick={() => setCreationMode(null)}>
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <h2 className="text-2xl font-bold">{creationMode === "ai" ? "AI-Assisted Assignment" : "Manual Assignment"}</h2>
      </div>

      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <div className="flex space-x-1">
            {[1, 2, 3].map((step) => (
              <div
                key={step}
                className={`w-3 h-3 rounded-full ${currentStep >= step ? "bg-purple-600" : "bg-gray-200"}`}
              />
            ))}
          </div>
          <div className="text-sm text-gray-500">Step {currentStep} of 3</div>
        </div>

        {currentStep === 1 && (
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="space-y-4"
          >
            <h3 className="text-lg font-medium">Upload Materials</h3>
            <Card>
              <CardContent className="p-6">
                <div
                  className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center cursor-pointer hover:bg-gray-50 transition-colors"
                  onClick={() => fileInputRef.current?.click()}
                >
                  <Upload className="h-10 w-10 text-gray-400 mx-auto mb-4" />
                  <h4 className="text-lg font-medium text-gray-700 mb-1">Upload Files</h4>
                  <p className="text-gray-500 text-sm mb-4">PDF, DOCX, Images</p>
                  <Button variant="outline" size="sm">
                    Browse Files
                  </Button>
                  <input type="file" ref={fileInputRef} onChange={handleFileUpload} className="hidden" multiple />
                </div>

                {files.length > 0 && (
                  <div className="mt-6">
                    <h4 className="font-medium mb-2">Uploaded Files:</h4>
                    <div className="space-y-2">
                      {files.map((file, index) => (
                        <div key={index} className="flex items-center justify-between bg-gray-50 p-3 rounded-md">
                          <div className="flex items-center">
                            <FileText className="h-5 w-5 text-gray-500 mr-2" />
                            <span className="text-sm truncate max-w-xs">{file.name}</span>
                          </div>
                          <Button variant="ghost" size="icon" onClick={() => removeFile(index)}>
                            <X className="h-4 w-4" />
                          </Button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            <div className="flex justify-between pt-4">
              <div></div>
              <Button onClick={() => setCurrentStep(2)}>
                Continue <ChevronRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </motion.div>
        )}

        {currentStep === 2 && (
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="space-y-4"
          >
            <h3 className="text-lg font-medium">
              {creationMode === "ai" ? "Generate Assignment" : "Write Assignment"}
            </h3>
            <Card>
              <CardContent className="p-6">
                {creationMode === "ai" && (
                  <div className="mb-6">
                    <Button className="w-full" onClick={processWithAI} disabled={isProcessing || files.length === 0}>
                      {isProcessing ? (
                        <>
                          <div className="h-4 w-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                          Generating...
                        </>
                      ) : (
                        <>
                          <Brain className="mr-2 h-4 w-4" />
                          Generate Questions
                        </>
                      )}
                    </Button>
                  </div>
                )}

                <Textarea
                  placeholder={
                    creationMode === "ai"
                      ? "AI will generate assignment instructions..."
                      : "Enter assignment instructions..."
                  }
                  value={assignmentText}
                  onChange={(e) => setAssignmentText(e.target.value)}
                  className="min-h-[200px]"
                  disabled={isProcessing}
                />
              </CardContent>
            </Card>

            <div className="flex justify-between pt-4">
              <Button variant="outline" onClick={() => setCurrentStep(1)}>
                <ChevronLeft className="mr-2 h-4 w-4" /> Back
              </Button>
              <Button onClick={() => setCurrentStep(3)} disabled={!assignmentText.trim()}>
                Continue <ChevronRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </motion.div>
        )}

        {currentStep === 3 && (
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="space-y-4"
          >
            <h3 className="text-lg font-medium">Review & Submit</h3>
            <Card>
              <CardContent className="p-6">
                <div className="space-y-4">
                  <div>
                    <h4 className="text-sm font-medium text-gray-500">Class</h4>
                    <p className="font-medium">{selectedClass?.name}</p>
                  </div>

                  <div>
                    <h4 className="text-sm font-medium text-gray-500">Creation Method</h4>
                    <p className="font-medium">{creationMode === "ai" ? "AI-Generated" : "Manual"}</p>
                  </div>

                  <div>
                    <h4 className="text-sm font-medium text-gray-500">Attached Files</h4>
                    <p className="font-medium">{files.length} file(s)</p>
                  </div>

                  <div>
                    <h4 className="text-sm font-medium text-gray-500">Assignment Content</h4>
                    <div className="bg-gray-50 p-4 rounded-md whitespace-pre-wrap text-sm">{assignmentText}</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <div className="flex justify-between pt-4">
              <Button variant="outline" onClick={() => setCurrentStep(2)}>
                <ChevronLeft className="mr-2 h-4 w-4" /> Back
              </Button>
              <Button onClick={handleSubmit}>
                <Check className="mr-2 h-4 w-4" /> Submit Assignment
              </Button>
            </div>
          </motion.div>
        )}
      </div>
    </motion.div>
  )

  const renderSuccess = () => (
    <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} className="text-center py-12">
      <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
        <Check className="h-10 w-10 text-green-600" />
      </div>
      <h2 className="text-2xl font-bold mb-2">Assignment Created!</h2>
      <p className="text-gray-600 mb-8">Your assignment for {selectedClass?.name} has been created successfully.</p>

      <Button
        onClick={() => {
          setSelectedClass(null)
          setCreationMode(null)
          setFiles([])
          setAssignmentText("")
          setIsSubmitted(false)
          setCurrentStep(1)
        }}
      >
        Create Another Assignment
      </Button>
    </motion.div>
  )

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center">
          {(selectedClass || creationMode || isSubmitted) && (
            <Button variant="ghost" size="icon" className="mr-2" onClick={handleBackNavigation}>
              <ArrowLeft className="h-5 w-5" />
            </Button>
          )}
          <h1 className="text-2xl font-bold">Assignments</h1>
        </div>
      </div>

      <AnimatePresence mode="wait">
        {!selectedClass && renderClassSelection()}
        {selectedClass && !creationMode && !isSubmitted && renderCreationMode()}
        {selectedClass && creationMode && !isSubmitted && renderAssignmentForm()}
        {isSubmitted && renderSuccess()}
      </AnimatePresence>
    </div>
  )
}
