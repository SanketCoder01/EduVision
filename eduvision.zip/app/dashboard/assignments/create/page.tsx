"use client"

import type React from "react"

import { useState, useRef } from "react"
import { useRouter } from "next/navigation"
import { ArrowLeft, FileText, Check, X, Paperclip, HelpCircle, FileQuestion } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { useToast } from "@/components/ui/use-toast"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { Checkbox } from "@/components/ui/checkbox"
import { createAssignment, addAssignmentResources } from "@/app/actions/assignment-actions"
import { uploadAssignmentResource } from "@/lib/file-upload"

// Mock data for classes
const classes = [
  { id: "1", name: "DSY CSE", students: 45 },
  { id: "2", name: "FY CSE", students: 60 },
  { id: "3", name: "DSY CY", students: 35 },
  { id: "4", name: "TY IT", students: 50 },
  { id: "5", name: "FY ME", students: 55 },
  { id: "6", name: "DSY EE", students: 40 },
]

export default function CreateAssignmentPage() {
  const { toast } = useToast()
  const router = useRouter()
  const fileInputRef = useRef<HTMLInputElement>(null)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [creationMethod, setCreationMethod] = useState<"manual" | "ai">("manual")
  const [showAIPromptDialog, setShowAIPromptDialog] = useState(false)
  const [aiPrompt, setAIPrompt] = useState("")
  const [isProcessingAI, setIsProcessingAI] = useState(false)

  // Form state
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    classId: "",
    assignmentType: "file_upload",
    allowedFileTypes: ["pdf", "docx", "zip"],
    wordLimit: "",
    startDate: "",
    startTime: "",
    dueDate: "",
    dueTime: "",
    visibility: true,
    allowLateSubmission: false,
    allowResubmission: false,
    enablePlagiarismCheck: true,
    allowGroupSubmission: false,
  })

  // Resources state
  const [resources, setResources] = useState<
    Array<{
      name: string
      fileType: string
      fileUrl: string
      file?: File
      isUploading?: boolean
    }>
  >([])

  // Handle form input changes
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  // Handle select changes
  const handleSelectChange = (name: string, value: string) => {
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  // Handle switch changes
  const handleSwitchChange = (name: string, checked: boolean) => {
    setFormData((prev) => ({ ...prev, [name]: checked }))
  }

  // Handle file types selection
  const handleFileTypeChange = (fileType: string, checked: boolean) => {
    setFormData((prev) => {
      const currentTypes = [...prev.allowedFileTypes]
      if (checked && !currentTypes.includes(fileType)) {
        return { ...prev, allowedFileTypes: [...currentTypes, fileType] }
      } else if (!checked && currentTypes.includes(fileType)) {
        return { ...prev, allowedFileTypes: currentTypes.filter((type) => type !== fileType) }
      }
      return prev
    })
  }

  // Handle resource file upload
  const handleResourceUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (!files || files.length === 0) return

    const newResources = Array.from(files).map((file) => ({
      name: file.name,
      fileType: file.type,
      fileUrl: URL.createObjectURL(file),
      file,
      isUploading: false,
    }))

    setResources((prev) => [...prev, ...newResources])

    // Reset file input
    if (fileInputRef.current) {
      fileInputRef.current.value = ""
    }
  }

  // Remove resource
  const handleRemoveResource = (index: number) => {
    setResources((prev) => prev.filter((_, i) => i !== index))
  }

  // Generate with AI
  const handleGenerateWithAI = async () => {
    if (!aiPrompt.trim()) {
      toast({
        title: "Error",
        description: "Please enter a prompt for the AI",
        variant: "destructive",
      })
      return
    }

    setIsProcessingAI(true)

    // Simulate AI processing
    setTimeout(() => {
      // Generate assignment based on prompt
      let generatedTitle = ""
      let generatedDescription = ""

      if (aiPrompt.toLowerCase().includes("data structure")) {
        generatedTitle = "Advanced Data Structures Implementation"
        generatedDescription =
          "# Data Structures Assignment\n\n" +
          "## Objectives\n\n" +
          "Implement and analyze advanced data structures to solve complex problems.\n\n" +
          "## Requirements\n\n" +
          "1. Implement a self-balancing binary search tree (AVL or Red-Black)\n" +
          "2. Create a priority queue using a binary heap\n" +
          "3. Develop a hash table with collision resolution\n" +
          "4. Analyze the time and space complexity of each implementation\n" +
          "5. Compare the performance of your implementations with standard library versions\n\n" +
          "## Submission Guidelines\n\n" +
          "- Submit source code with comprehensive comments\n" +
          "- Include a report (PDF) with analysis and performance comparisons\n" +
          "- Prepare test cases demonstrating the functionality of each data structure"
      } else if (aiPrompt.toLowerCase().includes("algorithm")) {
        generatedTitle = "Algorithm Design and Analysis"
        generatedDescription =
          "# Algorithms Assignment\n\n" +
          "## Objectives\n\n" +
          "Design, implement, and analyze algorithms for solving computational problems.\n\n" +
          "## Requirements\n\n" +
          "1. Implement three different sorting algorithms\n" +
          "2. Develop a graph algorithm for finding shortest paths\n" +
          "3. Create a dynamic programming solution for the knapsack problem\n" +
          "4. Analyze the time and space complexity of each algorithm\n" +
          "5. Compare the performance of your implementations with different input sizes\n\n" +
          "## Submission Guidelines\n\n" +
          "- Submit source code with comprehensive comments\n" +
          "- Include a report (PDF) with analysis and performance comparisons\n" +
          "- Prepare visualizations of algorithm performance"
      } else if (aiPrompt.toLowerCase().includes("database")) {
        generatedTitle = "Database Design and SQL Implementation"
        generatedDescription =
          "# Database Management Assignment\n\n" +
          "## Objectives\n\n" +
          "Design a relational database and implement SQL queries for data manipulation and analysis.\n\n" +
          "## Requirements\n\n" +
          "1. Design a normalized database schema for a given scenario\n" +
          "2. Create tables with appropriate constraints and relationships\n" +
          "3. Implement complex SQL queries for data retrieval and analysis\n" +
          "4. Develop stored procedures and triggers for business logic\n" +
          "5. Optimize queries for performance\n\n" +
          "## Submission Guidelines\n\n" +
          "- Submit SQL scripts for schema creation and data manipulation\n" +
          "- Include an ER diagram of your database design\n" +
          "- Provide a report explaining your design decisions and query optimizations"
      } else {
        generatedTitle = "Programming Fundamentals Assignment"
        generatedDescription =
          "# Programming Assignment\n\n" +
          "## Objectives\n\n" +
          "Demonstrate understanding of programming fundamentals through practical implementation.\n\n" +
          "## Requirements\n\n" +
          "1. Implement a solution for the given problem using proper programming techniques\n" +
          "2. Apply object-oriented principles in your design\n" +
          "3. Handle edge cases and exceptions appropriately\n" +
          "4. Write clean, well-documented code\n" +
          "5. Create comprehensive test cases\n\n" +
          "## Submission Guidelines\n\n" +
          "- Submit source code with comprehensive comments\n" +
          "- Include a report explaining your approach and design decisions\n" +
          "- Provide test cases and their expected outputs"
      }

      setFormData((prev) => ({
        ...prev,
        title: generatedTitle,
        description: generatedDescription,
      }))

      setIsProcessingAI(false)
      setShowAIPromptDialog(false)

      toast({
        title: "AI Generation Complete",
        description: "Assignment details have been generated based on your prompt.",
      })
    }, 3000)
  }

  // Handle form submission
  const handleSubmit = async () => {
    // Validate form
    if (!formData.title.trim()) {
      toast({
        title: "Error",
        description: "Please enter an assignment title",
        variant: "destructive",
      })
      return
    }

    if (!formData.description.trim()) {
      toast({
        title: "Error",
        description: "Please enter assignment instructions/description",
        variant: "destructive",
      })
      return
    }

    if (!formData.classId) {
      toast({
        title: "Error",
        description: "Please select a class",
        variant: "destructive",
      })
      return
    }

    if (!formData.dueDate) {
      toast({
        title: "Error",
        description: "Please set a due date",
        variant: "destructive",
      })
      return
    }

    setIsSubmitting(true)

    try {
      // Format dates
      const startDateTime =
        formData.startDate && formData.startTime
          ? new Date(`${formData.startDate}T${formData.startTime}`).toISOString()
          : new Date().toISOString()

      const dueDateTime = new Date(`${formData.dueDate}T${formData.dueTime || "23:59"}`).toISOString()

      // Create assignment in Supabase
      const result = await createAssignment({
        title: formData.title,
        description: formData.description,
        facultyId: "faculty-id", // Replace with actual faculty ID from auth
        classId: formData.classId,
        assignmentType: formData.assignmentType,
        allowedFileTypes: formData.allowedFileTypes,
        wordLimit: formData.wordLimit ? Number.parseInt(formData.wordLimit) : undefined,
        startDate: startDateTime,
        dueDate: dueDateTime,
        visibility: formData.visibility,
        allowLateSubmission: formData.allowLateSubmission,
        allowResubmission: formData.allowResubmission,
        enablePlagiarismCheck: formData.enablePlagiarismCheck,
        allowGroupSubmission: formData.allowGroupSubmission,
      })

      if (!result.success) {
        throw new Error("Failed to create assignment")
      }

      const assignmentId = result.data.id

      // Upload resources
      if (resources.length > 0) {
        const uploadedResources = []

        for (const resource of resources) {
          if (resource.file) {
            // Upload file to Supabase Storage
            const uploadResult = await uploadAssignmentResource(resource.file, assignmentId)

            if (!uploadResult.success) {
              throw new Error(`Failed to upload resource: ${resource.name}`)
            }

            uploadedResources.push({
              assignmentId,
              name: resource.name,
              fileType: resource.fileType,
              fileUrl: uploadResult.fileUrl,
            })
          }
        }

        // Add resources to database
        if (uploadedResources.length > 0) {
          const resourceResult = await addAssignmentResources(uploadedResources)

          if (!resourceResult.success) {
            throw new Error("Failed to add resources to assignment")
          }
        }
      }

      toast({
        title: "Success",
        description: "Assignment created successfully!",
      })

      // Redirect to assignments page
      router.push("/dashboard/assignments")
    } catch (error) {
      console.error("Error creating assignment:", error)
      toast({
        title: "Error",
        description: "Failed to create assignment. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  // Get file icon based on type
  const getFileIcon = (fileName: string) => {
    const extension = fileName.split(".").pop()?.toLowerCase() || ""

    switch (extension) {
      case "pdf":
        return <FileText className="h-4 w-4 text-red-500" />
      case "doc":
      case "docx":
        return <FileText className="h-4 w-4 text-blue-500" />
      case "ppt":
      case "pptx":
        return <FileText className="h-4 w-4 text-orange-500" />
      case "jpg":
      case "jpeg":
      case "png":
        return <FileText className="h-4 w-4 text-purple-500" />
      case "zip":
      case "rar":
        return <FileText className="h-4 w-4 text-gray-500" />
      default:
        return <FileText className="h-4 w-4 text-gray-500" />
    }
  }

  return (
    <div className="max-w-4xl mx-auto">
      <div className="flex items-center mb-6">
        <Button variant="ghost" size="icon" className="mr-2" onClick={() => router.push("/dashboard/assignments")}>
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <h1 className="text-2xl font-bold">Create New Assignment</h1>
      </div>

      <Card className="mb-6">
        <CardContent className="p-6">
          <div className="flex flex-col md:flex-row gap-4 mb-6">
            <div className="flex-1">
              <h2 className="text-lg font-medium mb-4">Assignment Method</h2>
              <div className="flex flex-col sm:flex-row gap-3">
                <Button
                  type="button"
                  variant={creationMethod === "manual" ? "default" : "outline"}
                  className={`flex-1 justify-start ${creationMethod === "manual" ? "bg-purple-600 hover:bg-purple-700" : ""}`}
                  onClick={() => setCreationMethod("manual")}
                >
                  <FileText className="mr-2 h-5 w-5" />
                  Create Manually
                </Button>

                <Button
                  type="button"
                  variant={creationMethod === "ai" ? "default" : "outline"}
                  className={`flex-1 justify-start ${creationMethod === "ai" ? "bg-purple-600 hover:bg-purple-700" : ""}`}
                  onClick={() => {
                    setCreationMethod("ai")
                    setShowAIPromptDialog(true)
                  }}
                >
                  <FileQuestion className="mr-2 h-5 w-5" />
                  Generate with AI
                </Button>
              </div>
            </div>

            <div className="flex-1">
              <h2 className="text-lg font-medium mb-4">Select Class</h2>
              <Select value={formData.classId} onValueChange={(value) => handleSelectChange("classId", value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select a class" />
                </SelectTrigger>
                <SelectContent>
                  {classes.map((cls) => (
                    <SelectItem key={cls.id} value={cls.id}>
                      {cls.name} ({cls.students} students)
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-6">
            <div>
              <Label htmlFor="title" className="text-base">
                Assignment Title
              </Label>
              <Input
                id="title"
                name="title"
                value={formData.title}
                onChange={handleInputChange}
                placeholder="Enter assignment title"
                className="mt-1"
              />
            </div>

            <div>
              <Label htmlFor="description" className="text-base">
                Instructions/Description
              </Label>
              <Textarea
                id="description"
                name="description"
                value={formData.description}
                onChange={handleInputChange}
                placeholder="Enter detailed instructions for the assignment"
                className="mt-1 min-h-[200px]"
              />
              <p className="text-xs text-gray-500 mt-1">Supports markdown formatting for better readability</p>
            </div>

            <div>
              <div className="flex items-center justify-between mb-2">
                <Label className="text-base">Resources</Label>
                <Button variant="outline" size="sm" onClick={() => fileInputRef.current?.click()}>
                  <Paperclip className="mr-2 h-4 w-4" />
                  Attach Files
                </Button>
                <input type="file" ref={fileInputRef} className="hidden" onChange={handleResourceUpload} multiple />
              </div>

              {resources.length > 0 ? (
                <div className="space-y-2 border rounded-md p-3">
                  {resources.map((resource, index) => (
                    <div key={index} className="flex items-center justify-between bg-gray-50 p-2 rounded-md">
                      <div className="flex items-center">
                        {getFileIcon(resource.name)}
                        <span className="ml-2 text-sm">{resource.name}</span>
                      </div>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleRemoveResource(index)}
                        className="text-gray-500 h-7 w-7"
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="border border-dashed rounded-md p-6 text-center">
                  <Paperclip className="h-8 w-8 text-gray-400 mx-auto mb-2" />
                  <p className="text-sm text-gray-500">Attach resources like PDFs, documents, or images</p>
                  <Button variant="outline" size="sm" className="mt-2" onClick={() => fileInputRef.current?.click()}>
                    Browse Files
                  </Button>
                </div>
              )}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <Label className="text-base">Assignment Type</Label>
                <Select
                  value={formData.assignmentType}
                  onValueChange={(value) => handleSelectChange("assignmentType", value)}
                >
                  <SelectTrigger className="mt-1">
                    <SelectValue placeholder="Select assignment type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="file_upload">File Upload</SelectItem>
                    <SelectItem value="text_based">Text-based</SelectItem>
                    <SelectItem value="quiz">Quiz</SelectItem>
                    <SelectItem value="coding">Coding</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="wordLimit" className="text-base">
                  Word/Page Limit (Optional)
                </Label>
                <Input
                  id="wordLimit"
                  name="wordLimit"
                  type="number"
                  value={formData.wordLimit}
                  onChange={handleInputChange}
                  placeholder="Enter word limit"
                  className="mt-1"
                />
              </div>
            </div>

            {formData.assignmentType === "file_upload" && (
              <div>
                <Label className="text-base mb-2 block">Allowed File Types</Label>
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2">
                  {["pdf", "docx", "pptx", "xlsx", "zip", "jpg", "png", "txt"].map((type) => (
                    <div key={type} className="flex items-center space-x-2">
                      <Checkbox
                        id={`filetype-${type}`}
                        checked={formData.allowedFileTypes.includes(type)}
                        onCheckedChange={(checked) => handleFileTypeChange(type, checked as boolean)}
                      />
                      <Label htmlFor={`filetype-${type}`} className="text-sm font-normal">
                        .{type}
                      </Label>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <Label className="text-base mb-2 block">Start Date & Time</Label>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <Input type="date" name="startDate" value={formData.startDate} onChange={handleInputChange} />
                  </div>
                  <div>
                    <Input type="time" name="startTime" value={formData.startTime} onChange={handleInputChange} />
                  </div>
                </div>
              </div>

              <div>
                <Label className="text-base mb-2 block">Due Date & Time</Label>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <Input type="date" name="dueDate" value={formData.dueDate} onChange={handleInputChange} required />
                  </div>
                  <div>
                    <Input type="time" name="dueTime" value={formData.dueTime} onChange={handleInputChange} />
                  </div>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <h2 className="text-lg font-medium">Submission Settings</h2>

              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label className="text-base">Visibility</Label>
                    <p className="text-sm text-gray-500">Make assignment visible to students</p>
                  </div>
                  <Switch
                    checked={formData.visibility}
                    onCheckedChange={(checked) => handleSwitchChange("visibility", checked)}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label className="text-base">Allow Late Submission</Label>
                    <p className="text-sm text-gray-500">Students can submit after the deadline</p>
                  </div>
                  <Switch
                    checked={formData.allowLateSubmission}
                    onCheckedChange={(checked) => handleSwitchChange("allowLateSubmission", checked)}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label className="text-base">Allow Resubmission</Label>
                    <p className="text-sm text-gray-500">Students can resubmit their work</p>
                  </div>
                  <Switch
                    checked={formData.allowResubmission}
                    onCheckedChange={(checked) => handleSwitchChange("allowResubmission", checked)}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label className="text-base">Enable Plagiarism Check</Label>
                    <p className="text-sm text-gray-500">Check submissions for plagiarism</p>
                  </div>
                  <Switch
                    checked={formData.enablePlagiarismCheck}
                    onCheckedChange={(checked) => handleSwitchChange("enablePlagiarismCheck", checked)}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label className="text-base">Allow Group Submission</Label>
                    <p className="text-sm text-gray-500">Students can submit as a group</p>
                  </div>
                  <Switch
                    checked={formData.allowGroupSubmission}
                    onCheckedChange={(checked) => handleSwitchChange("allowGroupSubmission", checked)}
                  />
                </div>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-4">
              <Button variant="outline" onClick={() => router.push("/dashboard/assignments")}>
                Cancel
              </Button>
              <Button onClick={handleSubmit} disabled={isSubmitting} className="bg-purple-600 hover:bg-purple-700">
                {isSubmitting ? (
                  <>
                    <div className="h-4 w-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                    Creating...
                  </>
                ) : (
                  <>
                    <Check className="mr-2 h-4 w-4" />
                    Create Assignment
                  </>
                )}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* AI Prompt Dialog */}
      <Dialog open={showAIPromptDialog} onOpenChange={setShowAIPromptDialog}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>Generate Assignment with AI</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <p className="text-sm text-gray-500">
              Describe the assignment you want to create, and our AI will generate the title and instructions for you.
            </p>
            <Textarea
              placeholder="E.g., Create a data structures assignment focusing on binary trees and their applications..."
              value={aiPrompt}
              onChange={(e) => setAIPrompt(e.target.value)}
              className="min-h-[150px]"
            />
            <div className="bg-amber-50 p-3 rounded-md border border-amber-200">
              <div className="flex items-start">
                <HelpCircle className="h-5 w-5 text-amber-500 mr-2 mt-0.5" />
                <div>
                  <h4 className="font-medium text-amber-800 text-sm">Tips for better results</h4>
                  <ul className="text-amber-700 text-xs mt-1 list-disc pl-4 space-y-1">
                    <li>Be specific about the topic and difficulty level</li>
                    <li>Mention any specific concepts you want to include</li>
                    <li>Specify the type of assignment (e.g., coding, essay, problem-solving)</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAIPromptDialog(false)}>
              Cancel
            </Button>
            <Button
              onClick={handleGenerateWithAI}
              disabled={isProcessingAI || !aiPrompt.trim()}
              className="bg-purple-600 hover:bg-purple-700"
            >
              {isProcessingAI ? (
                <>
                  <div className="h-4 w-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                  Generating...
                </>
              ) : (
                <>
                  <FileQuestion className="mr-2 h-4 w-4" />
                  Generate
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
