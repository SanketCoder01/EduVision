"use client"

import { useState, useRef, useEffect } from "react"
import { motion } from "framer-motion"
import {
  Video,
  Calendar,
  Clock,
  Plus,
  X,
  Mic,
  MicOff,
  Camera,
  CameraOff,
  PhoneOff,
  MessageSquare,
  Share2,
  Settings,
  Copy,
  Users,
  UserPlus,
  PenTool,
  BrainCircuit,
  HelpCircle,
  Volume2,
  Volume1,
  VolumeX,
  Eye,
  Languages,
  Play,
  Pause,
  SkipForward,
  SkipBack,
  Bookmark,
  ChevronLeft,
  Link,
  AlertTriangle,
  Award,
  Lightbulb,
  Sparkles,
  Send,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { useToast } from "@/components/ui/use-toast"
import { Badge } from "@/components/ui/badge"
import { Slider } from "@/components/ui/slider"
import { Progress } from "@/components/ui/progress"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export default function VirtualClassroomPage() {
  const { toast } = useToast()
  const [activeTab, setActiveTab] = useState("schedule")
  const [inSession, setInSession] = useState(false)
  const [isMicOn, setIsMicOn] = useState(true)
  const [isCameraOn, setIsCameraOn] = useState(true)
  const [isChatOpen, setIsChatOpen] = useState(false)
  const [isWhiteboardOpen, setIsWhiteboardOpen] = useState(false)
  const [isQuizOpen, setIsQuizOpen] = useState(false)
  const [isDoubtsOpen, setIsDoubtsOpen] = useState(false)
  const [isNotesOpen, setIsNotesOpen] = useState(false)
  const [isTranslationOpen, setIsTranslationOpen] = useState(false)
  const [message, setMessage] = useState("")
  const [joinLink, setJoinLink] = useState("https://meet.eduvision.edu/dsa-123")
  const [showJoinRequests, setShowJoinRequests] = useState(false)
  const [joinRequests, setJoinRequests] = useState([
    { id: 1, name: "Rahul Sharma", email: "rahul.s@student.edu", status: "pending" },
    { id: 2, name: "Priya Patel", email: "priya.p@student.edu", status: "pending" },
  ])
  const [isRecording, setIsRecording] = useState(false)
  const [recordingTime, setRecordingTime] = useState(0)
  const [noiseLevel, setNoiseLevel] = useState(30)
  const [focusScore, setFocusScore] = useState(85)
  const [participationScore, setParticipationScore] = useState({})
  const [selectedLanguage, setSelectedLanguage] = useState("english")
  const [isReplayMode, setIsReplayMode] = useState(false)
  const [replayProgress, setReplayProgress] = useState(0)
  const [replayPlaying, setReplayPlaying] = useState(false)
  const [replayBookmarks, setReplayBookmarks] = useState([
    { id: 1, time: 120, label: "Binary Trees Introduction" },
    { id: 2, time: 540, label: "AVL Tree Rotations" },
    { id: 3, time: 1200, label: "Time Complexity Analysis" },
  ])
  const [whiteboard, setWhiteboard] = useState({
    elements: [],
    currentElement: null,
  })
  const [quiz, setQuiz] = useState({
    active: false,
    question: "Which of the following is NOT a balanced binary tree?",
    options: ["AVL Tree", "Red-Black Tree", "Linked List", "B-Tree"],
    correctAnswer: 2,
    responses: [],
  })
  const [doubts, setDoubts] = useState([
    {
      id: 1,
      student: "Amit Kumar",
      text: "Can you explain the difference between AVL and Red-Black trees again?",
      time: "10:15 AM",
      status: "pending",
    },
    {
      id: 2,
      student: "Sneha Gupta",
      text: "What's the time complexity for deletion in a B-Tree?",
      time: "10:22 AM",
      status: "answered",
    },
  ])
  const [smartNotes, setSmartNotes] = useState({
    generating: false,
    content: `# Data Structures Lecture Notes

## Binary Trees
- A binary tree is a tree data structure in which each node has at most two children
- Properties:
  - Maximum number of nodes at level i is 2^i
  - Maximum number of nodes in a tree of height h is 2^h - 1
  - For n nodes, minimum height is log(n+1)

## Balanced Binary Trees
- AVL Trees: Self-balancing with balance factor of -1, 0, or 1
- Red-Black Trees: Self-balancing with specific coloring rules
- B-Trees: Generalization of binary search trees, used in databases

## Time Complexity
- Search: O(log n) for balanced trees
- Insert: O(log n) for balanced trees
- Delete: O(log n) for balanced trees`,
  })

  // Mock data for classes
  const [classes, setClasses] = useState([
    { id: 1, name: "DSY CSE", assignments: 5 },
    { id: 2, name: "FY CSE", assignments: 3 },
    { id: 3, name: "DSY CY", assignments: 4 },
    { id: 4, name: "TY IT", assignments: 2 },
    { id: 5, name: "FY ME", assignments: 6 },
    { id: 6, name: "DSY EE", assignments: 3 },
  ])

  // Mock scheduled sessions
  const [sessions, setScheduledSessions] = useState([
    {
      id: 1,
      title: "Data Structures and Algorithms",
      description: "Covering binary trees and graph algorithms",
      dateTime: new Date(new Date().setHours(new Date().getHours() + 2)),
      duration: 60,
      repeatOption: "once",
      participants: ["DSY CSE", "DSY IT"],
      meetingUrl: "https://meet.eduvision.edu/dsa-123",
      password: "dsa123",
      aiFeatures: {
        smartNotes: true,
        liveDoubts: true,
        interactiveWhiteboard: true,
        quizMode: true,
        participationTracking: true,
        noiseDetection: true,
        sessionRecording: true,
        focusMonitoring: true,
        translation: false,
      },
    },
    {
      id: 2,
      title: "Database Management Systems",
      description: "SQL queries and normalization",
      dateTime: new Date(new Date().setDate(new Date().getDate() + 1)),
      duration: 90,
      repeatOption: "weekly",
      participants: ["DSY CSE"],
      meetingUrl: "https://meet.eduvision.edu/dbms-456",
      password: "dbms456",
      aiFeatures: {
        smartNotes: true,
        liveDoubts: true,
        interactiveWhiteboard: false,
        quizMode: true,
        participationTracking: true,
        noiseDetection: false,
        sessionRecording: true,
        focusMonitoring: false,
        translation: false,
      },
    },
  ])

  // Mock participants
  const [participants, setParticipants] = useState([
    { id: 1, name: "John Doe", isActive: true, focusScore: 92, participationScore: 85 },
    { id: 2, name: "Jane Smith", isActive: true, focusScore: 78, participationScore: 90 },
    { id: 3, name: "Mike Johnson", isActive: false, focusScore: 0, participationScore: 0 },
    { id: 4, name: "Sarah Williams", isActive: true, focusScore: 95, participationScore: 70 },
    { id: 5, name: "Alex Brown", isActive: true, focusScore: 88, participationScore: 95 },
  ])

  // Mock messages
  const [messages, setMessages] = useState([
    { id: 1, sender: "John Doe", text: "Hello Professor!" },
    { id: 2, sender: "Jane Smith", text: "Can you explain the last concept again?" },
  ])

  // AI features
  const [aiFeatures, setAiFeatures] = useState({
    smartNotes: true,
    liveDoubts: true,
    interactiveWhiteboard: true,
    quizMode: true,
    participationTracking: true,
    noiseDetection: true,
    sessionRecording: true,
    focusMonitoring: true,
    translation: false,
  })

  const canvasRef = useRef(null)
  const chatEndRef = useRef(null)
  const recordingIntervalRef = useRef(null)

  // Scroll to bottom of chat when new messages are added
  useEffect(() => {
    if (chatEndRef.current) {
      chatEndRef.current.scrollIntoView({ behavior: "smooth" })
    }
  }, [messages])

  // Update recording time
  useEffect(() => {
    if (isRecording) {
      recordingIntervalRef.current = setInterval(() => {
        setRecordingTime((prev) => prev + 1)
      }, 1000)
    } else {
      clearInterval(recordingIntervalRef.current)
    }

    return () => clearInterval(recordingIntervalRef.current)
  }, [isRecording])

  // Simulate noise level changes
  useEffect(() => {
    if (inSession) {
      const noiseInterval = setInterval(() => {
        setNoiseLevel(Math.floor(Math.random() * 60) + 10)
      }, 5000)

      return () => clearInterval(noiseInterval)
    }
  }, [inSession])

  // Simulate focus score changes
  useEffect(() => {
    if (inSession) {
      const focusInterval = setInterval(() => {
        setFocusScore(Math.floor(Math.random() * 30) + 70)
      }, 8000)

      return () => clearInterval(focusInterval)
    }
  }, [inSession])

  // Simulate replay progress
  useEffect(() => {
    if (isReplayMode && replayPlaying) {
      const replayInterval = setInterval(() => {
        setReplayProgress((prev) => {
          if (prev >= 100) {
            setReplayPlaying(false)
            return 100
          }
          return prev + 0.5
        })
      }, 200)

      return () => clearInterval(replayInterval)
    }
  }, [isReplayMode, replayPlaying])

  const toggleAIFeature = (feature) => {
    setAiFeatures((prev) => ({
      ...prev,
      [feature]: !prev[feature],
    }))
  }

  const startSession = () => {
    setInSession(true)
    toast({
      title: "Session Started",
      description: "You are now live in the virtual classroom.",
    })
  }

  const endSession = () => {
    setInSession(false)
    setIsRecording(false)
    setRecordingTime(0)
    toast({
      title: "Session Ended",
      description: "Your virtual classroom session has ended.",
    })
  }

  const sendMessage = () => {
    if (message.trim()) {
      setMessages([...messages, { id: messages.length + 1, sender: "You (Faculty)", text: message.trim() }])
      setMessage("")
    }
  }

  const copyJoinLink = () => {
    navigator.clipboard.writeText(joinLink)
    toast({
      title: "Link Copied",
      description: "Meeting link copied to clipboard.",
    })
  }

  const handleJoinRequest = (id, action) => {
    setJoinRequests(
      joinRequests.map((req) =>
        req.id === id ? { ...req, status: action === "accept" ? "accepted" : "rejected" } : req,
      ),
    )

    toast({
      title: action === "accept" ? "Request Accepted" : "Request Rejected",
      description: `The join request has been ${action === "accept" ? "accepted" : "rejected"}.`,
    })
  }

  const toggleRecording = () => {
    if (!isRecording) {
      setIsRecording(true)
      toast({
        title: "Recording Started",
        description: "Session recording has begun.",
      })
    } else {
      setIsRecording(false)
      toast({
        title: "Recording Stopped",
        description: "Session recording has been saved.",
      })
    }
  }

  const handleAnswerDoubt = (id) => {
    setDoubts(
      doubts.map((doubt) =>
        doubt.id === id ? { ...doubt, status: doubt.status === "pending" ? "answered" : "pending" } : doubt,
      ),
    )
  }

  const startQuiz = () => {
    setQuiz({ ...quiz, active: true })
    toast({
      title: "Quiz Started",
      description: "A new quiz question has been sent to all participants.",
    })
  }

  const generateSmartNotes = () => {
    setSmartNotes({ ...smartNotes, generating: true })

    // Simulate AI processing
    setTimeout(() => {
      setSmartNotes({
        generating: false,
        content: smartNotes.content,
      })
      toast({
        title: "Smart Notes Generated",
        description: "AI has generated lecture notes based on the session content.",
      })
    }, 3000)
  }

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`
  }

  const getNoiseLevelIndicator = () => {
    if (noiseLevel < 30) return <Volume1 className="h-5 w-5 text-green-500" />
    if (noiseLevel < 60) return <Volume2 className="h-5 w-5 text-yellow-500" />
    return <VolumeX className="h-5 w-5 text-red-500" />
  }

  const getFocusIndicator = () => {
    if (focusScore > 80) return "bg-green-100 text-green-800"
    if (focusScore > 60) return "bg-yellow-100 text-yellow-800"
    return "bg-red-100 text-red-800"
  }

  const renderScheduleTab = () => (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-bold">Scheduled Sessions</h2>
        <Dialog>
          <DialogTrigger asChild>
            <Button className="bg-purple-600 hover:bg-purple-700">
              <Plus className="mr-2 h-4 w-4" /> Schedule New Session
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[600px]">
            <DialogHeader>
              <DialogTitle>Schedule Virtual Classroom</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="title">Session Title</Label>
                <Input id="title" placeholder="Enter session title" />
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Description</Label>
                <Textarea id="description" placeholder="Enter session description" />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="date">Date</Label>
                  <Input id="date" type="date" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="time">Time</Label>
                  <Input id="time" type="time" />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="duration">Duration (minutes)</Label>
                  <Input id="duration" type="number" defaultValue="60" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="repeat">Repeat</Label>
                  <Select defaultValue="once">
                    <SelectTrigger id="repeat">
                      <SelectValue placeholder="Select frequency" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="once">Once</SelectItem>
                      <SelectItem value="daily">Daily</SelectItem>
                      <SelectItem value="weekly">Weekly</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label>Target Classes</Label>
                <div className="flex flex-wrap gap-2">
                  {classes.map((cls) => (
                    <Button key={cls.id} variant="outline" size="sm">
                      {cls.name}
                    </Button>
                  ))}
                </div>
              </div>

              <div className="space-y-2">
                <Label>AI Features</Label>
                <Card>
                  <CardContent className="p-4 grid grid-cols-2 gap-4">
                    <div className="flex items-center justify-between">
                      <Label htmlFor="smartNotes" className="text-sm flex items-center">
                        <BrainCircuit className="h-4 w-4 mr-2 text-purple-500" />
                        Smart Notes
                      </Label>
                      <Switch
                        id="smartNotes"
                        checked={aiFeatures.smartNotes}
                        onCheckedChange={() => toggleAIFeature("smartNotes")}
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <Label htmlFor="liveDoubts" className="text-sm flex items-center">
                        <HelpCircle className="h-4 w-4 mr-2 text-purple-500" />
                        Live Doubts
                      </Label>
                      <Switch
                        id="liveDoubts"
                        checked={aiFeatures.liveDoubts}
                        onCheckedChange={() => toggleAIFeature("liveDoubts")}
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <Label htmlFor="interactiveWhiteboard" className="text-sm flex items-center">
                        <PenTool className="h-4 w-4 mr-2 text-purple-500" />
                        Interactive Whiteboard
                      </Label>
                      <Switch
                        id="interactiveWhiteboard"
                        checked={aiFeatures.interactiveWhiteboard}
                        onCheckedChange={() => toggleAIFeature("interactiveWhiteboard")}
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <Label htmlFor="quizMode" className="text-sm flex items-center">
                        <Lightbulb className="h-4 w-4 mr-2 text-purple-500" />
                        Quiz Mode
                      </Label>
                      <Switch
                        id="quizMode"
                        checked={aiFeatures.quizMode}
                        onCheckedChange={() => toggleAIFeature("quizMode")}
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <Label htmlFor="participationTracking" className="text-sm flex items-center">
                        <Award className="h-4 w-4 mr-2 text-purple-500" />
                        Participation Tracking
                      </Label>
                      <Switch
                        id="participationTracking"
                        checked={aiFeatures.participationTracking}
                        onCheckedChange={() => toggleAIFeature("participationTracking")}
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <Label htmlFor="noiseDetection" className="text-sm flex items-center">
                        <Volume2 className="h-4 w-4 mr-2 text-purple-500" />
                        Noise Detection
                      </Label>
                      <Switch
                        id="noiseDetection"
                        checked={aiFeatures.noiseDetection}
                        onCheckedChange={() => toggleAIFeature("noiseDetection")}
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <Label htmlFor="sessionRecording" className="text-sm flex items-center">
                        <Video className="h-4 w-4 mr-2 text-purple-500" />
                        Session Recording
                      </Label>
                      <Switch
                        id="sessionRecording"
                        checked={aiFeatures.sessionRecording}
                        onCheckedChange={() => toggleAIFeature("sessionRecording")}
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <Label htmlFor="focusMonitoring" className="text-sm flex items-center">
                        <Eye className="h-4 w-4 mr-2 text-purple-500" />
                        Focus Monitoring
                      </Label>
                      <Switch
                        id="focusMonitoring"
                        checked={aiFeatures.focusMonitoring}
                        onCheckedChange={() => toggleAIFeature("focusMonitoring")}
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <Label htmlFor="translation" className="text-sm flex items-center">
                        <Languages className="h-4 w-4 mr-2 text-purple-500" />
                        Live Translation
                      </Label>
                      <Switch
                        id="translation"
                        checked={aiFeatures.translation}
                        onCheckedChange={() => toggleAIFeature("translation")}
                      />
                    </div>
                  </CardContent>
                </Card>
              </div>

              <div className="flex justify-end">
                <Button
                  className="bg-purple-600 hover:bg-purple-700"
                  onClick={() => {
                    toast({
                      title: "Session Scheduled",
                      description: "Your virtual classroom session has been scheduled.",
                    })
                  }}
                >
                  Schedule Session
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {sessions.map((session) => (
          <motion.div
            key={session.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
            whileHover={{ scale: 1.02 }}
          >
            <Card className="overflow-hidden h-full">
              <CardContent className="p-0 h-full flex flex-col">
                <div className="bg-gradient-to-r from-purple-600 to-purple-800 text-white p-4">
                  <h3 className="font-bold text-lg">{session.title}</h3>
                  <div className="flex items-center text-sm mt-2">
                    <Calendar className="h-4 w-4 mr-1" />
                    <span>{session.dateTime.toLocaleDateString()}</span>
                    <Clock className="h-4 w-4 ml-3 mr-1" />
                    <span>{session.dateTime.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}</span>
                    <span className="ml-3">{session.duration} min</span>
                  </div>
                </div>
                <div className="p-4 flex-1 flex flex-col">
                  <p className="text-gray-600 mb-4">{session.description}</p>
                  <div className="flex flex-wrap gap-1 mb-4">
                    {session.participants.map((participant, index) => (
                      <Badge key={index} variant="outline" className="bg-purple-100 text-purple-800 border-purple-200">
                        {participant}
                      </Badge>
                    ))}
                  </div>

                  <div className="mt-2 mb-4">
                    <div className="flex items-center mb-2">
                      <Link className="h-4 w-4 mr-2 text-purple-600" />
                      <span className="text-sm text-gray-600 mr-2">{session.meetingUrl}</span>
                      <Button variant="ghost" size="sm" className="h-6 p-0" onClick={copyJoinLink}>
                        <Copy className="h-3 w-3" />
                      </Button>
                    </div>
                    <div className="flex flex-wrap gap-1">
                      {Object.entries(session.aiFeatures)
                        .filter(([_, enabled]) => enabled)
                        .map(([feature]) => (
                          <Badge key={feature} variant="outline" className="bg-blue-50 text-blue-700 border-blue-100">
                            {feature === "smartNotes" && <BrainCircuit className="h-3 w-3 mr-1" />}
                            {feature === "liveDoubts" && <HelpCircle className="h-3 w-3 mr-1" />}
                            {feature === "interactiveWhiteboard" && <PenTool className="h-3 w-3 mr-1" />}
                            {feature === "quizMode" && <Lightbulb className="h-3 w-3 mr-1" />}
                            {feature === "participationTracking" && <Award className="h-3 w-3 mr-1" />}
                            {feature === "noiseDetection" && <Volume2 className="h-3 w-3 mr-1" />}
                            {feature === "sessionRecording" && <Video className="h-3 w-3 mr-1" />}
                            {feature === "focusMonitoring" && <Eye className="h-3 w-3 mr-1" />}
                            {feature === "translation" && <Languages className="h-3 w-3 mr-1" />}
                            {feature.replace(/([A-Z])/g, " $1").replace(/^./, (str) => str.toUpperCase())}
                          </Badge>
                        ))}
                    </div>
                  </div>

                  <div className="flex justify-between items-center mt-auto">
                    <div className="text-sm text-gray-500">
                      {session.repeatOption === "once" ? "One-time session" : `Repeats ${session.repeatOption}`}
                    </div>
                    <Button
                      className="bg-purple-600 hover:bg-purple-700"
                      onClick={startSession}
                      disabled={
                        session.dateTime > new Date() &&
                        session.dateTime.getTime() - new Date().getTime() > 10 * 60 * 1000
                      }
                    >
                      {session.dateTime <= new Date() ||
                      session.dateTime.getTime() - new Date().getTime() <= 10 * 60 * 1000
                        ? "Start Session"
                        : "Starts in " +
                          Math.ceil((session.dateTime.getTime() - new Date().getTime()) / (60 * 1000)) +
                          " min"}
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>
    </div>
  )

  const renderLiveSessionTab = () => (
    <div className="space-y-6">
      {!inSession && !isReplayMode ? (
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5 }}
          className="text-center py-12"
        >
          <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Video className="h-8 w-8 text-gray-400" />
          </div>
          <h3 className="text-lg font-medium text-gray-900 mb-2">No Active Session</h3>
          <p className="text-gray-500 mb-4">Start a scheduled session or create a new one</p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Button className="bg-purple-600 hover:bg-purple-700" onClick={startSession}>
              <Video className="mr-2 h-4 w-4" />
              Start Quick Session
            </Button>
            <Button variant="outline" onClick={() => setActiveTab("schedule")}>
              <Calendar className="mr-2 h-4 w-4" />
              View Scheduled Sessions
            </Button>
            <Button variant="outline" onClick={() => setIsReplayMode(true)}>
              <Play className="mr-2 h-4 w-4" />
              View Recorded Sessions
            </Button>
          </div>
        </motion.div>
      ) : isReplayMode ? (
        <div className="space-y-6">
          <div className="flex items-center justify-between mb-4">
            <Button variant="outline" onClick={() => setIsReplayMode(false)}>
              <ChevronLeft className="mr-2 h-4 w-4" />
              Back to Live Session
            </Button>
            <h3 className="text-lg font-medium">Session Replay</h3>
          </div>

          <Card>
            <CardContent className="p-4">
              <div className="aspect-video bg-black rounded-lg relative mb-4">
                <div className="absolute inset-0 flex items-center justify-center">
                  <img
                    src="/placeholder.svg?height=400&width=800"
                    alt="Session Recording"
                    className="max-h-full max-w-full"
                  />
                </div>

                <div className="absolute bottom-4 left-0 right-0 px-4">
                  <div className="bg-black bg-opacity-70 p-3 rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <div className="text-white text-sm">{formatTime(Math.floor(replayProgress * 30))}</div>
                      <div className="text-white text-sm">30:00</div>
                    </div>
                    <Slider
                      value={[replayProgress]}
                      max={100}
                      step={0.1}
                      onValueChange={(value) => setReplayProgress(value[0])}
                      className="mb-4"
                    />
                    <div className="flex items-center justify-center gap-4">
                      <Button variant="ghost" size="icon" className="text-white">
                        <SkipBack className="h-5 w-5" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="text-white"
                        onClick={() => setReplayPlaying(!replayPlaying)}
                      >
                        {replayPlaying ? <Pause className="h-6 w-6" /> : <Play className="h-6 w-6" />}
                      </Button>
                      <Button variant="ghost" size="icon" className="text-white">
                        <SkipForward className="h-5 w-5" />
                      </Button>
                    </div>
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <h4 className="font-medium">Bookmarks & Key Moments</h4>
                <div className="space-y-2">
                  {replayBookmarks.map((bookmark) => (
                    <div
                      key={bookmark.id}
                      className="flex items-center justify-between p-2 hover:bg-gray-100 rounded-md cursor-pointer"
                      onClick={() => {
                        setReplayProgress((bookmark.time / 1800) * 100)
                        setReplayPlaying(true)
                      }}
                    >
                      <div className="flex items-center">
                        <Bookmark className="h-4 w-4 mr-2 text-purple-600" />
                        <span>{bookmark.label}</span>
                      </div>
                      <span className="text-sm text-gray-500">{formatTime(bookmark.time)}</span>
                    </div>
                  ))}
                </div>

                <div className="mt-4">
                  <h4 className="font-medium mb-2">AI-Generated Summary</h4>
                  <Card className="bg-purple-50">
                    <CardContent className="p-3 text-sm">
                      <p>In this session, the professor covered:</p>
                      <ul className="list-disc pl-5 mt-2 space-y-1">
                        <li>Introduction to binary trees and their properties</li>
                        <li>Balanced tree implementations including AVL and Red-Black trees</li>
                        <li>Time complexity analysis for common tree operations</li>
                        <li>Practical applications in database systems</li>
                      </ul>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-4">
            <div className="bg-black rounded-lg aspect-video relative flex items-center justify-center">
              {isCameraOn ? (
                <video
                  className="w-full h-full rounded-lg"
                  poster="/placeholder.svg?height=400&width=800"
                  muted
                  autoPlay
                  playsInline
                />
              ) : (
                <div className="text-white text-center">
                  <Camera className="h-12 w-12 mx-auto mb-2 opacity-50" />
                  <p>Camera is turned off</p>
                </div>
              )}

              {isRecording && (
                <div className="absolute top-4 left-4 flex items-center bg-red-600 text-white px-3 py-1 rounded-full text-sm animate-pulse">
                  <span className="h-2 w-2 bg-white rounded-full mr-2"></span>
                  REC {formatTime(recordingTime)}
                </div>
              )}

              {isWhiteboardOpen && (
                <div className="absolute inset-0 bg-white">
                  <canvas ref={canvasRef} className="w-full h-full" style={{ touchAction: "none" }}></canvas>
                  <div className="absolute top-4 right-4 flex gap-2">
                    <Button variant="outline" size="sm" className="bg-white">
                      <PenTool className="h-4 w-4 mr-1" />
                      Draw
                    </Button>
                    <Button variant="outline" size="sm" className="bg-white">
                      <Sparkles className="h-4 w-4 mr-1" />
                      AI Assist
                    </Button>
                    <Button variant="outline" size="sm" className="bg-white" onClick={() => setIsWhiteboardOpen(false)}>
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              )}

              {isQuizOpen && (
                <div className="absolute inset-0 bg-white bg-opacity-95 flex items-center justify-center">
                  <div className="max-w-md w-full p-6">
                    <h3 className="text-xl font-bold mb-4">Pop Quiz</h3>
                    <p className="mb-4">{quiz.question}</p>
                    <div className="space-y-2">
                      {quiz.options.map((option, index) => (
                        <div
                          key={index}
                          className={`p-3 border rounded-md cursor-pointer ${
                            quiz.correctAnswer === index ? "bg-green-100 border-green-500" : "hover:bg-gray-50"
                          }`}
                        >
                          {option}
                        </div>
                      ))}
                    </div>
                    <div className="flex justify-between mt-6">
                      <Button variant="outline" onClick={() => setIsQuizOpen(false)}>
                        Close
                      </Button>
                      <Button className="bg-purple-600 hover:bg-purple-700">Send to Students</Button>
                    </div>
                  </div>
                </div>
              )}

              <div className="absolute bottom-4 left-0 right-0 flex justify-center gap-2">
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button
                        variant="outline"
                        size="icon"
                        className="bg-gray-800 hover:bg-gray-700 text-white rounded-full"
                        onClick={() => setIsMicOn(!isMicOn)}
                      >
                        {isMicOn ? <Mic className="h-5 w-5" /> : <MicOff className="h-5 w-5" />}
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent>
                      <p>{isMicOn ? "Mute" : "Unmute"}</p>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>

                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button
                        variant="outline"
                        size="icon"
                        className="bg-gray-800 hover:bg-gray-700 text-white rounded-full"
                        onClick={() => setIsCameraOn(!isCameraOn)}
                      >
                        {isCameraOn ? <Camera className="h-5 w-5" /> : <CameraOff className="h-5 w-5" />}
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent>
                      <p>{isCameraOn ? "Turn off camera" : "Turn on camera"}</p>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>

                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button variant="destructive" size="icon" className="rounded-full" onClick={endSession}>
                        <PhoneOff className="h-5 w-5" />
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent>
                      <p>End session</p>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>

                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button
                        variant="outline"
                        size="icon"
                        className={`bg-gray-800 hover:bg-gray-700 text-white rounded-full ${
                          isChatOpen ? "bg-purple-600 hover:bg-purple-700" : ""
                        }`}
                        onClick={() => setIsChatOpen(!isChatOpen)}
                      >
                        <MessageSquare className="h-5 w-5" />
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent>
                      <p>Chat</p>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>

                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button
                        variant="outline"
                        size="icon"
                        className={`bg-gray-800 hover:bg-gray-700 text-white rounded-full ${
                          isWhiteboardOpen ? "bg-purple-600 hover:bg-purple-700" : ""
                        }`}
                        onClick={() => setIsWhiteboardOpen(!isWhiteboardOpen)}
                      >
                        <PenTool className="h-5 w-5" />
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent>
                      <p>Whiteboard</p>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>

                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button
                        variant="outline"
                        size="icon"
                        className={`bg-gray-800 hover:bg-gray-700 text-white rounded-full ${
                          isRecording ? "bg-red-600 hover:bg-red-700" : ""
                        }`}
                        onClick={toggleRecording}
                      >
                        <Video className="h-5 w-5" />
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent>
                      <p>{isRecording ? "Stop recording" : "Start recording"}</p>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>

                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button
                        variant="outline"
                        size="icon"
                        className="bg-gray-800 hover:bg-gray-700 text-white rounded-full"
                      >
                        <Share2 className="h-5 w-5" />
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent>
                      <p>Share screen</p>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>

                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button
                        variant="outline"
                        size="icon"
                        className="bg-gray-800 hover:bg-gray-700 text-white rounded-full"
                      >
                        <Settings className="h-5 w-5" />
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent>
                      <p>Settings</p>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              </div>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
              {participants
                .filter((p) => p.isActive)
                .slice(0, 4)
                .map((participant) => (
                  <div key={participant.id} className="bg-gray-100 rounded-lg aspect-video relative">
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div className="w-12 h-12 bg-gray-300 rounded-full flex items-center justify-center">
                        <span className="text-gray-600 font-medium">
                          {participant.name
                            .split(" ")
                            .map((n) => n[0])
                            .join("")}
                        </span>
                      </div>
                    </div>
                    <div className="absolute bottom-2 left-2 right-2 flex justify-between items-center">
                      <span className="text-xs bg-black bg-opacity-50 text-white px-2 py-1 rounded">
                        {participant.name}
                      </span>
                      <Badge className={getFocusIndicator()}>
                        <Eye className="h-3 w-3 mr-1" />
                        {participant.focusScore}%
                      </Badge>
                    </div>
                  </div>
                ))}
            </div>
          </div>

          <div className="space-y-4">
            <Tabs defaultValue="participants">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="participants" className="text-xs">
                  <Users className="h-4 w-4 mr-1" />
                  <span className="hidden sm:inline">Participants</span>
                </TabsTrigger>
                <TabsTrigger value="ai-tools" className="text-xs">
                  <BrainCircuit className="h-4 w-4 mr-1" />
                  <span className="hidden sm:inline">AI Tools</span>
                </TabsTrigger>
                <TabsTrigger value="doubts" className="text-xs">
                  <HelpCircle className="h-4 w-4 mr-1" />
                  <span className="hidden sm:inline">Doubts</span>
                </TabsTrigger>
                <TabsTrigger value="join" className="text-xs">
                  <UserPlus className="h-4 w-4 mr-1" />
                  <span className="hidden sm:inline">Join</span>
                </TabsTrigger>
              </TabsList>

              <TabsContent value="participants">
                <Card className="h-[calc(100vh-350px)]">
                  <CardContent className="p-4 h-full flex flex-col">
                    <div className="flex justify-between items-center mb-4">
                      <h3 className="font-medium">Participants ({participants.filter((p) => p.isActive).length})</h3>
                      <Badge variant="outline" className="bg-green-50 text-green-700 border-green-100">
                        <Award className="h-3 w-3 mr-1" />
                        Tracking
                      </Badge>
                    </div>
                    <div className="space-y-2 overflow-y-auto flex-1">
                      {participants.map((participant) => (
                        <div
                          key={participant.id}
                          className="flex items-center justify-between p-2 rounded-lg hover:bg-gray-50"
                        >
                          <div className="flex items-center">
                            <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center mr-2">
                              <span className="text-purple-600 text-sm font-medium">
                                {participant.name
                                  .split(" ")
                                  .map((n) => n[0])
                                  .join("")}
                              </span>
                            </div>
                            <div>
                              <span className="text-sm block">{participant.name}</span>
                              <div className="flex items-center">
                                <Badge className={`mr-1 ${getFocusIndicator()}`}>
                                  <Eye className="h-3 w-3 mr-1" />
                                  {participant.focusScore}%
                                </Badge>
                                <Badge className="bg-purple-100 text-purple-800 border-purple-200">
                                  <Award className="h-3 w-3 mr-1" />
                                  {participant.participationScore}%
                                </Badge>
                              </div>
                            </div>
                          </div>
                          <div
                            className={`w-2 h-2 rounded-full ${participant.isActive ? "bg-green-500" : "bg-gray-300"}`}
                          ></div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="ai-tools">
                <Card className="h-[calc(100vh-350px)]">
                  <CardContent className="p-4 h-full flex flex-col">
                    <h3 className="font-medium mb-4">AI-Powered Tools</h3>
                    <div className="grid grid-cols-1 gap-3">
                      <Button
                        variant="outline"
                        className="justify-start h-auto py-3"
                        onClick={() => setIsNotesOpen(!isNotesOpen)}
                      >
                        <div className="flex items-start">
                          <BrainCircuit className="h-5 w-5 mr-3 text-purple-600 mt-0.5" />
                          <div className="text-left">
                            <div className="font-medium">Smart Lecture Notes</div>
                            <p className="text-xs text-gray-500">Generate AI-powered notes from your lecture</p>
                          </div>
                        </div>
                      </Button>

                      <Button
                        variant="outline"
                        className="justify-start h-auto py-3"
                        onClick={() => setIsDoubtsOpen(!isDoubtsOpen)}
                      >
                        <div className="flex items-start">
                          <HelpCircle className="h-5 w-5 mr-3 text-purple-600 mt-0.5" />
                          <div className="text-left">
                            <div className="font-medium">Live Doubt Box</div>
                            <p className="text-xs text-gray-500">View and answer student questions in real-time</p>
                          </div>
                        </div>
                      </Button>

                      <Button
                        variant="outline"
                        className="justify-start h-auto py-3"
                        onClick={() => setIsWhiteboardOpen(!isWhiteboardOpen)}
                      >
                        <div className="flex items-start">
                          <PenTool className="h-5 w-5 mr-3 text-purple-600 mt-0.5" />
                          <div className="text-left">
                            <div className="font-medium">Interactive Whiteboard</div>
                            <p className="text-xs text-gray-500">Use AI-assisted drawing and diagrams</p>
                          </div>
                        </div>
                      </Button>

                      <Button
                        variant="outline"
                        className="justify-start h-auto py-3"
                        onClick={() => setIsQuizOpen(!isQuizOpen)}
                      >
                        <div className="flex items-start">
                          <Lightbulb className="h-5 w-5 mr-3 text-purple-600 mt-0.5" />
                          <div className="text-left">
                            <div className="font-medium">Live Quiz</div>
                            <p className="text-xs text-gray-500">Create and send interactive quizzes</p>
                          </div>
                        </div>
                      </Button>

                      <Button
                        variant="outline"
                        className="justify-start h-auto py-3"
                        onClick={() => setIsTranslationOpen(!isTranslationOpen)}
                      >
                        <div className="flex items-start">
                          <Languages className="h-5 w-5 mr-3 text-purple-600 mt-0.5" />
                          <div className="text-left">
                            <div className="font-medium">Live Translation</div>
                            <p className="text-xs text-gray-500">Translate your lecture in real-time</p>
                          </div>
                        </div>
                      </Button>
                    </div>

                    {isNotesOpen && (
                      <Dialog open={isNotesOpen} onOpenChange={setIsNotesOpen}>
                        <DialogContent className="sm:max-w-[600px]">
                          <DialogHeader>
                            <DialogTitle>Smart Lecture Notes</DialogTitle>
                          </DialogHeader>
                          <div className="space-y-4">
                            {smartNotes.generating ? (
                              <div className="text-center py-8">
                                <div className="w-12 h-12 border-4 border-t-purple-600 border-purple-200 rounded-full animate-spin mx-auto mb-4"></div>
                                <p>Generating smart notes from your lecture...</p>
                              </div>
                            ) : (
                              <div className="prose prose-sm max-w-none">
                                <div
                                  dangerouslySetInnerHTML={{
                                    __html: smartNotes.content
                                      .replace(/\n/g, "<br>")
                                      .replace(/^# (.*$)/gm, "<h1>$1</h1>")
                                      .replace(/^## (.*$)/gm, "<h2>$1</h2>")
                                      .replace(/^- (.*$)/gm, "<li>$1</li>")
                                      .replace(/<li>/g, "<ul><li>")
                                      .replace(/<\/li>\n/g, "</li></ul>"),
                                  }}
                                ></div>
                              </div>
                            )}
                            <div className="flex justify-between">
                              <Button variant="outline">Download Notes</Button>
                              <Button
                                className="bg-purple-600 hover:bg-purple-700"
                                onClick={generateSmartNotes}
                                disabled={smartNotes.generating}
                              >
                                <BrainCircuit className="mr-2 h-4 w-4" />
                                {smartNotes.generating ? "Generating..." : "Regenerate Notes"}
                              </Button>
                            </div>
                          </div>
                        </DialogContent>
                      </Dialog>
                    )}

                    {isDoubtsOpen && (
                      <Dialog open={isDoubtsOpen} onOpenChange={setIsDoubtsOpen}>
                        <DialogContent className="sm:max-w-[600px]">
                          <DialogHeader>
                            <DialogTitle>Live Doubt Box</DialogTitle>
                          </DialogHeader>
                          <div className="space-y-4 max-h-[60vh] overflow-y-auto">
                            {doubts.length === 0 ? (
                              <div className="text-center py-8">
                                <HelpCircle className="h-12 w-12 text-gray-300 mx-auto mb-4" />
                                <p>No doubts from students yet</p>
                              </div>
                            ) : (
                              doubts.map((doubt) => (
                                <Card key={doubt.id} className={doubt.status === "pending" ? "border-blue-300" : ""}>
                                  <CardContent className="p-4">
                                    <div className="flex justify-between items-start mb-2">
                                      <div className="font-medium">{doubt.student}</div>
                                      <Badge variant={doubt.status === "pending" ? "default" : "outline"}>
                                        {doubt.status === "pending" ? "Pending" : "Answered"}
                                      </Badge>
                                    </div>
                                    <p className="text-gray-700 mb-3">{doubt.text}</p>
                                    <div className="flex justify-between items-center">
                                      <div className="text-xs text-gray-500">{doubt.time}</div>
                                      <Button
                                        size="sm"
                                        variant={doubt.status === "pending" ? "default" : "outline"}
                                        className={
                                          doubt.status === "pending" ? "bg-purple-600 hover:bg-purple-700" : ""
                                        }
                                        onClick={() => handleAnswerDoubt(doubt.id)}
                                      >
                                        {doubt.status === "pending" ? "Answer Now" : "Mark as Pending"}
                                      </Button>
                                    </div>
                                  </CardContent>
                                </Card>
                              ))
                            )}
                          </div>
                        </DialogContent>
                      </Dialog>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="doubts">
                <Card className="h-[calc(100vh-350px)]">
                  <CardContent className="p-4 h-full flex flex-col">
                    <div className="flex justify-between items-center mb-4">
                      <h3 className="font-medium">Student Doubts</h3>
                      <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-100">
                        {doubts.filter((d) => d.status === "pending").length} Pending
                      </Badge>
                    </div>
                    <div className="space-y-3 overflow-y-auto flex-1">
                      {doubts.length === 0 ? (
                        <div className="text-center py-8">
                          <HelpCircle className="h-12 w-12 text-gray-300 mx-auto mb-4" />
                          <p>No doubts from students yet</p>
                        </div>
                      ) : (
                        doubts.map((doubt) => (
                          <div
                            key={doubt.id}
                            className={`p-3 rounded-lg border ${
                              doubt.status === "pending" ? "border-blue-300 bg-blue-50" : "border-gray-200"
                            }`}
                          >
                            <div className="flex justify-between items-start mb-1">
                              <div className="font-medium">{doubt.student}</div>
                              <Badge variant={doubt.status === "pending" ? "default" : "outline"}>
                                {doubt.status === "pending" ? "Pending" : "Answered"}
                              </Badge>
                            </div>
                            <p className="text-sm text-gray-700 mb-2">{doubt.text}</p>
                            <div className="flex justify-between items-center">
                              <div className="text-xs text-gray-500">{doubt.time}</div>
                              <Button
                                size="sm"
                                variant={doubt.status === "pending" ? "default" : "outline"}
                                className={doubt.status === "pending" ? "bg-purple-600 hover:bg-purple-700" : ""}
                                onClick={() => handleAnswerDoubt(doubt.id)}
                              >
                                {doubt.status === "pending" ? "Answer" : "Answered"}
                              </Button>
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="join">
                <Card className="h-[calc(100vh-350px)]">
                  <CardContent className="p-4 h-full flex flex-col">
                    <div className="flex justify-between items-center mb-4">
                      <h3 className="font-medium">Join Information</h3>
                      <Button variant="outline" size="sm" onClick={copyJoinLink}>
                        <Copy className="h-4 w-4 mr-1" />
                        Copy
                      </Button>
                    </div>

                    <div className="space-y-4">
                      <div className="p-3 bg-gray-50 rounded-lg break-all">
                        <div className="text-xs text-gray-500 mb-1">Meeting Link</div>
                        <div className="flex items-center">
                          <Link className="h-4 w-4 mr-2 text-purple-600" />
                          <span className="text-sm">{joinLink}</span>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-3">
                        <div className="p-3 bg-gray-50 rounded-lg">
                          <div className="text-xs text-gray-500 mb-1">Meeting ID</div>
                          <div className="text-sm font-medium">123-456-789</div>
                        </div>
                        <div className="p-3 bg-gray-50 rounded-lg">
                          <div className="text-xs text-gray-500 mb-1">Passcode</div>
                          <div className="text-sm font-medium">dsa123</div>
                        </div>
                      </div>

                      <div className="border-t pt-4 mt-2">
                        <div className="flex justify-between items-center mb-3">
                          <h4 className="font-medium">Join Requests</h4>
                          {joinRequests.filter((r) => r.status === "pending").length > 0 && (
                            <Badge className="bg-blue-500">
                              {joinRequests.filter((r) => r.status === "pending").length} New
                            </Badge>
                          )}
                        </div>

                        <div className="space-y-3">
                          {joinRequests.length === 0 ? (
                            <div className="text-center py-4 text-gray-500">
                              <p>No pending join requests</p>
                            </div>
                          ) : (
                            joinRequests.map((request) => (
                              <div
                                key={request.id}
                                className={`p-3 rounded-lg border ${
                                  request.status === "pending"
                                    ? "border-blue-300 bg-blue-50"
                                    : request.status === "accepted"
                                      ? "border-green-300 bg-green-50"
                                      : "border-red-300 bg-red-50"
                                }`}
                              >
                                <div className="flex justify-between items-start">
                                  <div>
                                    <div className="font-medium">{request.name}</div>
                                    <div className="text-xs text-gray-500">{request.email}</div>
                                  </div>
                                  {request.status === "pending" ? (
                                    <div className="flex gap-2">
                                      <Button
                                        size="sm"
                                        variant="outline"
                                        className="bg-green-500 text-white hover:bg-green-600 border-none"
                                        onClick={() => handleJoinRequest(request.id, "accept")}
                                      >
                                        Accept
                                      </Button>
                                      <Button
                                        size="sm"
                                        variant="outline"
                                        className="bg-red-500 text-white hover:bg-red-600 border-none"
                                        onClick={() => handleJoinRequest(request.id, "reject")}
                                      >
                                        Reject
                                      </Button>
                                    </div>
                                  ) : (
                                    <Badge className={request.status === "accepted" ? "bg-green-500" : "bg-red-500"}>
                                      {request.status === "accepted" ? "Accepted" : "Rejected"}
                                    </Badge>
                                  )}
                                </div>
                              </div>
                            ))
                          )}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>

            {isChatOpen && (
              <Card className="h-[calc(100vh-350px)]">
                <CardContent className="p-4 h-full flex flex-col">
                  <div className="flex justify-between items-center mb-4">
                    <h3 className="font-medium">Chat</h3>
                    <Button variant="ghost" size="icon" onClick={() => setIsChatOpen(false)}>
                      <X className="h-4 w-4" />
                    </Button>
                  </div>

                  <div className="flex-1 overflow-y-auto space-y-4 mb-4">
                    {messages.map((msg) => (
                      <div key={msg.id} className="space-y-1">
                        <div className="text-sm font-medium">{msg.sender}</div>
                        <div className="bg-gray-100 p-2 rounded-lg text-sm">{msg.text}</div>
                      </div>
                    ))}
                    <div ref={chatEndRef} />
                  </div>

                  <div className="flex gap-2">
                    <Input
                      placeholder="Type a message..."
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      onKeyDown={(e) => e.key === "Enter" && sendMessage()}
                    />
                    <Button
                      onClick={sendMessage}
                      disabled={!message.trim()}
                      className="bg-purple-600 hover:bg-purple-700"
                    >
                      <Send className="h-4 w-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}

            {!isChatOpen && !isDoubtsOpen && !isNotesOpen && (
              <Card>
                <CardContent className="p-4">
                  <h3 className="font-medium mb-4">Session Metrics</h3>
                  <div className="space-y-4">
                    <div>
                      <div className="flex justify-between mb-1">
                        <div className="text-sm">Noise Level</div>
                        <div className="flex items-center">
                          {getNoiseLevelIndicator()}
                          <span className="text-sm ml-1">{noiseLevel}%</span>
                        </div>
                      </div>
                      <Progress value={noiseLevel} className="h-2" />
                    </div>

                    <div>
                      <div className="flex justify-between mb-1">
                        <div className="text-sm">Average Focus</div>
                        <div className="text-sm">{focusScore}%</div>
                      </div>
                      <Progress value={focusScore} className="h-2" />
                    </div>

                    <div>
                      <div className="flex justify-between mb-1">
                        <div className="text-sm">Participation</div>
                        <div className="text-sm">
                          {participants.filter((p) => p.isActive).length}/{participants.length} students
                        </div>
                      </div>
                      <Progress
                        value={(participants.filter((p) => p.isActive).length / participants.length) * 100}
                        className="h-2"
                      />
                    </div>

                    {isRecording && (
                      <div className="flex items-center justify-between p-2 bg-red-50 rounded-lg border border-red-200">
                        <div className="flex items-center">
                          <div className="h-2 w-2 bg-red-500 rounded-full mr-2 animate-pulse"></div>
                          <span className="text-sm font-medium">Recording</span>
                        </div>
                        <div className="text-sm">{formatTime(recordingTime)}</div>
                      </div>
                    )}

                    {aiFeatures.noiseDetection && noiseLevel > 70 && (
                      <div className="flex items-center p-2 bg-yellow-50 rounded-lg border border-yellow-200">
                        <AlertTriangle className="h-4 w-4 text-yellow-500 mr-2" />
                        <span className="text-sm">High noise level detected</span>
                      </div>
                    )}

                    {aiFeatures.focusMonitoring && focusScore < 60 && (
                      <div className="flex items-center p-2 bg-red-50 rounded-lg border border-red-200">
                        <AlertTriangle className="h-4 w-4 text-red-500 mr-2" />
                        <span className="text-sm">Low student focus detected</span>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      )}
    </div>
  )

  return (
    <div className="p-6 max-w-6xl mx-auto">
      <motion.h1
        className="text-2xl font-bold mb-6 flex items-center"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <Video className="inline-block mr-2 h-6 w-6 text-purple-600" />
        Virtual Classroom
      </motion.h1>

      <Tabs defaultValue="schedule" value={activeTab} onValueChange={setActiveTab} className="mb-6">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger
            value="schedule"
            className="data-[state=active]:bg-purple-100 data-[state=active]:text-purple-700"
          >
            <motion.div
              className="flex items-center"
              whileHover={{ scale: 1.03 }}
              transition={{ type: "spring", stiffness: 400, damping: 10 }}
            >
              <Calendar className="mr-2 h-4 w-4" />
              Scheduled Sessions
            </motion.div>
          </TabsTrigger>
          <TabsTrigger value="live" className="data-[state=active]:bg-purple-100 data-[state=active]:text-purple-700">
            <motion.div
              className="flex items-center"
              whileHover={{ scale: 1.03 }}
              transition={{ type: "spring", stiffness: 400, damping: 10 }}
            >
              <Video className="mr-2 h-4 w-4" />
              Live Session
            </motion.div>
          </TabsTrigger>
        </TabsList>
        <TabsContent value="schedule">{renderScheduleTab()}</TabsContent>
        <TabsContent value="live">{renderLiveSessionTab()}</TabsContent>
      </Tabs>
    </div>
  )
}
