"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { usePathname, useRouter } from "next/navigation"
import {
  Menu,
  User,
  LogOut,
  Home,
  BookOpen,
  Users,
  Calendar,
  Video,
  MessageCircle,
  UserCheck,
  Bell,
  Code,
  ChevronLeft,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const pathname = usePathname()
  const router = useRouter()
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)

  const navigation = [
    { name: "Dashboard", href: "/dashboard", icon: <Home className="h-5 w-5" /> },
    { name: "Assignments", href: "/dashboard/assignments", icon: <BookOpen className="h-5 w-5" /> },
    { name: "Study Groups", href: "/dashboard/study-groups", icon: <Users className="h-5 w-5" /> },
    { name: "Events", href: "/dashboard/events", icon: <Calendar className="h-5 w-5" /> },
    { name: "Virtual Classroom", href: "/dashboard/virtual-classroom", icon: <Video className="h-5 w-5" /> },
    { name: "Student Queries", href: "/dashboard/queries", icon: <MessageCircle className="h-5 w-5" /> },
    { name: "Mentee Meetings", href: "/dashboard/mentee-meetings", icon: <UserCheck className="h-5 w-5" /> },
    { name: "Announcements", href: "/dashboard/announcements", icon: <Bell className="h-5 w-5" /> },
    { name: "Compiler", href: "/dashboard/compiler", icon: <Code className="h-5 w-5" /> },
  ]

  const handleBackNavigation = () => {
    router.back()
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-purple-700 text-white p-4 flex items-center justify-between sticky top-0 z-10">
        <div className="flex items-center">
          {pathname !== "/dashboard" && (
            <Button variant="ghost" size="icon" className="text-white mr-2" onClick={handleBackNavigation}>
              <ChevronLeft className="h-6 w-6" />
            </Button>
          )}
          <Sheet open={isMobileMenuOpen} onOpenChange={setIsMobileMenuOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="text-white md:hidden">
                <Menu className="h-6 w-6" />
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="p-0 w-64 bg-white">
              <div className="p-4 bg-purple-700 text-white">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-purple-600 flex items-center justify-center">
                    <User className="h-6 w-6" />
                  </div>
                  <div>
                    <h3 className="font-medium">Dr. Dhanwate</h3>
                    <p className="text-xs text-purple-200">Faculty of Computer Science</p>
                  </div>
                </div>
              </div>
              <nav className="p-2">
                {navigation.map((item) => (
                  <Link
                    key={item.name}
                    href={item.href}
                    className={`flex items-center gap-3 px-3 py-2 rounded-md text-sm ${
                      pathname === item.href
                        ? "bg-purple-100 text-purple-700 font-medium"
                        : "text-gray-700 hover:bg-gray-100"
                    }`}
                    onClick={() => setIsMobileMenuOpen(false)}
                  >
                    {item.icon}
                    {item.name}
                  </Link>
                ))}
              </nav>
              <div className="border-t mt-4 pt-4 p-2">
                <Link
                  href="/"
                  className="flex items-center gap-3 px-3 py-2 rounded-md text-sm text-red-600 hover:bg-red-50"
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  <LogOut className="h-5 w-5" />
                  Logout
                </Link>
              </div>
            </SheetContent>
          </Sheet>
          <h1 className="text-xl font-bold">EduVision</h1>
        </div>

        <div className="flex items-center gap-2">
          <Link href="/dashboard/profile">
            <Button variant="ghost" size="icon" className="text-white">
              <User className="h-6 w-6" />
            </Button>
          </Link>
        </div>
      </header>

      {/* Navigation bar */}
      <div className="bg-white border-b border-gray-200 overflow-x-auto hidden md:block">
        <div className="container mx-auto px-4">
          <nav className="flex space-x-1">
            {navigation.map((item) => (
              <Link
                key={item.name}
                href={item.href}
                className={`flex flex-col items-center py-3 px-4 text-sm ${
                  pathname === item.href
                    ? "text-purple-700 border-b-2 border-purple-700 font-medium"
                    : "text-gray-600 hover:text-purple-700 hover:bg-purple-50"
                }`}
              >
                {item.icon}
                <span className="mt-1">{item.name}</span>
              </Link>
            ))}
          </nav>
        </div>
      </div>

      {/* Main content */}
      <main className="container mx-auto px-4 py-6">{children}</main>
    </div>
  )
}
