"use client"

import { useState, useRef, useEffect } from "react"
import { motion } from "framer-motion"
import { MessageCircle, Search, Plus, FileText, HelpCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { useToast } from "@/components/ui/use-toast"

export default function StudentQueriesPage() {
  const { toast } = useToast()
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedQuery, setSelectedQuery] = useState(null)
  const [isCreatingQuery, setIsCreatingQuery] = useState(false)
  const [message, setMessage] = useState("")
  const [newQueryType, setNewQueryType] = useState("study")
  const [newQuerySubject, setNewQuerySubject] = useState("")
  const [newQueryTitle, setNewQueryTitle] = useState("")
  const [newQueryMessage, setNewQueryMessage] = useState("")
  const chatEndRef = useRef(null)

  // Mock queries data
  const [queries, setQueries] = useState([
    {
      id: 1,
      type: "study",
      subject: "Data Structures",
      title: "Confusion about Binary Trees",
      status: "answered",
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24 * 2), // 2 days ago
      messages: [
        {
          id: 1,
          senderId: "student",
          text: "I'm having trouble understanding the concept of balanced binary trees. Could you explain the difference between AVL trees and Red-Black trees?",
          timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24 * 2),
        },
        {
          id: 2,
          senderId: "faculty",
          text: "Great question! AVL trees and Red-Black trees are both self-balancing binary search trees, but they have different balancing mechanisms. AVL trees maintain stricter balance (height difference between left and right subtrees is at most 1), which makes them faster for lookups but slower for insertions and deletions due to more rotations. Red-Black trees allow more imbalance but require fewer rotations, making them generally faster for insertions and deletions. Would you like me to explain the specific balancing rules for each?",
          timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24 * 1.5),
        },
        {
          id: 3,
          senderId: "student",
          text: "Yes, that would be helpful. Could you also explain when I should use one over the other?",
          timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24 * 1.5),
        },
        {
          id: 4,
          senderId: "faculty",
          text: "For AVL trees, the balance factor (height of right subtree - height of left subtree) must be -1, 0, or 1. For Red-Black trees, nodes are colored red or black with specific rules: root is black, red nodes can't have red children, and all paths from root to leaves have the same number of black nodes. Use AVL trees when you have more lookups than insertions/deletions (like databases). Use Red-Black trees when you have frequent modifications (like in-memory caches). Red-Black trees are more commonly used in practice (e.g., in C++ STL and Java TreeMap) because they offer good enough search performance with better insertion/deletion performance.",
          timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24),
        },
      ],
    },
    {
      id: 2,
      type: "assignment",
      subject: "Database Management",
      title: "Clarification on Assignment 3",
      status: "pending",
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 5), // 5 hours ago
      messages: [
        {
          id: 1,
          senderId: "student",
          text: "For the third assignment, do we need to implement all the SQL queries or just design the database schema?",
          timestamp: new Date(Date.now() - 1000 * 60 * 60 * 5),
        },
      ],
    },
  ])

  // Scroll to bottom of chat when new messages are added
  useEffect(() => {
    if (chatEndRef.current) {
      chatEndRef.current.scrollIntoView({ behavior: "smooth" })
    }
  }, [selectedQuery])

  const handleSendMessage = () => {
    if (!message.trim() || !selectedQuery) return

    const newMessage = {
      id: selectedQuery.messages.length + 1,
      senderId: "student",
      text: message,
      timestamp: new Date(),
    }

    const updatedQueries = queries.map((query) => {
      if (query.id === selectedQuery.id) {
        return {
          ...query,
          messages: [...query.messages, newMessage],
        }
      }
      return query
    })

    setQueries(updatedQueries)
    setSelectedQuery({
      ...selectedQuery,
      messages: [...selectedQuery.messages, newMessage],
    })
    setMessage("")

    toast({
      title: "Message Sent",
      description: "Your message has been sent to the faculty.",
    })
  }

  const handleCreateQuery = () => {
    if (!newQueryTitle || !newQuerySubject || !newQueryMessage) {
      toast({
        title: "Error",
        description: "Please fill in all fields",
        variant: "destructive",
      })
      return
    }

    const newQuery = {
      id: queries.length + 1,
      type: newQueryType,
      subject: newQuerySubject,
      title: newQueryTitle,
      status: "pending",
      timestamp: new Date(),
      messages: [
        {
          id: 1,
          senderId: "student",
          text: newQueryMessage,
          timestamp: new Date(),
        },
      ],
    }

    setQueries([newQuery, ...queries])
    setIsCreatingQuery(false)
    setNewQueryType("study")
    setNewQuerySubject("")
    setNewQueryTitle("")
    setNewQueryMessage("")

    toast({
      title: "Query Created",
      description: "Your query has been sent to the faculty.",
    })
  }

  const getFilteredQueries = () => {
    if (!searchQuery) return queries

    const query = searchQuery.toLowerCase()
    return queries.filter(
      (q) =>
        q.title.toLowerCase().includes(query) ||
        q.subject.toLowerCase().includes(query) ||
        q.type.toLowerCase().includes(query)
    )
  }

  // Helper function to format timestamp
  const formatTime = (timestamp) => {
    const now = new Date()
    const diff = now - new Date(timestamp)

    // Less than a minute
    if (diff < 60 * 1000) {
      return "Just now"
    }

    // Less than an hour
    if (diff < 60 * 60 * 1000) {
      const minutes = Math.floor(diff / (60 * 1000))
      return `${minutes}m ago`
    }

    // Less than a day
    if (diff < 24 * 60 * 60 * 1000) {
      const hours = Math.floor(diff / (60 * 60 * 1000))
      return `${hours}h ago`
    }

    // Less than a week
    if (diff < 7 * 24 * 60 * 60 * 1000) {
      const days = Math.floor(diff / (24 * 60 * 60 * 1000))
      return `${days}d ago`
    }

    // Format as date
    return timestamp.toLocaleDateString()
  }

  return (
    <div className="max-w-6xl mx-auto">
      <motion.h1
        className="text-2xl font-bold mb-6 flex items-center"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <MessageCircle className="inline-block mr-2 h-6 w-6 text-green-600" />
        My Queries
      </motion.h1>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-1">
          <Card className="h-[calc(100vh-180px)]">
            <CardContent className="p-4 h-full flex flex-col">
              <div className="flex items-center justify-between mb-4">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <Input
                    placeholder="Search queries..."
                    className="pl-10"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
                <Button
                  className="ml-2 bg-green-600 hover:bg-green-700"
                  size="icon"
                  onClick={() => setIsCreatingQuery(true)}
                >
                  <Plus className="h-4 w-4" />
                </Button>
              </div>

              <div className="flex-1 overflow-y-auto space-y-2">
                {getFilteredQueries().length === 0 ? (
                  <div className="text-center py-8 text-gray-500">No queries found</div>
                ) : (
                  getFilteredQueries().map((query) => (
                    <div
                      key={query.id}
                      className={`p-3 rounded-lg cursor-pointer transition-colors ${
                        selectedQuery?.id === query.id
                          ? "bg-green-100"
                          : "hover:bg-gray-100"
                      }`}
                      onClick={() => setSelectedQuery(query)}
                    >
                      <div className="flex justify-between items-start mb-1">
                        <div className="font-medium line-clamp-1">{query.title}</div>
                        <Badge
                          variant={query.status === "pending" ? "default" : "outline"}
                          className={
                            query.status === "pending"
                              ? "bg-yellow-500"
                              : "bg-green-100 text-green-800"
                          }
                        >
                          {query.status === "pending" ? "Pending" : "Answered"}
                        </Badge>
                      </div>
                      <div className="text-sm text-gray-500 flex items-center mb-1">
                        {query.subject}
                      </div>
                      <div className="text-sm text-gray-500 flex items-center justify-between">
                        <div className="flex items-center">
                          {query.type === "study" && <HelpCircle className="h-3 w-3 mr-1 text-green-500" />}
                          {query.type === "assignment" && <FileText className="h-3 w-3 mr-1 text-blue-500" />}
                          {query.type === "other" && <MessageCircle className="h-3 w-3 mr-1 text-orange-500" />}
                          {query.type.charAt(0).toUpperCase() + query.type.slice(1)}
                        </div>
                        <div>{formatTime(query.timestamp)}</div>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </CardContent>\
