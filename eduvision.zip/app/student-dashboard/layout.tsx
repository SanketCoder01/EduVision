"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { usePathname, useRouter } from "next/navigation"
import {
  Menu,
  User,
  LogOut,
  Home,
  BookOpen,
  Users,
  Calendar,
  Video,
  MessageCircle,
  Bell,
  Code,
  ChevronLeft,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"

export default function StudentDashboardLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const pathname = usePathname()
  const router = useRouter()
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)

  const navigation = [
    { name: "Dashboard", href: "/student-dashboard", icon: <Home className="h-5 w-5" /> },
    { name: "Assignments", href: "/student-dashboard/assignments", icon: <BookOpen className="h-5 w-5" /> },
    { name: "Study Groups", href: "/student-dashboard/study-groups", icon: <Users className="h-5 w-5" /> },
    { name: "Virtual Classroom", href: "/student-dashboard/virtual-classroom", icon: <Video className="h-5 w-5" /> },
    { name: "Events", href: "/student-dashboard/events", icon: <Calendar className="h-5 w-5" /> },
    { name: "Queries", href: "/student-dashboard/queries", icon: <MessageCircle className="h-5 w-5" /> },
    { name: "Announcements", href: "/student-dashboard/announcements", icon: <Bell className="h-5 w-5" /> },
    { name: "Compiler", href: "/student-dashboard/compiler", icon: <Code className="h-5 w-5" /> },
  ]

  const handleBackNavigation = () => {
    router.back()
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-green-600 text-white p-4 flex items-center justify-between sticky top-0 z-10">
        <div className="flex items-center">
          {pathname !== "/student-dashboard" && (
            <Button variant="ghost" size="icon" className="text-white mr-2" onClick={handleBackNavigation}>
              <ChevronLeft className="h-6 w-6" />
            </Button>
          )}
          <Sheet open={isMobileMenuOpen} onOpenChange={setIsMobileMenuOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="text-white md:hidden">
                <Menu className="h-6 w-6" />
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="p-0 w-64 bg-white">
              <div className="p-4 bg-green-600 text-white">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-green-500 flex items-center justify-center">
                    <User className="h-6 w-6" />
                  </div>
                  <div>
                    <h3 className="font-medium">Rahul Sharma</h3>
                    <p className="text-xs text-green-200">FY CSE Student</p>
                  </div>
                </div>
              </div>
              <nav className="p-2">
                {navigation.map((item) => (
                  <Link
                    key={item.name}
                    href={item.href}
                    className={`flex items-center gap-3 px-3 py-2 rounded-md text-sm ${
                      pathname === item.href
                        ? "bg-green-100 text-green-700 font-medium"
                        : "text-gray-700 hover:bg-gray-100"
                    }`}
                    onClick={() => setIsMobileMenuOpen(false)}
                  >
                    {item.icon}
                    {item.name}
                  </Link>
                ))}
              </nav>
              <div className="border-t mt-4 pt-4 p-2">
                <Link
                  href="/"
                  className="flex items-center gap-3 px-3 py-2 rounded-md text-sm text-red-600 hover:bg-red-50"
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  <LogOut className="h-5 w-5" />
                  Logout
                </Link>
              </div>
            </SheetContent>
          </Sheet>
          <h1 className="text-xl font-bold">EduVision</h1>
        </div>

        <div className="flex items-center gap-2">
          <Link href="/student-dashboard/profile">
            <Button variant="ghost" size="icon" className="text-white">
              <User className="h-6 w-6" />
            </Button>
          </Link>
        </div>
      </header>

      {/* Navigation bar */}
      <div className="bg-white border-b border-gray-200 overflow-x-auto hidden md:block">
        <div className="container mx-auto px-4">
          <nav className="flex space-x-1">
            {navigation.map((item) => (
              <Link
                key={item.name}
                href={item.href}
                className={`flex flex-col items-center py-3 px-4 text-sm ${
                  pathname === item.href
                    ? "text-green-600 border-b-2 border-green-600 font-medium"
                    : "text-gray-600 hover:text-green-600 hover:bg-green-50"
                }`}
              >
                {item.icon}
                <span className="mt-1">{item.name}</span>
              </Link>
            ))}
          </nav>
        </div>
      </div>

      {/* Main content */}
      <main className="container mx-auto px-4 py-6">{children}</main>
    </div>
  )
}
