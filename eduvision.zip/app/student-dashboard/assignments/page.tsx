"use client"

import { useState, useRef, useEffect } from "react"
import { motion } from "framer-motion"
import {
  BookOpen,
  Calendar,
  Clock,
  FileText,
  Upload,
  Check,
  X,
  Eye,
  AlertTriangle,
  FileCode,
  CloudUpload,
  History,
  MessageSquare,
  Paperclip,
  Shield,
  Info,
  ChevronDown,
  ChevronUp,
  Edit,
  Save,
  RefreshCw,
  ExternalLink,
  AlertCircle,
  File,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { useToast } from "@/components/ui/use-toast"
import { Progress } from "@/components/ui/progress"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

export default function StudentAssignmentsPage() {
  const { toast } = useToast()
  const [activeTab, setActiveTab] = useState("upcoming")
  const [selectedAssignment, setSelectedAssignment] = useState(null)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [uploadedFiles, setUploadedFiles] = useState([])
  const [viewAssignment, setViewAssignment] = useState(null)
  const [submissionText, setSubmissionText] = useState("")
  const [showHistory, setShowHistory] = useState(false)
  const [showFeedback, setShowFeedback] = useState(false)
  const [showPlagiarismReport, setShowPlagiarismReport] = useState(false)
  const fileInputRef = useRef(null)
  const dropAreaRef = useRef(null)
  const [isDragging, setIsDragging] = useState(false)
  const [cloudSource, setCloudSource] = useState("")
  const [submissionType, setSubmissionType] = useState("file")
  const [showNotifications, setShowNotifications] = useState(true)
  const [sortBy, setSortBy] = useState("dueDate")
  const [filterStatus, setFilterStatus] = useState("all")

  // Mock assignments data
  const assignments = [
    {
      id: 1,
      title: "Data Structures Assignment",
      subject: "Data Structures and Algorithms",
      description: "Implement a priority queue using a binary heap and analyze its time complexity.",
      instructions:
        "Your submission should include:\n1. Source code with comments\n2. Time complexity analysis\n3. Test cases demonstrating functionality",
      dueDate: "2023-10-15T23:59:59",
      createdDate: "2023-09-30T10:00:00",
      status: "not_submitted",
      progress: 0,
      allowedFileTypes: [".pdf", ".docx", ".zip", ".java", ".py", ".cpp"],
      maxFileSize: "10MB",
      wordLimit: "1500 words",
      allowResubmission: true,
      resources: [
        { name: "Priority Queue Example", type: "pdf", url: "#" },
        { name: "Heap Implementation Guide", type: "docx", url: "#" },
      ],
      submissionHistory: [],
      plagiarismScore: null,
      grade: null,
      feedback: null,
      rubric: [
        { criterion: "Implementation", maxScore: 40, score: null },
        { criterion: "Analysis", maxScore: 30, score: null },
        { criterion: "Documentation", maxScore: 20, score: null },
        { criterion: "Test Cases", maxScore: 10, score: null },
      ],
    },
    {
      id: 2,
      title: "Database Normalization",
      subject: "Database Management Systems",
      description: "Normalize the given database schema to 3NF and explain your steps.",
      instructions:
        "Analyze the provided database schema and normalize it to 3NF. Explain each step of the normalization process and identify functional dependencies.",
      dueDate: "2023-10-20T23:59:59",
      createdDate: "2023-10-01T14:30:00",
      status: "in_progress",
      progress: 30,
      allowedFileTypes: [".pdf", ".docx"],
      maxFileSize: "5MB",
      wordLimit: "2000 words",
      allowResubmission: true,
      resources: [
        { name: "Database Schema", type: "pdf", url: "#" },
        { name: "Normalization Examples", type: "pdf", url: "#" },
      ],
      submissionHistory: [
        {
          id: 1,
          date: "2023-10-05T15:45:00",
          files: [{ name: "draft_normalization.pdf", size: "1.2MB" }],
          text: "Initial draft with first and second normal forms.",
          status: "saved",
        },
      ],
      plagiarismScore: null,
      grade: null,
      feedback: null,
      rubric: [
        { criterion: "Normalization Process", maxScore: 50, score: null },
        { criterion: "Explanation", maxScore: 30, score: null },
        { criterion: "Functional Dependencies", maxScore: 20, score: null },
      ],
    },
    {
      id: 3,
      title: "Object-Oriented Programming",
      subject: "Programming Fundamentals",
      description: "Design and implement a class hierarchy for a library management system.",
      instructions:
        "Create a complete object-oriented solution for a library management system with classes for books, members, loans, etc. Include proper inheritance, encapsulation, and polymorphism.",
      dueDate: "2023-09-30T23:59:59",
      createdDate: "2023-09-15T09:00:00",
      status: "submitted",
      submissionDate: "2023-09-29T22:30:00",
      progress: 100,
      allowedFileTypes: [".pdf", ".zip", ".java"],
      maxFileSize: "15MB",
      wordLimit: null,
      allowResubmission: false,
      resources: [
        { name: "OOP Design Principles", type: "pdf", url: "#" },
        { name: "UML Diagram Examples", type: "pdf", url: "#" },
      ],
      submissionHistory: [
        {
          id: 1,
          date: "2023-09-25T14:20:00",
          files: [{ name: "library_draft.zip", size: "3.5MB" }],
          text: "",
          status: "saved",
        },
        {
          id: 2,
          date: "2023-09-29T22:30:00",
          files: [{ name: "library_final.zip", size: "4.2MB" }],
          text: "Final submission with all required classes and documentation.",
          status: "submitted",
        },
      ],
      plagiarismScore: 3,
      grade: null,
      feedback: null,
      rubric: [
        { criterion: "Class Design", maxScore: 30, score: null },
        { criterion: "Implementation", maxScore: 40, score: null },
        { criterion: "Documentation", maxScore: 15, score: null },
        { criterion: "Testing", maxScore: 15, score: null },
      ],
    },
    {
      id: 4,
      title: "Network Protocols",
      subject: "Computer Networks",
      description: "Compare and contrast TCP and UDP protocols with examples.",
      instructions:
        "Write a comprehensive comparison of TCP and UDP protocols. Include their characteristics, use cases, advantages, and disadvantages. Provide real-world examples of applications that use each protocol.",
      dueDate: "2023-09-25T23:59:59",
      createdDate: "2023-09-10T11:15:00",
      status: "graded",
      submissionDate: "2023-09-24T20:15:00",
      progress: 100,
      allowedFileTypes: [".pdf", ".docx"],
      maxFileSize: "8MB",
      wordLimit: "2500 words",
      allowResubmission: false,
      resources: [
        { name: "Protocol Specifications", type: "pdf", url: "#" },
        { name: "Network Examples", type: "video", url: "#" },
      ],
      submissionHistory: [
        {
          id: 1,
          date: "2023-09-20T16:40:00",
          files: [{ name: "tcp_udp_draft.docx", size: "1.8MB" }],
          text: "",
          status: "saved",
        },
        {
          id: 2,
          date: "2023-09-24T20:15:00",
          files: [{ name: "tcp_udp_comparison.pdf", size: "2.3MB" }],
          text: "Final submission with all comparisons and examples.",
          status: "submitted",
        },
      ],
      plagiarismScore: 5,
      grade: "A-",
      gradedDate: "2023-10-01T14:20:00",
      feedback:
        "Excellent comparison with clear examples. The analysis of real-world applications is particularly strong. Consider exploring the performance implications in more depth for future assignments.",
      rubric: [
        { criterion: "Understanding of Protocols", maxScore: 40, score: 38 },
        { criterion: "Comparison Quality", maxScore: 30, score: 28 },
        { criterion: "Examples", maxScore: 20, score: 20 },
        { criterion: "Writing Quality", maxScore: 10, score: 9 },
      ],
    },
    {
      id: 5,
      title: "Machine Learning Algorithms",
      subject: "Artificial Intelligence",
      description: "Implement and compare three classification algorithms on the provided dataset.",
      instructions:
        "Use the provided dataset to implement and compare the performance of three different classification algorithms. Include accuracy, precision, recall, and F1 score metrics.",
      dueDate: "2023-10-25T23:59:59",
      createdDate: "2023-10-05T13:00:00",
      status: "late",
      submissionDate: "2023-10-26T01:30:00",
      progress: 100,
      allowedFileTypes: [".pdf", ".ipynb", ".py", ".zip"],
      maxFileSize: "20MB",
      wordLimit: null,
      allowResubmission: false,
      resources: [
        { name: "Dataset", type: "csv", url: "#" },
        { name: "Algorithm Guidelines", type: "pdf", url: "#" },
      ],
      submissionHistory: [
        {
          id: 1,
          date: "2023-10-26T01:30:00",
          files: [
            { name: "ml_classification.ipynb", size: "4.5MB" },
            { name: "report.pdf", size: "3.2MB" },
          ],
          text: "Late submission due to dataset processing issues.",
          status: "submitted",
        },
      ],
      plagiarismScore: 2,
      grade: "B+",
      gradedDate: "2023-11-01T10:45:00",
      feedback:
        "Good implementation and comparison. The late submission affected your grade, but the technical quality is high. The visualization of results is particularly effective.",
      rubric: [
        { criterion: "Implementation", maxScore: 40, score: 36 },
        { criterion: "Analysis", maxScore: 30, score: 28 },
        { criterion: "Metrics Evaluation", maxScore: 20, score: 18 },
        { criterion: "Report Quality", maxScore: 10, score: 9 },
      ],
    },
  ]

  // Calculate time remaining for assignments
  const calculateTimeRemaining = (dueDate) => {
    const now = new Date()
    const due = new Date(dueDate)
    const diff = due - now

    if (diff <= 0) return { expired: true, text: "Expired" }

    const days = Math.floor(diff / (1000 * 60 * 60 * 24))
    const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60))
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60))

    if (days > 0) {
      return {
        expired: false,
        text: `${days}d ${hours}h remaining`,
        urgent: days <= 1,
      }
    } else if (hours > 0) {
      return {
        expired: false,
        text: `${hours}h ${minutes}m remaining`,
        urgent: true,
      }
    } else {
      return {
        expired: false,
        text: `${minutes}m remaining`,
        urgent: true,
      }
    }
  }

  // Handle file upload
  const handleFileUpload = (e) => {
    const files = e.target.files
    if (files && files.length > 0) {
      const newFiles = Array.from(files).map((file) => ({
        name: file.name,
        size: (file.size / (1024 * 1024)).toFixed(2) + " MB",
        type: file.type,
        file: file,
      }))

      setUploadedFiles([...uploadedFiles, ...newFiles])

      toast({
        title: "Files Uploaded",
        description: `${files.length} file(s) have been added to your submission.`,
      })
    }
  }

  // Handle drag and drop
  useEffect(() => {
    const dropArea = dropAreaRef.current

    const handleDragOver = (e) => {
      e.preventDefault()
      setIsDragging(true)
    }

    const handleDragLeave = () => {
      setIsDragging(false)
    }

    const handleDrop = (e) => {
      e.preventDefault()
      setIsDragging(false)

      if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
        const newFiles = Array.from(e.dataTransfer.files).map((file) => ({
          name: file.name,
          size: (file.size / (1024 * 1024)).toFixed(2) + " MB",
          type: file.type,
          file: file,
        }))

        setUploadedFiles([...uploadedFiles, ...newFiles])

        toast({
          title: "Files Uploaded",
          description: `${e.dataTransfer.files.length} file(s) have been added to your submission.`,
        })
      }
    }

    if (dropArea) {
      dropArea.addEventListener("dragover", handleDragOver)
      dropArea.addEventListener("dragleave", handleDragLeave)
      dropArea.addEventListener("drop", handleDrop)

      return () => {
        dropArea.removeEventListener("dragover", handleDragOver)
        dropArea.removeEventListener("dragleave", handleDragLeave)
        dropArea.removeEventListener("drop", handleDrop)
      }
    }
  }, [uploadedFiles, toast])

  // Handle cloud integration
  const handleCloudUpload = (source) => {
    // Simulate cloud upload
    setIsSubmitting(true)

    setTimeout(() => {
      const newFile = {
        name: `document_from_${source.toLowerCase()}.pdf`,
        size: "2.5 MB",
        type: "application/pdf",
        source: source,
      }

      setUploadedFiles([...uploadedFiles, newFile])
      setIsSubmitting(false)
      setCloudSource("")

      toast({
        title: "Cloud File Imported",
        description: `File has been imported from ${source}.`,
      })
    }, 1500)
  }

  // Handle file removal
  const handleRemoveFile = (index) => {
    const newFiles = [...uploadedFiles]
    newFiles.splice(index, 1)
    setUploadedFiles(newFiles)

    toast({
      title: "File Removed",
      description: "The file has been removed from your submission.",
    })
  }

  // Handle submission
  const handleSubmit = () => {
    if (submissionType === "file" && uploadedFiles.length === 0) {
      toast({
        title: "Error",
        description: "Please upload at least one file",
        variant: "destructive",
      })
      return
    }

    if (submissionType === "text" && !submissionText.trim()) {
      toast({
        title: "Error",
        description: "Please enter your submission text",
        variant: "destructive",
      })
      return
    }

    setIsSubmitting(true)

    // Simulate submission and plagiarism check
    setTimeout(() => {
      // Update the assignment status
      const updatedAssignment = { ...selectedAssignment }

      // Create submission history entry
      const submissionEntry = {
        id: updatedAssignment.submissionHistory ? updatedAssignment.submissionHistory.length + 1 : 1,
        date: new Date().toISOString(),
        files: uploadedFiles.map((file) => ({ name: file.name, size: file.size })),
        text: submissionText,
        status: "submitted",
      }

      updatedAssignment.submissionHistory = updatedAssignment.submissionHistory
        ? [...updatedAssignment.submissionHistory, submissionEntry]
        : [submissionEntry]

      updatedAssignment.status = "submitted"
      updatedAssignment.submissionDate = new Date().toISOString()
      updatedAssignment.progress = 100

      // Simulate plagiarism check
      const plagiarismScore = Math.floor(Math.random() * 15)
      updatedAssignment.plagiarismScore = plagiarismScore

      // Show plagiarism warning if score is high
      if (plagiarismScore > 10) {
        toast({
          title: "Plagiarism Warning",
          description: `Your submission has a high similarity score (${plagiarismScore}%). This may be flagged for review.`,
          variant: "destructive",
        })
      }

      setIsSubmitting(false)
      setSelectedAssignment(null)
      setUploadedFiles([])
      setSubmissionText("")

      toast({
        title: "Assignment Submitted",
        description: "Your assignment has been submitted successfully.",
      })

      // Refresh the page after submission
      setTimeout(() => {
        window.location.reload()
      }, 2000)
    }, 3000)
  }

  // Handle save draft
  const handleSaveDraft = () => {
    if (
      submissionType === "file" &&
      uploadedFiles.length === 0 &&
      submissionType === "text" &&
      !submissionText.trim()
    ) {
      toast({
        title: "Error",
        description: "Please add content to save as draft",
        variant: "destructive",
      })
      return
    }

    setIsSubmitting(true)

    // Simulate saving draft
    setTimeout(() => {
      // Update the assignment status
      const updatedAssignment = { ...selectedAssignment }

      // Create submission history entry
      const submissionEntry = {
        id: updatedAssignment.submissionHistory ? updatedAssignment.submissionHistory.length + 1 : 1,
        date: new Date().toISOString(),
        files: uploadedFiles.map((file) => ({ name: file.name, size: file.size })),
        text: submissionText,
        status: "saved",
      }

      updatedAssignment.submissionHistory = updatedAssignment.submissionHistory
        ? [...updatedAssignment.submissionHistory, submissionEntry]
        : [submissionEntry]

      if (updatedAssignment.status === "not_submitted") {
        updatedAssignment.status = "in_progress"
        updatedAssignment.progress = 30
      }

      setIsSubmitting(false)
      setSelectedAssignment(null)
      setUploadedFiles([])
      setSubmissionText("")

      toast({
        title: "Draft Saved",
        description: "Your draft has been saved successfully.",
      })

      // Refresh the page after saving
      setTimeout(() => {
        window.location.reload()
      }, 2000)
    }, 1500)
  }

  // Get assignments by status
  const getAssignmentsByTab = (tab) => {
    const now = new Date()

    switch (tab) {
      case "upcoming":
        return assignments.filter(
          (a) => (a.status === "not_submitted" || a.status === "in_progress") && new Date(a.dueDate) > now,
        )
      case "past":
        return assignments.filter(
          (a) =>
            a.status === "submitted" ||
            a.status === "graded" ||
            a.status === "late" ||
            (a.status === "not_submitted" && new Date(a.dueDate) < now),
        )
      case "graded":
        return assignments.filter((a) => a.status === "graded")
      default:
        return assignments
    }
  }

  // Get status badge
  const getStatusBadge = (status, dueDate) => {
    const now = new Date()
    const due = new Date(dueDate)

    switch (status) {
      case "not_submitted":
        return due < now ? (
          <Badge variant="destructive">Missed</Badge>
        ) : (
          <Badge variant="outline" className="bg-yellow-100 text-yellow-800">
            Not Submitted
          </Badge>
        )
      case "in_progress":
        return (
          <Badge variant="outline" className="bg-blue-100 text-blue-800">
            In Progress
          </Badge>
        )
      case "submitted":
        return (
          <Badge variant="outline" className="bg-green-100 text-green-800">
            Submitted
          </Badge>
        )
      case "late":
        return (
          <Badge variant="outline" className="bg-orange-100 text-orange-800">
            Late Submission
          </Badge>
        )
      case "graded":
        return (
          <Badge variant="outline" className="bg-purple-100 text-purple-800">
            Graded
          </Badge>
        )
      default:
        return <Badge variant="outline">Unknown</Badge>
    }
  }

  // Get file icon based on type
  const getFileIcon = (fileName) => {
    const extension = fileName.split(".").pop().toLowerCase()

    switch (extension) {
      case "pdf":
        return <FileText className="h-4 w-4 text-red-500" />
      case "doc":
      case "docx":
        return <FileText className="h-4 w-4 text-blue-500" />
      case "xls":
      case "xlsx":
        return <FileText className="h-4 w-4 text-green-500" />
      case "ppt":
      case "pptx":
        return <FileText className="h-4 w-4 text-orange-500" />
      case "jpg":
      case "jpeg":
      case "png":
      case "gif":
        return <FileText className="h-4 w-4 text-purple-500" />
      case "zip":
      case "rar":
        return <FileText className="h-4 w-4 text-gray-500" />
      case "py":
      case "java":
      case "js":
      case "html":
      case "css":
      case "cpp":
        return <FileCode className="h-4 w-4 text-teal-500" />
      default:
        return <File className="h-4 w-4 text-gray-500" />
    }
  }

  // Calculate total grade
  const calculateTotalGrade = (rubric) => {
    if (!rubric || rubric.some((item) => item.score === null)) return null

    const totalScore = rubric.reduce((sum, item) => sum + item.score, 0)
    const maxScore = rubric.reduce((sum, item) => sum + item.maxScore, 0)

    return {
      score: totalScore,
      maxScore: maxScore,
      percentage: Math.round((totalScore / maxScore) * 100),
    }
  }

  // Sort assignments
  const sortAssignments = (assignments) => {
    return [...assignments].sort((a, b) => {
      switch (sortBy) {
        case "dueDate":
          return new Date(a.dueDate) - new Date(b.dueDate)
        case "title":
          return a.title.localeCompare(b.title)
        case "subject":
          return a.subject.localeCompare(b.subject)
        case "status":
          return a.status.localeCompare(b.status)
        default:
          return new Date(a.dueDate) - new Date(b.dueDate)
      }
    })
  }

  // Filter assignments
  const filterAssignments = (assignments) => {
    if (filterStatus === "all") return assignments
    return assignments.filter((a) => a.status === filterStatus)
  }

  // Get filtered and sorted assignments
  const getFilteredAndSortedAssignments = (tab) => {
    const assignmentsByTab = getAssignmentsByTab(tab)
    const filteredAssignments = filterAssignments(assignmentsByTab)
    return sortAssignments(filteredAssignments)
  }

  return (
    <div className="max-w-6xl mx-auto">
      <motion.div
        className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-6"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <h1 className="text-2xl font-bold flex items-center">
          <BookOpen className="inline-block mr-2 h-6 w-6 text-green-600" />
          My Assignments
        </h1>

        <div className="flex flex-col sm:flex-row gap-2">
          <Select value={sortBy} onValueChange={setSortBy}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Sort by" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="dueDate">Sort by Due Date</SelectItem>
              <SelectItem value="title">Sort by Title</SelectItem>
              <SelectItem value="subject">Sort by Subject</SelectItem>
              <SelectItem value="status">Sort by Status</SelectItem>
            </SelectContent>
          </Select>

          <Select value={filterStatus} onValueChange={setFilterStatus}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Filter by status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Statuses</SelectItem>
              <SelectItem value="not_submitted">Not Submitted</SelectItem>
              <SelectItem value="in_progress">In Progress</SelectItem>
              <SelectItem value="submitted">Submitted</SelectItem>
              <SelectItem value="late">Late</SelectItem>
              <SelectItem value="graded">Graded</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </motion.div>

      {/* Notifications */}
      {showNotifications && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="mb-6"
        >
          <Alert className="bg-amber-50 border-amber-200">
            <AlertCircle className="h-4 w-4 text-amber-600" />
            <AlertTitle className="text-amber-800">Upcoming Deadlines</AlertTitle>
            <AlertDescription className="text-amber-700">
              You have{" "}
              {
                assignments.filter(
                  (a) =>
                    (a.status === "not_submitted" || a.status === "in_progress") &&
                    new Date(a.dueDate) > new Date() &&
                    (new Date(a.dueDate) - new Date()) / (1000 * 60 * 60 * 24) <= 3,
                ).length
              }{" "}
              assignments due in the next 3 days.
            </AlertDescription>
            <Button
              variant="outline"
              size="sm"
              className="mt-2 bg-white border-amber-200 text-amber-800 hover:bg-amber-100"
              onClick={() => setShowNotifications(false)}
            >
              Dismiss
            </Button>
          </Alert>
        </motion.div>
      )}

      <Tabs defaultValue="upcoming" value={activeTab} onValueChange={setActiveTab} className="mb-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="upcoming" className="data-[state=active]:bg-green-100 data-[state=active]:text-green-700">
            <motion.div
              className="flex items-center"
              whileHover={{ scale: 1.03 }}
              transition={{ type: "spring", stiffness: 400, damping: 10 }}
            >
              <Calendar className="mr-2 h-4 w-4" />
              Upcoming
              {getAssignmentsByTab("upcoming").length > 0 && (
                <Badge variant="outline" className="ml-2 bg-green-50 text-green-700">
                  {getAssignmentsByTab("upcoming").length}
                </Badge>
              )}
            </motion.div>
          </TabsTrigger>
          <TabsTrigger value="past" className="data-[state=active]:bg-blue-100 data-[state=active]:text-blue-700">
            <motion.div
              className="flex items-center"
              whileHover={{ scale: 1.03 }}
              transition={{ type: "spring", stiffness: 400, damping: 10 }}
            >
              <History className="mr-2 h-4 w-4" />
              Past
            </motion.div>
          </TabsTrigger>
          <TabsTrigger value="graded" className="data-[state=active]:bg-purple-100 data-[state=active]:text-purple-700">
            <motion.div
              className="flex items-center"
              whileHover={{ scale: 1.03 }}
              transition={{ type: "spring", stiffness: 400, damping: 10 }}
            >
              <Check className="mr-2 h-4 w-4" />
              Graded
              {getAssignmentsByTab("graded").length > 0 && (
                <Badge variant="outline" className="ml-2 bg-purple-50 text-purple-700">
                  {getAssignmentsByTab("graded").length}
                </Badge>
              )}
            </motion.div>
          </TabsTrigger>
        </TabsList>

        {["upcoming", "past", "graded"].map((tab) => (
          <TabsContent key={tab} value={tab}>
            <div className="space-y-4">
              {getFilteredAndSortedAssignments(tab).length === 0 ? (
                <div className="text-center py-12 bg-gray-50 rounded-lg">
                  <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    {tab === "upcoming" ? (
                      <Calendar className="h-8 w-8 text-gray-400" />
                    ) : tab === "past" ? (
                      <History className="h-8 w-8 text-gray-400" />
                    ) : (
                      <Check className="h-8 w-8 text-gray-400" />
                    )}
                  </div>
                  <h3 className="text-lg font-medium text-gray-900 mb-2">No {tab} assignments</h3>
                  <p className="text-gray-500">
                    {tab === "upcoming"
                      ? "You don't have any upcoming assignments."
                      : tab === "past"
                        ? "You don't have any past assignments."
                        : "You don't have any graded assignments yet."}
                  </p>
                </div>
              ) : (
                getFilteredAndSortedAssignments(tab).map((assignment) => {
                  const timeRemaining = calculateTimeRemaining(assignment.dueDate)

                  return (
                    <motion.div
                      key={assignment.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.3 }}
                    >
                      <Card
                        className={
                          assignment.status === "graded"
                            ? "border-l-4 border-l-purple-500"
                            : timeRemaining.urgent && assignment.status !== "submitted" && !timeRemaining.expired
                              ? "border-l-4 border-l-amber-500"
                              : ""
                        }
                      >
                        <CardContent className="p-6">
                          <div className="flex flex-col gap-4">
                            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                              <div className="flex-1">
                                <div className="flex items-center justify-between mb-1">
                                  <h3 className="text-lg font-bold">{assignment.title}</h3>
                                  {getStatusBadge(assignment.status, assignment.dueDate)}
                                </div>
                                <p className="text-sm text-gray-500 mb-2">{assignment.subject}</p>

                                <div className="flex flex-wrap gap-2 text-sm text-gray-500 mb-3">
                                  <div className="flex items-center">
                                    <Calendar className="h-4 w-4 mr-1" />
                                    Due: {new Date(assignment.dueDate).toLocaleDateString()}
                                  </div>

                                  {assignment.status !== "graded" && !timeRemaining.expired && (
                                    <div
                                      className={`flex items-center ${timeRemaining.urgent ? "text-red-500 font-medium" : ""}`}
                                    >
                                      <Clock className={`h-4 w-4 mr-1 ${timeRemaining.urgent ? "text-red-500" : ""}`} />
                                      {timeRemaining.text}
                                    </div>
                                  )}

                                  {assignment.submissionDate && (
                                    <div className="flex items-center">
                                      <Check className="h-4 w-4 mr-1" />
                                      Submitted: {new Date(assignment.submissionDate).toLocaleDateString()}
                                    </div>
                                  )}

                                  {assignment.plagiarismScore !== null && (
                                    <TooltipProvider>
                                      <Tooltip>
                                        <TooltipTrigger asChild>
                                          <div
                                            className={`flex items-center ${
                                              assignment.plagiarismScore > 10
                                                ? "text-red-500"
                                                : assignment.plagiarismScore > 5
                                                  ? "text-amber-500"
                                                  : "text-green-500"
                                            }`}
                                          >
                                            <Shield className="h-4 w-4 mr-1" />
                                            Similarity: {assignment.plagiarismScore}%
                                          </div>
                                        </TooltipTrigger>
                                        <TooltipContent>
                                          <p>
                                            Similarity score indicates potential matching content with other sources
                                          </p>
                                        </TooltipContent>
                                      </Tooltip>
                                    </TooltipProvider>
                                  )}
                                </div>

                                {assignment.progress > 0 && assignment.status !== "graded" && (
                                  <div className="mb-4">
                                    <div className="flex justify-between text-sm mb-1">
                                      <span>Progress</span>
                                      <span>{assignment.progress}%</span>
                                    </div>
                                    <Progress value={assignment.progress} className="h-2" />
                                  </div>
                                )}

                                {assignment.grade && (
                                  <div className="flex items-center mt-2">
                                    <span className="font-medium mr-2">Grade:</span>
                                    <Badge className="bg-purple-100 text-purple-800 border-purple-200">
                                      {assignment.grade}
                                    </Badge>

                                    {calculateTotalGrade(assignment.rubric) && (
                                      <span className="ml-2 text-sm text-gray-500">
                                        ({calculateTotalGrade(assignment.rubric).score}/
                                        {calculateTotalGrade(assignment.rubric).maxScore} points)
                                      </span>
                                    )}
                                  </div>
                                )}
                              </div>

                              <div className="flex flex-col sm:flex-row gap-2">
                                <Button
                                  variant="outline"
                                  className="flex items-center"
                                  onClick={() => setViewAssignment(assignment)}
                                >
                                  <Eye className="mr-2 h-4 w-4" />
                                  View Details
                                </Button>

                                {(assignment.status === "not_submitted" || assignment.status === "in_progress") && (
                                  <Button
                                    className="bg-green-600 hover:bg-green-700"
                                    onClick={() => setSelectedAssignment(assignment)}
                                  >
                                    <Upload className="mr-2 h-4 w-4" />
                                    {assignment.status === "in_progress" ? "Continue" : "Submit"}
                                  </Button>
                                )}

                                {assignment.status === "submitted" && assignment.allowResubmission && (
                                  <Button
                                    variant="outline"
                                    className="flex items-center"
                                    onClick={() => setSelectedAssignment(assignment)}
                                  >
                                    <RefreshCw className="mr-2 h-4 w-4" />
                                    Resubmit
                                  </Button>
                                )}
                              </div>
                            </div>

                            {assignment.resources && assignment.resources.length > 0 && (
                              <div className="mt-2">
                                <div className="flex items-center text-sm font-medium text-gray-700 mb-2">
                                  <Paperclip className="h-4 w-4 mr-1" />
                                  Resources:
                                </div>
                                <div className="flex flex-wrap gap-2">
                                  {assignment.resources.map((resource, index) => (
                                    <Button
                                      key={index}
                                      variant="outline"
                                      size="sm"
                                      className="flex items-center text-xs"
                                      asChild
                                    >
                                      <a href={resource.url} target="_blank" rel="noopener noreferrer">
                                        {getFileIcon(resource.name)}
                                        <span className="ml-1">{resource.name}</span>
                                        <ExternalLink className="ml-1 h-3 w-3" />
                                      </a>
                                    </Button>
                                  ))}
                                </div>
                              </div>
                            )}
                          </div>
                        </CardContent>
                      </Card>
                    </motion.div>
                  )
                })
              )}
            </div>
          </TabsContent>
        ))}
      </Tabs>

      {/* Submit Assignment Dialog */}
      <Dialog open={selectedAssignment !== null} onOpenChange={(open) => !open && setSelectedAssignment(null)}>
        <DialogContent className="sm:max-w-[700px] max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Submit Assignment</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            {selectedAssignment && (
              <>
                <div className="mb-4">
                  <h3 className="font-medium mb-1">{selectedAssignment.title}</h3>
                  <p className="text-sm text-gray-500">{selectedAssignment.subject}</p>

                  <div className="flex flex-wrap gap-2 text-sm text-gray-500 mt-2">
                    <div className="flex items-center">
                      <Calendar className="h-4 w-4 mr-1" />
                      Due: {new Date(selectedAssignment.dueDate).toLocaleDateString()}
                    </div>

                    {!calculateTimeRemaining(selectedAssignment.dueDate).expired && (
                      <div
                        className={`flex items-center ${calculateTimeRemaining(selectedAssignment.dueDate).urgent ? "text-red-500 font-medium" : ""}`}
                      >
                        <Clock
                          className={`h-4 w-4 mr-1 ${calculateTimeRemaining(selectedAssignment.dueDate).urgent ? "text-red-500" : ""}`}
                        />
                        {calculateTimeRemaining(selectedAssignment.dueDate).text}
                      </div>
                    )}
                  </div>
                </div>

                <div className="bg-gray-50 p-4 rounded-md mb-4">
                  <Accordion type="single" collapsible defaultValue="instructions">
                    <AccordionItem value="instructions" className="border-none">
                      <AccordionTrigger className="py-2">
                        <div className="flex items-center text-sm font-medium">
                          <Info className="h-4 w-4 mr-2" />
                          Assignment Instructions
                        </div>
                      </AccordionTrigger>
                      <AccordionContent>
                        <div className="text-sm text-gray-700 space-y-2">
                          <p>{selectedAssignment.description}</p>
                          <div className="mt-2 whitespace-pre-line">{selectedAssignment.instructions}</div>

                          <div className="mt-4 space-y-1">
                            {selectedAssignment.allowedFileTypes && (
                              <div className="flex items-start">
                                <span className="font-medium mr-2">Allowed file types:</span>
                                <span>{selectedAssignment.allowedFileTypes.join(", ")}</span>
                              </div>
                            )}

                            {selectedAssignment.maxFileSize && (
                              <div className="flex items-start">
                                <span className="font-medium mr-2">Max file size:</span>
                                <span>{selectedAssignment.maxFileSize}</span>
                              </div>
                            )}

                            {selectedAssignment.wordLimit && (
                              <div className="flex items-start">
                                <span className="font-medium mr-2">Word limit:</span>
                                <span>{selectedAssignment.wordLimit}</span>
                              </div>
                            )}
                          </div>
                        </div>
                      </AccordionContent>
                    </AccordionItem>
                  </Accordion>
                </div>

                {selectedAssignment.submissionHistory && selectedAssignment.submissionHistory.length > 0 && (
                  <div className="mb-4">
                    <Button
                      variant="outline"
                      size="sm"
                      className="flex items-center mb-2"
                      onClick={() => setShowHistory(!showHistory)}
                    >
                      <History className="h-4 w-4 mr-1" />
                      {showHistory ? "Hide Submission History" : "Show Submission History"}
                      {showHistory ? <ChevronUp className="ml-1 h-4 w-4" /> : <ChevronDown className="ml-1 h-4 w-4" />}
                    </Button>

                    {showHistory && (
                      <div className="bg-gray-50 p-4 rounded-md">
                        <h4 className="font-medium mb-2 text-sm">Previous Submissions</h4>
                        <div className="space-y-3">
                          {selectedAssignment.submissionHistory.map((submission, index) => (
                            <div key={index} className="bg-white p-3 rounded-md border text-sm">
                              <div className="flex justify-between items-center mb-2">
                                <div className="font-medium">{new Date(submission.date).toLocaleString()}</div>
                                <Badge
                                  variant="outline"
                                  className={
                                    submission.status === "submitted"
                                      ? "bg-green-100 text-green-800"
                                      : "bg-blue-100 text-blue-800"
                                  }
                                >
                                  {submission.status === "submitted" ? "Submitted" : "Saved Draft"}
                                </Badge>
                              </div>

                              {submission.files && submission.files.length > 0 && (
                                <div className="mb-2">
                                  <div className="text-xs text-gray-500 mb-1">Files:</div>
                                  <div className="flex flex-wrap gap-2">
                                    {submission.files.map((file, fileIndex) => (
                                      <div
                                        key={fileIndex}
                                        className="flex items-center bg-gray-100 px-2 py-1 rounded text-xs"
                                      >
                                        {getFileIcon(file.name)}
                                        <span className="ml-1">{file.name}</span>
                                        <span className="ml-1 text-gray-500">({file.size})</span>
                                      </div>
                                    ))}
                                  </div>
                                </div>
                              )}

                              {submission.text && (
                                <div>
                                  <div className="text-xs text-gray-500 mb-1">Text:</div>
                                  <div className="text-gray-700 bg-gray-50 p-2 rounded text-xs">
                                    {submission.text.length > 100
                                      ? `${submission.text.substring(0, 100)}...`
                                      : submission.text}
                                  </div>
                                </div>
                              )}
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                )}

                <div className="mb-4">
                  <div className="flex items-center justify-between mb-2">
                    <Label className="text-base font-medium">Submission Type</Label>
                  </div>

                  <div className="flex flex-col sm:flex-row gap-2 mb-4">
                    <Button
                      type="button"
                      variant={submissionType === "file" ? "default" : "outline"}
                      className={`flex-1 justify-start ${submissionType === "file" ? "bg-green-600 hover:bg-green-700" : ""}`}
                      onClick={() => setSubmissionType("file")}
                    >
                      <Upload className="mr-2 h-4 w-4" />
                      File Upload
                    </Button>

                    <Button
                      type="button"
                      variant={submissionType === "text" ? "default" : "outline"}
                      className={`flex-1 justify-start ${submissionType === "text" ? "bg-green-600 hover:bg-green-700" : ""}`}
                      onClick={() => setSubmissionType("text")}
                    >
                      <Edit className="mr-2 h-4 w-4" />
                      Text Submission
                    </Button>
                  </div>

                  {submissionType === "file" ? (
                    <>
                      <div
                        ref={dropAreaRef}
                        className={`border-2 ${
                          isDragging ? "border-green-500 bg-green-50" : "border-dashed border-gray-300"
                        } rounded-lg p-8 text-center transition-colors duration-200`}
                      >
                        {uploadedFiles.length > 0 ? (
                          <div className="space-y-2">
                            <div className="flex items-center justify-between mb-2">
                              <h4 className="font-medium">Uploaded Files</h4>
                              <Button
                                variant="ghost"
                                size="sm"
                                className="text-gray-500 h-8"
                                onClick={() => fileInputRef.current?.click()}
                              >
                                <Upload className="h-4 w-4 mr-1" />
                                Add More
                              </Button>
                            </div>

                            <div className="space-y-2 max-h-40 overflow-y-auto">
                              {uploadedFiles.map((file, index) => (
                                <div
                                  key={index}
                                  className="flex items-center justify-between bg-gray-50 p-2 rounded-md"
                                >
                                  <div className="flex items-center">
                                    {getFileIcon(file.name)}
                                    <span className="ml-2 text-sm">{file.name}</span>
                                    <span className="ml-2 text-xs text-gray-500">({file.size})</span>
                                    {file.source && (
                                      <Badge variant="outline" className="ml-2 text-xs">
                                        From {file.source}
                                      </Badge>
                                    )}
                                  </div>
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    onClick={() => handleRemoveFile(index)}
                                    className="text-gray-500 h-7 w-7"
                                  >
                                    <X className="h-4 w-4" />
                                  </Button>
                                </div>
                              ))}
                            </div>
                          </div>
                        ) : (
                          <>
                            <Upload className="h-10 w-10 text-gray-400 mx-auto mb-4" />
                            <h4 className="text-lg font-medium text-gray-700 mb-1">Upload Assignment Files</h4>
                            <p className="text-gray-500 text-sm mb-4">
                              Drag and drop your files here, or click to browse
                            </p>
                            <div className="flex flex-col sm:flex-row justify-center gap-2">
                              <Button variant="outline" size="sm" onClick={() => fileInputRef.current?.click()}>
                                Browse Files
                              </Button>

                              <Popover>
                                <PopoverTrigger asChild>
                                  <Button variant="outline" size="sm">
                                    <CloudUpload className="mr-2 h-4 w-4" />
                                    Import from Cloud
                                  </Button>
                                </PopoverTrigger>
                                <PopoverContent className="w-56">
                                  <div className="space-y-2">
                                    <h4 className="font-medium text-sm">Select Source</h4>
                                    <Button
                                      variant="outline"
                                      size="sm"
                                      className="w-full justify-start"
                                      onClick={() => handleCloudUpload("Google Drive")}
                                      disabled={isSubmitting}
                                    >
                                      <CloudUpload className="mr-2 h-4 w-4" />
                                      Google Drive
                                    </Button>
                                    <Button
                                      variant="outline"
                                      size="sm"
                                      className="w-full justify-start"
                                      onClick={() => handleCloudUpload("OneDrive")}
                                      disabled={isSubmitting}
                                    >
                                      <CloudUpload className="mr-2 h-4 w-4" />
                                      OneDrive
                                    </Button>
                                    <Button
                                      variant="outline"
                                      size="sm"
                                      className="w-full justify-start"
                                      onClick={() => handleCloudUpload("Dropbox")}
                                      disabled={isSubmitting}
                                    >
                                      <CloudUpload className="mr-2 h-4 w-4" />
                                      Dropbox
                                    </Button>
                                  </div>
                                </PopoverContent>
                              </Popover>
                            </div>
                          </>
                        )}

                        <input
                          ref={fileInputRef}
                          type="file"
                          className="hidden"
                          onChange={handleFileUpload}
                          multiple
                          accept={selectedAssignment.allowedFileTypes?.join(",") || "*"}
                        />
                      </div>

                      <div className="mt-4">
                        <Label htmlFor="submission-notes" className="text-sm font-medium">
                          Additional Notes (Optional)
                        </Label>
                        <Textarea
                          id="submission-notes"
                          placeholder="Add any notes about your submission..."
                          className="mt-1"
                          value={submissionText}
                          onChange={(e) => setSubmissionText(e.target.value)}
                        />
                      </div>
                    </>
                  ) : (
                    <div className="space-y-2">
                      <Label htmlFor="text-submission" className="text-sm font-medium">
                        Text Submission
                      </Label>
                      <Textarea
                        id="text-submission"
                        placeholder="Type your submission here..."
                        className="min-h-[200px]"
                        value={submissionText}
                        onChange={(e) => setSubmissionText(e.target.value)}
                      />

                      <div className="flex items-center justify-between text-xs text-gray-500">
                        <div>
                          {selectedAssignment.wordLimit && (
                            <span>
                              Word count: {submissionText.split(/\s+/).filter(Boolean).length} /
                              {selectedAssignment.wordLimit.split(" ")[0]}
                            </span>
                          )}
                        </div>
                        <div>Use Markdown for formatting</div>
                      </div>
                    </div>
                  )}
                </div>

                <div className="bg-amber-50 p-3 rounded-md border border-amber-200 mb-4">
                  <div className="flex items-start">
                    <AlertTriangle className="h-5 w-5 text-amber-500 mr-2 mt-0.5" />
                    <div>
                      <h4 className="font-medium text-amber-800 text-sm">Plagiarism Warning</h4>
                      <p className="text-amber-700 text-xs mt-1">
                        Your submission will be checked for plagiarism. Ensure your work is original and properly cited.
                      </p>
                    </div>
                  </div>
                </div>

                <DialogFooter className="flex flex-col-reverse sm:flex-row sm:justify-between sm:space-x-2">
                  <div className="flex flex-col sm:flex-row gap-2 mt-2 sm:mt-0">
                    <Button variant="outline" onClick={() => setSelectedAssignment(null)}>
                      Cancel
                    </Button>

                    <Button variant="outline" onClick={handleSaveDraft} disabled={isSubmitting}>
                      {isSubmitting ? (
                        <>
                          <div className="h-4 w-4 border-2 border-current border-t-transparent rounded-full animate-spin mr-2"></div>
                          Saving...
                        </>
                      ) : (
                        <>
                          <Save className="mr-2 h-4 w-4" />
                          Save Draft
                        </>
                      )}
                    </Button>
                  </div>

                  <Button className="bg-green-600 hover:bg-green-700" onClick={handleSubmit} disabled={isSubmitting}>
                    {isSubmitting ? (
                      <>
                        <div className="h-4 w-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                        Submitting...
                      </>
                    ) : (
                      <>
                        <Check className="mr-2 h-4 w-4" />
                        Submit Assignment
                      </>
                    )}
                  </Button>
                </DialogFooter>
              </>
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* View Assignment Dialog */}
      <Dialog
        open={viewAssignment !== null}
        onOpenChange={(open) => {
          if (!open) {
            setViewAssignment(null)
            setShowFeedback(false)
            setShowPlagiarismReport(false)
          }
        }}
      >
        <DialogContent className="sm:max-w-[800px] max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Assignment Details</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            {viewAssignment && (
              <>
                <div className="mb-4">
                  <div className="flex items-center justify-between mb-1">
                    <h3 className="text-xl font-bold">{viewAssignment.title}</h3>
                    {getStatusBadge(viewAssignment.status, viewAssignment.dueDate)}
                  </div>
                  <p className="text-sm text-gray-500">{viewAssignment.subject}</p>
                </div>

                <div className="flex flex-wrap gap-3 mb-4">
                  <Badge variant="outline" className="bg-gray-100">
                    <Calendar className="h-3 w-3 mr-1" />
                    Due: {new Date(viewAssignment.dueDate).toLocaleDateString()}
                  </Badge>

                  {viewAssignment.submissionDate && (
                    <Badge variant="outline" className="bg-blue-100 text-blue-800">
                      <Check className="h-3 w-3 mr-1" />
                      Submitted: {new Date(viewAssignment.submissionDate).toLocaleDateString()}
                    </Badge>
                  )}

                  {viewAssignment.gradedDate && (
                    <Badge variant="outline" className="bg-purple-100 text-purple-800">
                      <Check className="h-3 w-3 mr-1" />
                      Graded: {new Date(viewAssignment.gradedDate).toLocaleDateString()}
                    </Badge>
                  )}
                </div>

                <Tabs defaultValue="details">
                  <TabsList className="grid w-full grid-cols-3">
                    <TabsTrigger value="details">
                      <Info className="h-4 w-4 mr-2" />
                      Details
                    </TabsTrigger>

                    {viewAssignment.submissionHistory && viewAssignment.submissionHistory.length > 0 && (
                      <TabsTrigger value="submission">
                        <Upload className="h-4 w-4 mr-2" />
                        Submission
                      </TabsTrigger>
                    )}

                    {viewAssignment.grade && (
                      <TabsTrigger value="feedback">
                        <MessageSquare className="h-4 w-4 mr-2" />
                        Feedback
                      </TabsTrigger>
                    )}
                  </TabsList>

                  <TabsContent value="details" className="space-y-4 mt-4">
                    <div className="bg-gray-50 p-4 rounded-md">
                      <h4 className="font-medium mb-2">Description:</h4>
                      <p className="text-gray-700">{viewAssignment.description}</p>
                    </div>

                    <div className="bg-gray-50 p-4 rounded-md">
                      <h4 className="font-medium mb-2">Instructions:</h4>
                      <div className="text-gray-700 whitespace-pre-line">{viewAssignment.instructions}</div>
                    </div>

                    <div className="bg-gray-50 p-4 rounded-md">
                      <h4 className="font-medium mb-2">Requirements:</h4>
                      <div className="space-y-2">
                        {viewAssignment.allowedFileTypes && (
                          <div className="flex items-start">
                            <span className="font-medium mr-2">Allowed file types:</span>
                            <span>{viewAssignment.allowedFileTypes.join(", ")}</span>
                          </div>
                        )}

                        {viewAssignment.maxFileSize && (
                          <div className="flex items-start">
                            <span className="font-medium mr-2">Max file size:</span>
                            <span>{viewAssignment.maxFileSize}</span>
                          </div>
                        )}

                        {viewAssignment.wordLimit && (
                          <div className="flex items-start">
                            <span className="font-medium mr-2">Word limit:</span>
                            <span>{viewAssignment.wordLimit}</span>
                          </div>
                        )}

                        <div className="flex items-start">
                          <span className="font-medium mr-2">Resubmission allowed:</span>
                          <span>{viewAssignment.allowResubmission ? "Yes" : "No"}</span>
                        </div>
                      </div>
                    </div>

                    {viewAssignment.resources && viewAssignment.resources.length > 0 && (
                      <div className="bg-gray-50 p-4 rounded-md">
                        <h4 className="font-medium mb-2">Resources:</h4>
                        <div className="flex flex-wrap gap-2">
                          {viewAssignment.resources.map((resource, index) => (
                            <Button
                              key={index}
                              variant="outline"
                              size="sm"
                              className="flex items-center text-xs"
                              asChild
                            >
                              <a href={resource.url} target="_blank" rel="noopener noreferrer">
                                {getFileIcon(resource.name)}
                                <span className="ml-1">{resource.name}</span>
                                <ExternalLink className="ml-1 h-3 w-3" />
                              </a>
                            </Button>
                          ))}
                        </div>
                      </div>
                    )}
                  </TabsContent>

                  {viewAssignment.submissionHistory && viewAssignment.submissionHistory.length > 0 && (
                    <TabsContent value="submission" className="space-y-4 mt-4">
                      <div className="bg-gray-50 p-4 rounded-md">
                        <h4 className="font-medium mb-2">Submission History:</h4>
                        <div className="space-y-3">
                          {viewAssignment.submissionHistory.map((submission, index) => (
                            <div key={index} className="bg-white p-3 rounded-md border">
                              <div className="flex justify-between items-center mb-2">
                                <div className="font-medium">{new Date(submission.date).toLocaleString()}</div>
                                <Badge
                                  variant="outline"
                                  className={
                                    submission.status === "submitted"
                                      ? "bg-green-100 text-green-800"
                                      : "bg-blue-100 text-blue-800"
                                  }
                                >
                                  {submission.status === "submitted" ? "Submitted" : "Saved Draft"}
                                </Badge>
                              </div>

                              {submission.files && submission.files.length > 0 && (
                                <div className="mb-2">
                                  <div className="text-xs text-gray-500 mb-1">Files:</div>
                                  <div className="flex flex-wrap gap-2">
                                    {submission.files.map((file, fileIndex) => (
                                      <div
                                        key={fileIndex}
                                        className="flex items-center bg-gray-100 px-2 py-1 rounded text-xs"
                                      >
                                        {getFileIcon(file.name)}
                                        <span className="ml-1">{file.name}</span>
                                        <span className="ml-1 text-gray-500">({file.size})</span>
                                      </div>
                                    ))}
                                  </div>
                                </div>
                              )}

                              {submission.text && (
                                <div>
                                  <div className="text-xs text-gray-500 mb-1">Text:</div>
                                  <div className="text-gray-700 bg-gray-50 p-2 rounded">{submission.text}</div>
                                </div>
                              )}
                            </div>
                          ))}
                        </div>
                      </div>

                      {viewAssignment.plagiarismScore !== null && (
                        <div className="bg-gray-50 p-4 rounded-md">
                          <div className="flex items-center justify-between mb-2">
                            <h4 className="font-medium">Plagiarism Check:</h4>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => setShowPlagiarismReport(!showPlagiarismReport)}
                            >
                              {showPlagiarismReport ? "Hide Report" : "View Report"}
                            </Button>
                          </div>

                          <div className="flex items-center mb-2">
                            <div className="w-full">
                              <div className="flex justify-between text-sm mb-1">
                                <span>Similarity Score</span>
                                <span
                                  className={
                                    viewAssignment.plagiarismScore > 10
                                      ? "text-red-500 font-medium"
                                      : viewAssignment.plagiarismScore > 5
                                        ? "text-amber-500 font-medium"
                                        : "text-green-500 font-medium"
                                  }
                                >
                                  {viewAssignment.plagiarismScore}%
                                </span>
                              </div>
                              <div className="w-full bg-gray-200 rounded-full h-2.5">
                                <div
                                  className={`h-2.5 rounded-full ${
                                    viewAssignment.plagiarismScore > 10
                                      ? "bg-red-500"
                                      : viewAssignment.plagiarismScore > 5
                                        ? "bg-amber-500"
                                        : "bg-green-500"
                                  }`}
                                  style={{ width: `${viewAssignment.plagiarismScore}%` }}
                                ></div>
                              </div>
                            </div>
                          </div>

                          {showPlagiarismReport && (
                            <div className="mt-4 border rounded-md p-3 bg-white">
                              <h5 className="font-medium text-sm mb-2">Similarity Report</h5>
                              <p className="text-sm text-gray-700 mb-2">
                                {viewAssignment.plagiarismScore <= 5
                                  ? "No significant matching content detected. Your work appears to be original."
                                  : viewAssignment.plagiarismScore <= 10
                                    ? "Some minor similarities detected. This is generally acceptable but ensure all sources are properly cited."
                                    : "Significant matching content detected. Please review your work and ensure proper citation of sources."}
                              </p>

                              {viewAssignment.plagiarismScore > 5 && (
                                <div className="mt-2">
                                  <h6 className="text-xs font-medium mb-1">Potential Matches:</h6>
                                  <ul className="text-xs text-gray-700 list-disc pl-4 space-y-1">
                                    <li>
                                      Academic paper: "Introduction to {viewAssignment.subject}" -{" "}
                                      {Math.floor(viewAssignment.plagiarismScore / 2)}% match
                                    </li>
                                    <li>
                                      Online resource: "Learn {viewAssignment.subject}" -{" "}
                                      {Math.floor(viewAssignment.plagiarismScore / 3)}% match
                                    </li>
                                    {viewAssignment.plagiarismScore > 10 && (
                                      <li>
                                        Student submission from previous semester -{" "}
                                        {Math.floor(viewAssignment.plagiarismScore / 4)}% match
                                      </li>
                                    )}
                                  </ul>
                                </div>
                              )}
                            </div>
                          )}
                        </div>
                      )}
                    </TabsContent>
                  )}

                  {viewAssignment.grade && (
                    <TabsContent value="feedback" className="space-y-4 mt-4">
                      <div className="bg-purple-50 p-4 rounded-md border border-purple-100">
                        <div className="flex items-center justify-between mb-2">
                          <h4 className="font-medium text-purple-900">Grade:</h4>
                          <Badge className="bg-purple-100 text-purple-800 border-purple-200">
                            {viewAssignment.grade}
                          </Badge>
                        </div>

                        {calculateTotalGrade(viewAssignment.rubric) && (
                          <div className="mb-2">
                            <div className="flex justify-between text-sm mb-1">
                              <span className="text-purple-900">Total Score</span>
                              <span className="text-purple-900 font-medium">
                                {calculateTotalGrade(viewAssignment.rubric).score}/
                                {calculateTotalGrade(viewAssignment.rubric).maxScore} (
                                {calculateTotalGrade(viewAssignment.rubric).percentage}%)
                              </span>
                            </div>
                            <div className="w-full bg-purple-200 rounded-full h-2.5">
                              <div
                                className="h-2.5 rounded-full bg-purple-600"
                                style={{ width: `${calculateTotalGrade(viewAssignment.rubric).percentage}%` }}
                              ></div>
                            </div>
                          </div>
                        )}
                      </div>

                      {viewAssignment.rubric && (
                        <div className="bg-gray-50 p-4 rounded-md">
                          <h4 className="font-medium mb-2">Grading Rubric:</h4>
                          <Table>
                            <TableHeader>
                              <TableRow>
                                <TableHead className="w-[50%]">Criterion</TableHead>
                                <TableHead>Score</TableHead>
                                <TableHead className="text-right">Max Points</TableHead>
                              </TableRow>
                            </TableHeader>
                            <TableBody>
                              {viewAssignment.rubric.map((item, index) => (
                                <TableRow key={index}>
                                  <TableCell className="font-medium">{item.criterion}</TableCell>
                                  <TableCell>
                                    {item.score !== null ? (
                                      <Badge
                                        variant="outline"
                                        className={
                                          item.score / item.maxScore >= 0.9
                                            ? "bg-green-100 text-green-800"
                                            : item.score / item.maxScore >= 0.7
                                              ? "bg-blue-100 text-blue-800"
                                              : "bg-amber-100 text-amber-800"
                                        }
                                      >
                                        {item.score}
                                      </Badge>
                                    ) : (
                                      "Not graded"
                                    )}
                                  </TableCell>
                                  <TableCell className="text-right">{item.maxScore}</TableCell>
                                </TableRow>
                              ))}
                            </TableBody>
                          </Table>
                        </div>
                      )}

                      {viewAssignment.feedback && (
                        <div className="bg-gray-50 p-4 rounded-md">
                          <h4 className="font-medium mb-2">Instructor Feedback:</h4>
                          <div className="bg-white p-3 rounded border text-gray-700">{viewAssignment.feedback}</div>
                        </div>
                      )}
                    </TabsContent>
                  )}
                </Tabs>

                <DialogFooter className="flex justify-end gap-2 mt-4">
                  {(viewAssignment.status === "not_submitted" || viewAssignment.status === "in_progress") && (
                    <Button
                      className="bg-green-600 hover:bg-green-700"
                      onClick={() => {
                        setViewAssignment(null)
                        setSelectedAssignment(viewAssignment)
                      }}
                    >
                      <Upload className="mr-2 h-4 w-4" />
                      Submit
                    </Button>
                  )}

                  {viewAssignment.status === "submitted" && viewAssignment.allowResubmission && (
                    <Button
                      variant="outline"
                      onClick={() => {
                        setViewAssignment(null)
                        setSelectedAssignment(viewAssignment)
                      }}
                    >
                      <RefreshCw className="mr-2 h-4 w-4" />
                      Resubmit
                    </Button>
                  )}

                  <Button variant="outline" onClick={() => setViewAssignment(null)}>
                    Close
                  </Button>
                </DialogFooter>
              </>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
