"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { useRouter } from "next/navigation"
import {
  ArrowLeft,
  Calendar,
  Clock,
  FileText,
  Upload,
  Check,
  X,
  AlertTriangle,
  FileCode,
  CloudUpload,
  History,
  Info,
  ChevronDown,
  ChevronUp,
  Edit,
  Save,
  ExternalLink,
  File,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { useToast } from "@/components/ui/use-toast"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { getAssignmentById, getStudentSubmissions, submitAssignment, saveDraft } from "@/app/actions/assignment-actions"
import { uploadSubmissionFile } from "@/lib/file-upload"

export default function SubmitAssignmentPage({ params }: { params: { id: string } }) {
  const { toast } = useToast()
  const router = useRouter()
  const fileInputRef = useRef<HTMLInputElement>(null)
  const dropAreaRef = useRef<HTMLDivElement>(null)
  const [isDragging, setIsDragging] = useState(false)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [assignment, setAssignment] = useState<any>(null)
  const [resources, setResources] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [uploadedFiles, setUploadedFiles] = useState<
    Array<{
      name: string
      size: string
      type: string
      file?: File
      source?: string
    }>
  >([])
  const [submissionText, setSubmissionText] = useState("")
  const [submissionType, setSubmissionType] = useState("file")
  const [showHistory, setShowHistory] = useState(false)
  const [submissionHistory, setSubmissionHistory] = useState<any[]>([])
  const [cloudSource, setCloudSource] = useState("")

  // Fetch assignment data
  useEffect(() => {
    const fetchData = async () => {
      try {
        // Fetch assignment data from Supabase
        const result = await getAssignmentById(params.id)

        if (!result.success) {
          throw new Error("Failed to load assignment")
        }

        setAssignment(result.data.assignment)
        setResources(result.data.resources)

        // Fetch student's submission history
        const studentId = "student-id" // Replace with actual student ID from auth
        const submissionsResult = await getStudentSubmissions(studentId, params.id)

        if (submissionsResult.success && submissionsResult.data.length > 0) {
          setSubmissionHistory(submissionsResult.data)
        }
      } catch (error) {
        console.error("Error fetching assignment data:", error)
        toast({
          title: "Error",
          description: "Failed to load assignment data",
          variant: "destructive",
        })
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [params.id, toast])

  // Calculate time remaining for assignment
  const calculateTimeRemaining = (dueDate: string) => {
    const now = new Date()
    const due = new Date(dueDate)
    const diff = due.getTime() - now.getTime()

    if (diff <= 0) return { expired: true, text: "Expired" }

    const days = Math.floor(diff / (1000 * 60 * 60 * 24))
    const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60))
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60))

    if (days > 0) {
      return {
        expired: false,
        text: `${days}d ${hours}h remaining`,
        urgent: days <= 1,
      }
    } else if (hours > 0) {
      return {
        expired: false,
        text: `${hours}h ${minutes}m remaining`,
        urgent: true,
      }
    } else {
      return {
        expired: false,
        text: `${minutes}m remaining`,
        urgent: true,
      }
    }
  }

  // Format date
  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString() + " " + date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
  }

  // Handle drag and drop
  useEffect(() => {
    const dropArea = dropAreaRef.current

    const handleDragOver = (e: DragEvent) => {
      e.preventDefault()
      setIsDragging(true)
    }

    const handleDragLeave = () => {
      setIsDragging(false)
    }

    const handleDrop = (e: DragEvent) => {
      e.preventDefault()
      setIsDragging(false)

      if (e.dataTransfer?.files && e.dataTransfer.files.length > 0) {
        const newFiles = Array.from(e.dataTransfer.files).map((file) => ({
          name: file.name,
          size: (file.size / (1024 * 1024)).toFixed(2) + " MB",
          type: file.type,
          file: file,
        }))

        setUploadedFiles([...uploadedFiles, ...newFiles])

        toast({
          title: "Files Uploaded",
          description: `${e.dataTransfer.files.length} file(s) have been added to your submission.`,
        })
      }
    }

    if (dropArea) {
      dropArea.addEventListener("dragover", handleDragOver)
      dropArea.addEventListener("dragleave", handleDragLeave)
      dropArea.addEventListener("drop", handleDrop as EventListener)

      return () => {
        dropArea.removeEventListener("dragover", handleDragOver)
        dropArea.removeEventListener("dragleave", handleDragLeave)
        dropArea.removeEventListener("drop", handleDrop as EventListener)
      }
    }
  }, [uploadedFiles, toast])

  // Handle file upload
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (files && files.length > 0) {
      const newFiles = Array.from(files).map((file) => ({
        name: file.name,
        size: (file.size / (1024 * 1024)).toFixed(2) + " MB",
        type: file.type,
        file: file,
      }))

      setUploadedFiles([...uploadedFiles, ...newFiles])

      toast({
        title: "Files Uploaded",
        description: `${files.length} file(s) have been added to your submission.`,
      })
    }
  }

  // Handle cloud integration
  const handleCloudUpload = (source: string) => {
    // Simulate cloud upload
    setIsSubmitting(true)

    setTimeout(() => {
      const newFile = {
        name: `document_from_${source.toLowerCase()}.pdf`,
        size: "2.5 MB",
        type: "application/pdf",
        source: source,
      }

      setUploadedFiles([...uploadedFiles, newFile])
      setIsSubmitting(false)
      setCloudSource("")

      toast({
        title: "Cloud File Imported",
        description: `File has been imported from ${source}.`,
      })
    }, 1500)
  }

  // Handle file removal
  const handleRemoveFile = (index: number) => {
    const newFiles = [...uploadedFiles]
    newFiles.splice(index, 1)
    setUploadedFiles(newFiles)

    toast({
      title: "File Removed",
      description: "The file has been removed from your submission.",
    })
  }

  // Handle submission
  const handleSubmit = async () => {
    if (submissionType === "file" && uploadedFiles.length === 0) {
      toast({
        title: "Error",
        description: "Please upload at least one file",
        variant: "destructive",
      })
      return
    }

    if (submissionType === "text" && !submissionText.trim()) {
      toast({
        title: "Error",
        description: "Please enter your submission text",
        variant: "destructive",
      })
      return
    }

    setIsSubmitting(true)

    try {
      const studentId = "student-id" // Replace with actual student ID from auth

      // Upload files if any
      const uploadedSubmissionFiles = []

      if (submissionType === "file" && uploadedFiles.length > 0) {
        for (const file of uploadedFiles) {
          if (file.file) {
            const uploadResult = await uploadSubmissionFile(file.file, params.id, studentId)

            if (!uploadResult.success) {
              throw new Error(`Failed to upload file: ${file.name}`)
            }

            uploadedSubmissionFiles.push({
              name: file.name,
              fileType: file.type,
              fileUrl: uploadResult.fileUrl,
              fileSize: uploadResult.fileSize,
            })
          }
        }
      }

      // Submit assignment
      const result = await submitAssignment({
        assignmentId: params.id,
        studentId,
        submissionType,
        content: submissionText,
        files: uploadedSubmissionFiles,
      })

      if (!result.success) {
        throw new Error("Failed to submit assignment")
      }

      toast({
        title: "Success",
        description: "Your assignment has been submitted successfully.",
      })

      // Redirect back to assignments page
      router.push("/student-dashboard/assignments")
    } catch (error) {
      console.error("Error submitting assignment:", error)
      toast({
        title: "Error",
        description: "Failed to submit assignment. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  // Handle save draft
  const handleSaveDraft = async () => {
    if (
      submissionType === "file" &&
      uploadedFiles.length === 0 &&
      submissionType === "text" &&
      !submissionText.trim()
    ) {
      toast({
        title: "Error",
        description: "Please add content to save as draft",
        variant: "destructive",
      })
      return
    }

    setIsSubmitting(true)

    try {
      const studentId = "student-id" // Replace with actual student ID from auth

      // Upload files if any
      const uploadedSubmissionFiles = []

      if (submissionType === "file" && uploadedFiles.length > 0) {
        for (const file of uploadedFiles) {
          if (file.file) {
            const uploadResult = await uploadSubmissionFile(file.file, params.id, studentId)

            if (!uploadResult.success) {
              throw new Error(`Failed to upload file: ${file.name}`)
            }

            uploadedSubmissionFiles.push({
              name: file.name,
              fileType: file.type,
              fileUrl: uploadResult.fileUrl,
              fileSize: uploadResult.fileSize,
            })
          }
        }
      }

      // Save draft
      const result = await saveDraft({
        assignmentId: params.id,
        studentId,
        submissionType,
        content: submissionText,
        files: uploadedSubmissionFiles,
      })

      if (!result.success) {
        throw new Error("Failed to save draft")
      }

      toast({
        title: "Success",
        description: "Your draft has been saved successfully.",
      })

      // Add to submission history
      const newSubmission = {
        id: result.data.id,
        date: result.data.created_at,
        files: uploadedSubmissionFiles.map((file) => ({ name: file.name, size: file.fileSize })),
        text: submissionText,
        status: "draft",
      }

      setSubmissionHistory([...submissionHistory, newSubmission])
    } catch (error) {
      console.error("Error saving draft:", error)
      toast({
        title: "Error",
        description: "Failed to save draft. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  // Get file icon based on type
  const getFileIcon = (fileName: string) => {
    const extension = fileName.split(".").pop()?.toLowerCase() || ""

    switch (extension) {
      case "pdf":
        return <FileText className="h-4 w-4 text-red-500" />
      case "doc":
      case "docx":
        return <FileText className="h-4 w-4 text-blue-500" />
      case "ppt":
      case "pptx":
        return <FileText className="h-4 w-4 text-orange-500" />
      case "jpg":
      case "jpeg":
      case "png":
        return <FileText className="h-4 w-4 text-purple-500" />
      case "zip":
      case "rar":
        return <FileText className="h-4 w-4 text-gray-500" />
      case "java":
      case "py":
      case "cpp":
      case "js":
        return <FileCode className="h-4 w-4 text-teal-500" />
      default:
        return <File className="h-4 w-4 text-gray-500" />
    }
  }

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="h-8 w-8 border-4 border-green-600 border-t-transparent rounded-full animate-spin"></div>
      </div>
    )
  }

  if (!assignment) {
    return (
      <div className="text-center py-12">
        <h2 className="text-2xl font-bold text-gray-800 mb-2">Assignment Not Found</h2>
        <p className="text-gray-600 mb-6">The assignment you're looking for doesn't exist or has been removed.</p>
        <Button onClick={() => router.push("/student-dashboard/assignments")}>
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Assignments
        </Button>
      </div>
    )
  }

  const timeRemaining = calculateTimeRemaining(assignment.due_date)

  return (
    <div className="max-w-4xl mx-auto">
      <div className="flex items-center mb-6">
        <Button
          variant="ghost"
          size="icon"
          className="mr-2"
          onClick={() => router.push("/student-dashboard/assignments")}
        >
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <h1 className="text-2xl font-bold">Submit Assignment</h1>
      </div>

      <Card className="mb-6">
        <CardContent className="p-6">
          <div className="flex flex-col md:flex-row gap-6">
            <div className="flex-1">
              <h2 className="text-xl font-bold mb-2">{assignment.title}</h2>

              <div className="flex flex-wrap gap-3 mb-4">
                <Badge variant="outline" className="bg-gray-100">
                  <Calendar className="h-3 w-3 mr-1" />
                  Due: {formatDate(assignment.due_date)}
                </Badge>

                {!timeRemaining.expired && (
                  <Badge
                    variant="outline"
                    className={timeRemaining.urgent ? "bg-red-100 text-red-800" : "bg-green-100 text-green-800"}
                  >
                    <Clock className="h-3 w-3 mr-1" />
                    {timeRemaining.text}
                  </Badge>
                )}

                <Badge variant="outline" className="bg-gray-100">
                  <FileText className="h-3 w-3 mr-1" />
                  Type: {assignment.assignment_type.replace("_", " ")}
                </Badge>
              </div>

              <div className="bg-gray-50 p-4 rounded-md mb-4">
                <Accordion type="single" collapsible defaultValue="instructions">
                  <AccordionItem value="instructions" className="border-none">
                    <AccordionTrigger className="py-2">
                      <div className="flex items-center text-sm font-medium">
                        <Info className="h-4 w-4 mr-2" />
                        Assignment Instructions
                      </div>
                    </AccordionTrigger>
                    <AccordionContent>
                      <div className="text-sm text-gray-700 space-y-2">
                        <p>{assignment.description}</p>

                        <div className="mt-4 space-y-1">
                          {assignment.allowed_file_types && (
                            <div className="flex items-start">
                              <span className="font-medium mr-2">Allowed file types:</span>
                              <span>{assignment.allowed_file_types.map((type: string) => `.${type}`).join(", ")}</span>
                            </div>
                          )}

                          {assignment.word_limit && (
                            <div className="flex items-start">
                              <span className="font-medium mr-2">Word limit:</span>
                              <span>{assignment.word_limit} words</span>
                            </div>
                          )}
                        </div>
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                </Accordion>
              </div>

              {resources.length > 0 && (
                <div>
                  <h3 className="font-medium mb-2">Resources:</h3>
                  <div className="flex flex-wrap gap-2">
                    {resources.map((resource) => (
                      <Button
                        key={resource.id}
                        variant="outline"
                        size="sm"
                        className="flex items-center text-xs"
                        asChild
                      >
                        <a href={resource.file_url} target="_blank" rel="noopener noreferrer">
                          {getFileIcon(resource.name)}
                          <span className="ml-1">{resource.name}</span>
                          <ExternalLink className="ml-1 h-3 w-3" />
                        </a>
                      </Button>
                    ))}
                  </div>
                </div>
              )}
            </div>

            <div className="flex-1">
              <h3 className="font-medium mb-3">Submission Settings:</h3>
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Late Submission:</span>
                  <span className="font-medium">{assignment.allow_late_submission ? "Allowed" : "Not allowed"}</span>
                </div>

                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Resubmission:</span>
                  <span className="font-medium">{assignment.allow_resubmission ? "Allowed" : "Not allowed"}</span>
                </div>

                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Plagiarism Check:</span>
                  <span className="font-medium">{assignment.enable_plagiarism_check ? "Enabled" : "Disabled"}</span>
                </div>

                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Group Submission:</span>
                  <span className="font-medium">{assignment.allow_group_submission ? "Allowed" : "Not allowed"}</span>
                </div>
              </div>

              {submissionHistory.length > 0 && (
                <div className="mt-6">
                  <Button
                    variant="outline"
                    size="sm"
                    className="flex items-center mb-2"
                    onClick={() => setShowHistory(!showHistory)}
                  >
                    <History className="h-4 w-4 mr-1" />
                    {showHistory ? "Hide Submission History" : "Show Submission History"}
                    {showHistory ? <ChevronUp className="ml-1 h-4 w-4" /> : <ChevronDown className="ml-1 h-4 w-4" />}
                  </Button>

                  {showHistory && (
                    <div className="bg-gray-50 p-4 rounded-md">
                      <h4 className="font-medium mb-2 text-sm">Previous Submissions</h4>
                      <div className="space-y-3">
                        {submissionHistory.map((submission) => (
                          <div key={submission.id} className="bg-white p-3 rounded-md border text-sm">
                            <div className="flex justify-between items-center mb-2">
                              <div className="font-medium">{formatDate(submission.date)}</div>
                              <Badge
                                variant="outline"
                                className={
                                  submission.status === "submitted"
                                    ? "bg-green-100 text-green-800"
                                    : "bg-blue-100 text-blue-800"
                                }
                              >
                                {submission.status === "submitted" ? "Submitted" : "Saved Draft"}
                              </Badge>
                            </div>

                            {submission.files && submission.files.length > 0 && (
                              <div className="mb-2">
                                <div className="text-xs text-gray-500 mb-1">Files:</div>
                                <div className="flex flex-wrap gap-2">
                                  {submission.files.map((file: any, fileIndex: number) => (
                                    <div
                                      key={fileIndex}
                                      className="flex items-center bg-gray-100 px-2 py-1 rounded text-xs"
                                    >
                                      {getFileIcon(file.name)}
                                      <span className="ml-1">{file.name}</span>
                                      <span className="ml-1 text-gray-500">({file.size})</span>
                                    </div>
                                  ))}
                                </div>
                              </div>
                            )}

                            {submission.text && (
                              <div>
                                <div className="text-xs text-gray-500 mb-1">Text:</div>
                                <div className="text-gray-700 bg-gray-50 p-2 rounded text-xs">
                                  {submission.text.length > 100
                                    ? `${submission.text.substring(0, 100)}...`
                                    : submission.text}
                                </div>
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-6">
          <div className="mb-4">
            <div className="flex items-center justify-between mb-2">
              <Label className="text-base font-medium">Submission Type</Label>
            </div>

            <div className="flex flex-col sm:flex-row gap-2 mb-4">
              <Button
                type="button"
                variant={submissionType === "file" ? "default" : "outline"}
                className={`flex-1 justify-start ${submissionType === "file" ? "bg-green-600 hover:bg-green-700" : ""}`}
                onClick={() => setSubmissionType("file")}
              >
                <Upload className="mr-2 h-4 w-4" />
                File Upload
              </Button>

              <Button
                type="button"
                variant={submissionType === "text" ? "default" : "outline"}
                className={`flex-1 justify-start ${submissionType === "text" ? "bg-green-600 hover:bg-green-700" : ""}`}
                onClick={() => setSubmissionType("text")}
              >
                <Edit className="mr-2 h-4 w-4" />
                Text Submission
              </Button>
            </div>

            {submissionType === "file" ? (
              <>
                <div
                  ref={dropAreaRef}
                  className={`border-2 ${
                    isDragging ? "border-green-500 bg-green-50" : "border-dashed border-gray-300"
                  } rounded-lg p-8 text-center transition-colors duration-200`}
                >
                  {uploadedFiles.length > 0 ? (
                    <div className="space-y-2">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-medium">Uploaded Files</h4>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="text-gray-500 h-8"
                          onClick={() => fileInputRef.current?.click()}
                        >
                          <Upload className="h-4 w-4 mr-1" />
                          Add More
                        </Button>
                      </div>

                      <div className="space-y-2 max-h-40 overflow-y-auto">
                        {uploadedFiles.map((file, index) => (
                          <div key={index} className="flex items-center justify-between bg-gray-50 p-2 rounded-md">
                            <div className="flex items-center">
                              {getFileIcon(file.name)}
                              <span className="ml-2 text-sm">{file.name}</span>
                              <span className="ml-2 text-xs text-gray-500">({file.size})</span>
                              {file.source && (
                                <Badge variant="outline" className="ml-2 text-xs">
                                  From {file.source}
                                </Badge>
                              )}
                            </div>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => handleRemoveFile(index)}
                              className="text-gray-500 h-7 w-7"
                            >
                              <X className="h-4 w-4" />
                            </Button>
                          </div>
                        ))}
                      </div>
                    </div>
                  ) : (
                    <>
                      <Upload className="h-10 w-10 text-gray-400 mx-auto mb-4" />
                      <h4 className="text-lg font-medium text-gray-700 mb-1">Upload Assignment Files</h4>
                      <p className="text-gray-500 text-sm mb-4">Drag and drop your files here, or click to browse</p>
                      <div className="flex flex-col sm:flex-row justify-center gap-2">
                        <Button variant="outline" size="sm" onClick={() => fileInputRef.current?.click()}>
                          Browse Files
                        </Button>

                        <Popover>
                          <PopoverTrigger asChild>
                            <Button variant="outline" size="sm">
                              <CloudUpload className="mr-2 h-4 w-4" />
                              Import from Cloud
                            </Button>
                          </PopoverTrigger>
                          <PopoverContent className="w-56">
                            <div className="space-y-2">
                              <h4 className="font-medium text-sm">Select Source</h4>
                              <Button
                                variant="outline"
                                size="sm"
                                className="w-full justify-start"
                                onClick={() => handleCloudUpload("Google Drive")}
                                disabled={isSubmitting}
                              >
                                <CloudUpload className="mr-2 h-4 w-4" />
                                Google Drive
                              </Button>
                              <Button
                                variant="outline"
                                size="sm"
                                className="w-full justify-start"
                                onClick={() => handleCloudUpload("OneDrive")}
                                disabled={isSubmitting}
                              >
                                <CloudUpload className="mr-2 h-4 w-4" />
                                OneDrive
                              </Button>
                              <Button
                                variant="outline"
                                size="sm"
                                className="w-full justify-start"
                                onClick={() => handleCloudUpload("Dropbox")}
                                disabled={isSubmitting}
                              >
                                <CloudUpload className="mr-2 h-4 w-4" />
                                Dropbox
                              </Button>
                            </div>
                          </PopoverContent>
                        </Popover>
                      </div>
                    </>
                  )}

                  <input
                    ref={fileInputRef}
                    type="file"
                    className="hidden"
                    onChange={handleFileUpload}
                    multiple
                    accept={assignment.allowed_file_types?.map((type: string) => `.${type}`).join(",")}
                  />
                </div>

                <div className="mt-4">
                  <Label htmlFor="submission-notes" className="text-sm font-medium">
                    Additional Notes (Optional)
                  </Label>
                  <Textarea
                    id="submission-notes"
                    placeholder="Add any notes about your submission..."
                    className="mt-1"
                    value={submissionText}
                    onChange={(e) => setSubmissionText(e.target.value)}
                  />
                </div>
              </>
            ) : (
              <div className="space-y-2">
                <Label htmlFor="text-submission" className="text-sm font-medium">
                  Text Submission
                </Label>
                <Textarea
                  id="text-submission"
                  placeholder="Type your submission here..."
                  className="min-h-[200px]"
                  value={submissionText}
                  onChange={(e) => setSubmissionText(e.target.value)}
                />

                <div className="flex items-center justify-between text-xs text-gray-500">
                  <div>
                    {assignment.word_limit && (
                      <span>
                        Word count: {submissionText.split(/\s+/).filter(Boolean).length} / {assignment.word_limit}
                      </span>
                    )}
                  </div>
                  <div>Use Markdown for formatting</div>
                </div>
              </div>
            )}

            {assignment.enable_plagiarism_check && (
              <div className="bg-amber-50 p-3 rounded-md border border-amber-200 mt-6">
                <div className="flex items-start">
                  <AlertTriangle className="h-5 w-5 text-amber-500 mr-2 mt-0.5" />
                  <div>
                    <h4 className="font-medium text-amber-800 text-sm">Plagiarism Warning</h4>
                    <p className="text-amber-700 text-xs mt-1">
                      Your submission will be checked for plagiarism. Ensure your work is original and properly cited.
                    </p>
                  </div>
                </div>
              </div>
            )}

            <div className="flex justify-end gap-2 mt-6">
              <Button variant="outline" onClick={() => router.push("/student-dashboard/assignments")}>
                Cancel
              </Button>

              <Button variant="outline" onClick={handleSaveDraft} disabled={isSubmitting}>
                {isSubmitting ? (
                  <>
                    <div className="h-4 w-4 border-2 border-current border-t-transparent rounded-full animate-spin mr-2"></div>
                    Saving...
                  </>
                ) : (
                  <>
                    <Save className="mr-2 h-4 w-4" />
                    Save Draft
                  </>
                )}
              </Button>

              <Button className="bg-green-600 hover:bg-green-700" onClick={handleSubmit} disabled={isSubmitting}>
                {isSubmitting ? (
                  <>
                    <div className="h-4 w-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                    Submitting...
                  </>
                ) : (
                  <>
                    <Check className="mr-2 h-4 w-4" />
                    Submit Assignment
                  </>
                )}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
