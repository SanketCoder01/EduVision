"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { Calendar, Clock, MapPin, Users, DollarSign, Search, Filter, Check } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { useToast } from "@/components/ui/use-toast"

export default function StudentEventsPage() {
  const { toast } = useToast()
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedEvent, setSelectedEvent] = useState(null)
  const [isRegistering, setIsRegistering] = useState(false)

  // Mock events data
  const events = [
    {
      id: 1,
      title: "Annual Tech Symposium",
      description:
        "A day-long symposium featuring workshops, talks, and networking opportunities for tech enthusiasts.",
      date: "2023-10-15",
      time: "10:00 AM",
      venue: "Main Auditorium",
      poster: "/placeholder.svg?height=200&width=400",
      maxParticipants: 100,
      targetAudience: ["CSE", "IT", "AIML"],
      onlinePayment: true,
      paymentAmount: "500",
      registeredStudents: 45,
      isRegistered: false,
      hasPaid: false,
    },
    {
      id: 2,
      title: "Coding Competition",
      description: "Test your programming skills in this competitive coding event with exciting prizes.",
      date: "2023-10-20",
      time: "2:00 PM",
      venue: "Computer Lab 3",
      poster: "/placeholder.svg?height=200&width=400",
      maxParticipants: 50,
      targetAudience: ["CSE", "IT"],
      onlinePayment: false,
      registeredStudents: 32,
      isRegistered: true,
      hasPaid: true,
    },
    {
      id: 3,
      title: "Career Guidance Workshop",
      description: "Industry experts will provide guidance on career opportunities in the tech industry.",
      date: "2023-11-05",
      time: "11:00 AM",
      venue: "Seminar Hall",
      poster: "/placeholder.svg?height=200&width=400",
      maxParticipants: 150,
      targetAudience: ["All Departments"],
      onlinePayment: true,
      paymentAmount: "200",
      registeredStudents: 78,
      isRegistered: false,
      hasPaid: false,
    },
  ]

  const handleRegister = () => {
    if (!selectedEvent) return

    setIsRegistering(true)

    // Simulate registration process
    setTimeout(() => {
      setIsRegistering(false)
      setSelectedEvent(null)

      toast({
        title: "Registration Successful",
        description: "You have successfully registered for the event.",
      })
    }, 2000)
  }

  const getFilteredEvents = () => {
    if (!searchQuery) return events

    const query = searchQuery.toLowerCase()
    return events.filter(
      (event) =>
        event.title.toLowerCase().includes(query) ||
        event.description.toLowerCase().includes(query) ||
        event.venue.toLowerCase().includes(query),
    )
  }

  return (
    <div className="max-w-6xl mx-auto">
      <motion.h1
        className="text-2xl font-bold mb-6 flex items-center"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <Calendar className="inline-block mr-2 h-6 w-6 text-green-600" />
        Events
      </motion.h1>

      <div className="flex flex-col md:flex-row gap-4 mb-6">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
          <Input
            placeholder="Search events..."
            className="pl-10"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <Button variant="outline" className="flex items-center">
          <Filter className="mr-2 h-4 w-4" />
          Filter
        </Button>
      </div>

      <div className="space-y-6">
        {getFilteredEvents().length === 0 ? (
          <div className="text-center py-12">
            <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Calendar className="h-8 w-8 text-gray-400" />
            </div>
            <h3 className="text-lg font-medium text-gray-900 mb-2">No Events Found</h3>
            <p className="text-gray-500">Try adjusting your search criteria</p>
          </div>
        ) : (
          getFilteredEvents().map((event) => (
            <motion.div
              key={event.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3 }}
            >
              <Card className="overflow-hidden">
                <CardContent className="p-0">
                  <div className="md:flex">
                    <div className="md:w-1/3">
                      <img
                        src={event.poster || "/placeholder.svg"}
                        alt={event.title}
                        className="w-full h-48 md:h-full object-cover"
                      />
                    </div>
                    <div className="p-6 md:w-2/3">
                      <div className="flex justify-between items-start mb-2">
                        <h3 className="text-xl font-bold">{event.title}</h3>
                        {event.isRegistered && (
                          <Badge className="bg-green-100 text-green-800">
                            <Check className="mr-1 h-3 w-3" />
                            Registered
                          </Badge>
                        )}
                      </div>
                      <div className="flex flex-wrap gap-2 text-sm text-gray-500 mb-3">
                        <div className="flex items-center">
                          <Calendar className="h-4 w-4 mr-1" />
                          {event.date}
                        </div>
                        <div className="flex items-center">
                          <Clock className="h-4 w-4 mr-1" />
                          {event.time}
                        </div>
                        <div className="flex items-center">
                          <MapPin className="h-4 w-4 mr-1" />
                          {event.venue}
                        </div>
                      </div>
                      <p className="text-gray-700 mb-4">{event.description}</p>
                      <div className="flex flex-wrap gap-2 mb-4">
                        <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-100">
                          <Users className="h-3 w-3 mr-1" />
                          {event.registeredStudents}/{event.maxParticipants} Registered
                        </Badge>
                        {event.onlinePayment && (
                          <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-100">
                            <DollarSign className="h-3 w-3 mr-1" />₹{event.paymentAmount}
                          </Badge>
                        )}
                        {event.targetAudience.map((audience, index) => (
                          <Badge key={index} variant="outline">
                            {audience}
                          </Badge>
                        ))}
                      </div>
                      <div className="flex justify-end">
                        {event.isRegistered ? (
                          <Button variant="outline" className="flex items-center">
                            View Details
                          </Button>
                        ) : (
                          <Button className="bg-green-600 hover:bg-green-700" onClick={() => setSelectedEvent(event)}>
                            Register Now
                          </Button>
                        )}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))
        )}
      </div>

      {/* Registration Dialog */}
      <Dialog open={selectedEvent !== null} onOpenChange={(open) => !open && setSelectedEvent(null)}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Event Registration</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            {selectedEvent && (
              <>
                <div className="mb-4">
                  <h3 className="font-medium mb-1">{selectedEvent.title}</h3>
                  <div className="flex flex-wrap gap-2 text-sm text-gray-500">
                    <div className="flex items-center">
                      <Calendar className="h-4 w-4 mr-1" />
                      {selectedEvent.date}
                    </div>
                    <div className="flex items-center">
                      <Clock className="h-4 w-4 mr-1" />
                      {selectedEvent.time}
                    </div>
                  </div>
                </div>

                <div className="bg-gray-50 p-4 rounded-md mb-4">
                  <h4 className="font-medium mb-2">Registration Details:</h4>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span>Name:</span>
                      <span className="font-medium">Rahul Sharma</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Roll Number:</span>
                      <span className="font-medium">CSE2023001</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Email:</span>
                      <span className="font-medium">rahul.s@eduvision.edu</span>
                    </div>
                  </div>
                </div>

                {selectedEvent.onlinePayment && (
                  <div className="bg-yellow-50 p-4 rounded-md mb-4">
                    <h4 className="font-medium mb-2">Payment Information:</h4>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span>Registration Fee:</span>
                        <span className="font-medium">₹{selectedEvent.paymentAmount}</span>
                      </div>
                      <p className="text-sm text-gray-600">
                        Payment can be made online after registration or at the venue.
                      </p>
                    </div>
                  </div>
                )}

                <div className="flex justify-end gap-2 mt-4">
                  <Button variant="outline" onClick={() => setSelectedEvent(null)}>
                    Cancel
                  </Button>
                  <Button className="bg-green-600 hover:bg-green-700" onClick={handleRegister} disabled={isRegistering}>
                    {isRegistering ? (
                      <>
                        <div className="h-4 w-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                        Registering...
                      </>
                    ) : (
                      "Confirm Registration"
                    )}
                  </Button>
                </div>
              </>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
