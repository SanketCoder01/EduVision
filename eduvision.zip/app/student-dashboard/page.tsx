"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { motion } from "framer-motion"
import { BookOpen, Users, Calendar, Video, MessageCircle, Bell, Code, ChevronRight } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"

export default function StudentDashboardPage() {
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Simulate loading data
    const timer = setTimeout(() => {
      setIsLoading(false)
    }, 1000)

    return () => clearTimeout(timer)
  }, [])

  const menuItems = [
    {
      icon: <BookOpen className="h-8 w-8 text-green-600" />,
      title: "Assignments",
      href: "/student-dashboard/assignments",
      description: "View and submit your assignments",
    },
    {
      icon: <Users className="h-8 w-8 text-green-600" />,
      title: "Study Groups",
      href: "/student-dashboard/study-groups",
      description: "Join and participate in study groups",
    },
    {
      icon: <Video className="h-8 w-8 text-green-600" />,
      title: "Virtual Classroom",
      href: "/student-dashboard/virtual-classroom",
      description: "Attend online classes and lectures",
    },
    {
      icon: <Calendar className="h-8 w-8 text-green-600" />,
      title: "Events",
      href: "/student-dashboard/events",
      description: "View and register for upcoming events",
    },
    {
      icon: <MessageCircle className="h-8 w-8 text-green-600" />,
      title: "Queries",
      href: "/student-dashboard/queries",
      description: "Ask questions and get help from faculty",
    },
    {
      icon: <Bell className="h-8 w-8 text-green-600" />,
      title: "Announcements",
      href: "/student-dashboard/announcements",
      description: "View important announcements",
    },
    {
      icon: <Code className="h-8 w-8 text-green-600" />,
      title: "Compiler",
      href: "/student-dashboard/compiler",
      description: "Access online coding environment",
    },
  ]

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  }

  const item = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0 },
  }

  return (
    <div>
      <div className="bg-gradient-to-r from-green-600 to-green-800 text-white rounded-xl p-6 mb-8">
        <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
          <h1 className="text-2xl md:text-3xl font-bold mb-2">Welcome, Rahul</h1>
          <p className="opacity-90">FY CSE Student</p>
        </motion.div>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {[...Array(7)].map((_, i) => (
            <Card key={i} className="animate-pulse">
              <CardContent className="p-6 h-40">
                <div className="h-8 w-8 bg-gray-200 rounded-full mb-4"></div>
                <div className="h-5 bg-gray-200 rounded w-1/2 mb-2"></div>
                <div className="h-4 bg-gray-200 rounded w-full mb-1"></div>
                <div className="h-4 bg-gray-200 rounded w-2/3"></div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <motion.div
          variants={container}
          initial="hidden"
          animate="show"
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
        >
          {menuItems.map((item, index) => (
            <motion.div key={index} variants={item}>
              <Link href={item.href}>
                <Card className="hover:shadow-md transition-shadow h-full">
                  <CardContent className="p-6 flex flex-col h-full">
                    <div className="mb-4">{item.icon}</div>
                    <h3 className="text-lg font-semibold mb-2">{item.title}</h3>
                    <p className="text-gray-500 text-sm flex-grow">{item.description}</p>
                    <div className="flex justify-end mt-4">
                      <ChevronRight className="h-5 w-5 text-green-600" />
                    </div>
                  </CardContent>
                </Card>
              </Link>
            </motion.div>
          ))}
        </motion.div>
      )}
    </div>
  )
}
