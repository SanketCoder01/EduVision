"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { Users, Calendar, Clock, MapPin, Plus, Search, UserPlus, MessageSquare, Info } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { useToast } from "@/components/ui/use-toast"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Separator } from "@/components/ui/separator"

export default function StudyGroupsPage() {
  const { toast } = useToast()
  const [searchQuery, setSearchQuery] = useState("")
  const [showCreateDialog, setShowCreateDialog] = useState(false)
  const [showJoinDialog, setShowJoinDialog] = useState(false)
  const [selectedGroup, setSelectedGroup] = useState(null)
  const [activeTab, setActiveTab] = useState("my-groups")

  // Mock study groups data
  const studyGroups = [
    {
      id: 1,
      name: "Data Structures Study Group",
      subject: "Computer Science",
      description: "Weekly meetings to discuss data structures concepts and solve practice problems.",
      schedule: "Every Tuesday, 4:00 PM - 6:00 PM",
      location: "Library Study Room 3",
      members: [
        { id: 1, name: "John Doe", avatar: "/placeholder.svg?height=40&width=40", role: "admin" },
        { id: 2, name: "Jane Smith", avatar: "/placeholder.svg?height=40&width=40", role: "member" },
        { id: 3, name: "Alex Johnson", avatar: "/placeholder.svg?height=40&width=40", role: "member" },
      ],
      nextMeeting: "2023-10-17T16:00:00",
      topics: ["Arrays", "Linked Lists", "Trees", "Graphs"],
      isMember: true,
    },
    {
      id: 2,
      name: "Calculus II Study Group",
      subject: "Mathematics",
      description: "Collaborative study sessions for Calculus II. We focus on integration techniques and applications.",
      schedule: "Mondays and Thursdays, 5:00 PM - 7:00 PM",
      location: "Math Building, Room 201",
      members: [
        { id: 4, name: "Emily Chen", avatar: "/placeholder.svg?height=40&width=40", role: "admin" },
        { id: 5, name: "Michael Brown", avatar: "/placeholder.svg?height=40&width=40", role: "member" },
        { id: 6, name: "Sarah Wilson", avatar: "/placeholder.svg?height=40&width=40", role: "member" },
        { id: 1, name: "John Doe", avatar: "/placeholder.svg?height=40&width=40", role: "member" },
      ],
      nextMeeting: "2023-10-16T17:00:00",
      topics: ["Integration by Parts", "Partial Fractions", "Improper Integrals"],
      isMember: true,
    },
    {
      id: 3,
      name: "Database Systems Group",
      subject: "Computer Science",
      description: "Study group focused on database design, SQL, and database management systems.",
      schedule: "Every Wednesday, 3:00 PM - 5:00 PM",
      location: "Computer Lab 2",
      members: [
        { id: 7, name: "David Lee", avatar: "/placeholder.svg?height=40&width=40", role: "admin" },
        { id: 8, name: "Lisa Wang", avatar: "/placeholder.svg?height=40&width=40", role: "member" },
        { id: 9, name: "Robert Taylor", avatar: "/placeholder.svg?height=40&width=40", role: "member" },
      ],
      nextMeeting: "2023-10-18T15:00:00",
      topics: ["SQL Queries", "Database Normalization", "Indexing"],
      isMember: false,
    },
    {
      id: 4,
      name: "Physics Study Circle",
      subject: "Physics",
      description: "Group for discussing physics concepts and solving complex problems together.",
      schedule: "Fridays, 2:00 PM - 4:00 PM",
      location: "Physics Building, Room 105",
      members: [
        { id: 10, name: "James Wilson", avatar: "/placeholder.svg?height=40&width=40", role: "admin" },
        { id: 11, name: "Emma Davis", avatar: "/placeholder.svg?height=40&width=40", role: "member" },
        { id: 12, name: "Thomas Moore", avatar: "/placeholder.svg?height=40&width=40", role: "member" },
      ],
      nextMeeting: "2023-10-20T14:00:00",
      topics: ["Mechanics", "Electromagnetism", "Thermodynamics"],
      isMember: false,
    },
  ]

  // Filter study groups based on search query
  const filteredGroups = studyGroups.filter((group) => {
    if (searchQuery === "") return true

    const query = searchQuery.toLowerCase()
    return (
      group.name.toLowerCase().includes(query) ||
      group.subject.toLowerCase().includes(query) ||
      group.description.toLowerCase().includes(query) ||
      group.topics.some((topic) => topic.toLowerCase().includes(query))
    )
  })

  // Get groups based on tab
  const getGroupsByTab = (tab) => {
    switch (tab) {
      case "my-groups":
        return filteredGroups.filter((group) => group.isMember)
      case "discover":
        return filteredGroups.filter((group) => !group.isMember)
      default:
        return filteredGroups
    }
  }

  // Format date
  const formatDate = (dateString) => {
    const date = new Date(dateString)
    return date.toLocaleDateString("en-US", {
      weekday: "long",
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    })
  }

  // Calculate time remaining
  const getTimeRemaining = (dateString) => {
    const now = new Date()
    const meetingDate = new Date(dateString)
    const diff = meetingDate - now

    if (diff <= 0) return "Meeting in progress"

    const days = Math.floor(diff / (1000 * 60 * 60 * 24))
    const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60))

    if (days > 0) {
      return `${days} day${days > 1 ? "s" : ""} ${hours} hour${hours > 1 ? "s" : ""}`
    } else {
      const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60))
      return `${hours} hour${hours > 1 ? "s" : ""} ${minutes} minute${minutes > 1 ? "s" : ""}`
    }
  }

  // Handle join group
  const handleJoinGroup = (group) => {
    toast({
      title: "Request Sent",
      description: `Your request to join ${group.name} has been sent to the group admin.`,
    })
    setShowJoinDialog(false)
  }

  // Handle create group
  const handleCreateGroup = () => {
    toast({
      title: "Group Created",
      description: "Your study group has been created successfully.",
    })
    setShowCreateDialog(false)
  }

  return (
    <div className="max-w-6xl mx-auto">
      <motion.div
        className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-6"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <h1 className="text-2xl font-bold flex items-center">
          <Users className="inline-block mr-2 h-6 w-6 text-blue-600" />
          Study Groups
        </h1>

        <Button onClick={() => setShowCreateDialog(true)} className="bg-blue-600 hover:bg-blue-700">
          <Plus className="mr-2 h-4 w-4" />
          Create Study Group
        </Button>
      </motion.div>

      <div className="flex flex-col md:flex-row gap-4 mb-6">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
          <Input
            placeholder="Search study groups..."
            className="pl-9"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <Select defaultValue="all">
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Filter by subject" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Subjects</SelectItem>
            <SelectItem value="cs">Computer Science</SelectItem>
            <SelectItem value="math">Mathematics</SelectItem>
            <SelectItem value="physics">Physics</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <Tabs defaultValue="my-groups" value={activeTab} onValueChange={setActiveTab} className="mb-6">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="my-groups" className="data-[state=active]:bg-blue-100 data-[state=active]:text-blue-700">
            <motion.div
              className="flex items-center"
              whileHover={{ scale: 1.03 }}
              transition={{ type: "spring", stiffness: 400, damping: 10 }}
            >
              <Users className="mr-2 h-4 w-4" />
              My Groups
              {getGroupsByTab("my-groups").length > 0 && (
                <Badge variant="outline" className="ml-2 bg-blue-50 text-blue-700">
                  {getGroupsByTab("my-groups").length}
                </Badge>
              )}
            </motion.div>
          </TabsTrigger>
          <TabsTrigger value="discover" className="data-[state=active]:bg-blue-100 data-[state=active]:text-blue-700">
            <motion.div
              className="flex items-center"
              whileHover={{ scale: 1.03 }}
              transition={{ type: "spring", stiffness: 400, damping: 10 }}
            >
              <Search className="mr-2 h-4 w-4" />
              Discover Groups
            </motion.div>
          </TabsTrigger>
        </TabsList>

        {["my-groups", "discover"].map((tab) => (
          <TabsContent key={tab} value={tab}>
            <div className="space-y-4">
              {getGroupsByTab(tab).length === 0 ? (
                <div className="text-center py-12 bg-gray-50 rounded-lg">
                  <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    {tab === "my-groups" ? (
                      <Users className="h-8 w-8 text-gray-400" />
                    ) : (
                      <Search className="h-8 w-8 text-gray-400" />
                    )}
                  </div>
                  <h3 className="text-lg font-medium text-gray-900 mb-2">
                    {tab === "my-groups" ? "No study groups joined" : "No study groups found"}
                  </h3>
                  <p className="text-gray-500 mb-4">
                    {tab === "my-groups"
                      ? "You haven't joined any study groups yet."
                      : "Try adjusting your search or filters."}
                  </p>
                  {tab === "my-groups" && <Button onClick={() => setActiveTab("discover")}>Discover Groups</Button>}
                </div>
              ) : (
                getGroupsByTab(tab).map((group) => (
                  <motion.div
                    key={group.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3 }}
                  >
                    <Card>
                      <CardContent className="p-6">
                        <div className="flex flex-col md:flex-row gap-6">
                          <div className="flex-1">
                            <div className="flex items-center justify-between mb-2">
                              <h3 className="text-lg font-bold">{group.name}</h3>
                              <Badge variant="outline" className="bg-blue-50 text-blue-700">
                                {group.subject}
                              </Badge>
                            </div>

                            <p className="text-gray-700 mb-4">{group.description}</p>

                            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-4">
                              <div className="flex items-start">
                                <Calendar className="h-5 w-5 text-gray-500 mr-2 mt-0.5" />
                                <div>
                                  <p className="font-medium text-sm">Schedule</p>
                                  <p className="text-sm text-gray-600">{group.schedule}</p>
                                </div>
                              </div>

                              <div className="flex items-start">
                                <MapPin className="h-5 w-5 text-gray-500 mr-2 mt-0.5" />
                                <div>
                                  <p className="font-medium text-sm">Location</p>
                                  <p className="text-sm text-gray-600">{group.location}</p>
                                </div>
                              </div>

                              <div className="flex items-start">
                                <Clock className="h-5 w-5 text-gray-500 mr-2 mt-0.5" />
                                <div>
                                  <p className="font-medium text-sm">Next Meeting</p>
                                  <p className="text-sm text-gray-600">{formatDate(group.nextMeeting)}</p>
                                  <p className="text-xs text-blue-600 font-medium">
                                    {getTimeRemaining(group.nextMeeting)} remaining
                                  </p>
                                </div>
                              </div>

                              <div className="flex items-start">
                                <Users className="h-5 w-5 text-gray-500 mr-2 mt-0.5" />
                                <div>
                                  <p className="font-medium text-sm">Members</p>
                                  <div className="flex -space-x-2 mt-1">
                                    {group.members.slice(0, 3).map((member) => (
                                      <Avatar key={member.id} className="h-6 w-6 border-2 border-white">
                                        <AvatarImage src={member.avatar || "/placeholder.svg"} alt={member.name} />
                                        <AvatarFallback>{member.name.charAt(0)}</AvatarFallback>
                                      </Avatar>
                                    ))}
                                    {group.members.length > 3 && (
                                      <div className="flex items-center justify-center h-6 w-6 rounded-full bg-gray-200 text-xs font-medium border-2 border-white">
                                        +{group.members.length - 3}
                                      </div>
                                    )}
                                  </div>
                                </div>
                              </div>
                            </div>

                            <div className="flex flex-wrap gap-2 mb-4">
                              {group.topics.map((topic, index) => (
                                <Badge key={index} variant="outline" className="bg-gray-100">
                                  {topic}
                                </Badge>
                              ))}
                            </div>
                          </div>

                          <div className="flex flex-row md:flex-col gap-2 justify-end">
                            <Button
                              variant="outline"
                              className="flex items-center"
                              onClick={() => setSelectedGroup(group)}
                            >
                              <Info className="mr-2 h-4 w-4" />
                              Details
                            </Button>

                            {group.isMember ? (
                              <Button className="bg-blue-600 hover:bg-blue-700">
                                <MessageSquare className="mr-2 h-4 w-4" />
                                Chat
                              </Button>
                            ) : (
                              <Button
                                className="bg-blue-600 hover:bg-blue-700"
                                onClick={() => {
                                  setSelectedGroup(group)
                                  setShowJoinDialog(true)
                                }}
                              >
                                <UserPlus className="mr-2 h-4 w-4" />
                                Join Group
                              </Button>
                            )}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))
              )}
            </div>
          </TabsContent>
        ))}
      </Tabs>

      {/* Create Study Group Dialog */}
      <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>Create Study Group</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="group-name">Group Name</Label>
              <Input id="group-name" placeholder="Enter group name" />
            </div>

            <div className="space-y-2">
              <Label htmlFor="group-subject">Subject</Label>
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder="Select subject" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="cs">Computer Science</SelectItem>
                  <SelectItem value="math">Mathematics</SelectItem>
                  <SelectItem value="physics">Physics</SelectItem>
                  <SelectItem value="chemistry">Chemistry</SelectItem>
                  <SelectItem value="biology">Biology</SelectItem>
                  <SelectItem value="literature">Literature</SelectItem>
                  <SelectItem value="history">History</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="group-description">Description</Label>
              <Textarea
                id="group-description"
                placeholder="Describe the purpose and goals of your study group"
                rows={3}
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="group-schedule">Schedule</Label>
                <Input id="group-schedule" placeholder="e.g., Every Tuesday, 4-6 PM" />
              </div>

              <div className="space-y-2">
                <Label htmlFor="group-location">Location</Label>
                <Input id="group-location" placeholder="e.g., Library Study Room 3" />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="group-topics">Topics (comma separated)</Label>
              <Input id="group-topics" placeholder="e.g., Arrays, Linked Lists, Trees" />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowCreateDialog(false)}>
              Cancel
            </Button>
            <Button className="bg-blue-600 hover:bg-blue-700" onClick={handleCreateGroup}>
              Create Group
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Join Study Group Dialog */}
      <Dialog open={showJoinDialog} onOpenChange={setShowJoinDialog}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Join Study Group</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            {selectedGroup && (
              <>
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-lg font-medium">{selectedGroup.name}</h3>
                  <Badge variant="outline" className="bg-blue-50 text-blue-700">
                    {selectedGroup.subject}
                  </Badge>
                </div>

                <p className="text-gray-700">{selectedGroup.description}</p>

                <div className="space-y-2">
                  <Label htmlFor="join-message">Message to Group Admin (Optional)</Label>
                  <Textarea
                    id="join-message"
                    placeholder="Introduce yourself and explain why you want to join this group"
                    rows={3}
                  />
                </div>
              </>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowJoinDialog(false)}>
              Cancel
            </Button>
            <Button className="bg-blue-600 hover:bg-blue-700" onClick={() => handleJoinGroup(selectedGroup)}>
              Send Join Request
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Group Details Dialog */}
      <Dialog open={selectedGroup !== null && !showJoinDialog} onOpenChange={(open) => !open && setSelectedGroup(null)}>
        <DialogContent className="sm:max-w-[700px] max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Group Details</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            {selectedGroup && (
              <>
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-xl font-bold">{selectedGroup.name}</h3>
                  <Badge variant="outline" className="bg-blue-50 text-blue-700">
                    {selectedGroup.subject}
                  </Badge>
                </div>

                <p className="text-gray-700">{selectedGroup.description}</p>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                  <div className="bg-gray-50 p-3 rounded-md">
                    <div className="flex items-start">
                      <Calendar className="h-5 w-5 text-gray-500 mr-2 mt-0.5" />
                      <div>
                        <p className="font-medium text-sm">Schedule</p>
                        <p className="text-sm text-gray-600">{selectedGroup.schedule}</p>
                      </div>
                    </div>
                  </div>

                  <div className="bg-gray-50 p-3 rounded-md">
                    <div className="flex items-start">
                      <MapPin className="h-5 w-5 text-gray-500 mr-2 mt-0.5" />
                      <div>
                        <p className="font-medium text-sm">Location</p>
                        <p className="text-sm text-gray-600">{selectedGroup.location}</p>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-blue-50 p-4 rounded-md mb-4">
                  <div className="flex items-start">
                    <Clock className="h-5 w-5 text-blue-500 mr-2 mt-0.5" />
                    <div>
                      <p className="font-medium">Next Meeting</p>
                      <p className="text-gray-700">{formatDate(selectedGroup.nextMeeting)}</p>
                      <p className="text-sm text-blue-600 font-medium mt-1">
                        {getTimeRemaining(selectedGroup.nextMeeting)} remaining
                      </p>
                    </div>
                  </div>
                </div>

                <div>
                  <h4 className="font-medium mb-2">Topics Covered</h4>
                  <div className="flex flex-wrap gap-2 mb-4">
                    {selectedGroup.topics.map((topic, index) => (
                      <Badge key={index} variant="outline" className="bg-gray-100">
                        {topic}
                      </Badge>
                    ))}
                  </div>
                </div>

                <Separator />

                <div>
                  <h4 className="font-medium mb-3">Members ({selectedGroup.members.length})</h4>
                  <div className="space-y-2">
                    {selectedGroup.members.map((member) => (
                      <div key={member.id} className="flex items-center justify-between">
                        <div className="flex items-center">
                          <Avatar className="h-8 w-8 mr-2">
                            <AvatarImage src={member.avatar || "/placeholder.svg"} alt={member.name} />
                            <AvatarFallback>{member.name.charAt(0)}</AvatarFallback>
                          </Avatar>
                          <div>
                            <p className="text-sm font-medium">{member.name}</p>
                            {member.role === "admin" && (
                              <Badge variant="outline" className="text-xs bg-amber-50 text-amber-700">
                                Admin
                              </Badge>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </>
            )}
          </div>
          <DialogFooter className="flex justify-end gap-2">
            {selectedGroup && !selectedGroup.isMember && (
              <Button
                className="bg-blue-600 hover:bg-blue-700"
                onClick={() => {
                  setShowJoinDialog(true)
                }}
              >
                <UserPlus className="mr-2 h-4 w-4" />
                Join Group
              </Button>
            )}

            {selectedGroup && selectedGroup.isMember && (
              <Button className="bg-blue-600 hover:bg-blue-700">
                <MessageSquare className="mr-2 h-4 w-4" />
                Open Chat
              </Button>
            )}

            <Button variant="outline" onClick={() => setSelectedGroup(null)}>
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
